<section class="privacy-policy">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h4>Terms and conditions</h4>

        <h5>Introduction</h5>

<p>Evd Private Limited ( Evd / we / us / our ) respects the privacy of all the users, including but not limited to customers, dealers and distributors, who use or access (Users / you / your / their ) our website www.pureev.in (Website) or otherwise provide any information, including personal information while availing any products or services offered by us or any other dealings with us. PuR Energy is committed towards protecting and safeguarding the information, including personal information of its Users which may be collected by PuR Energy in consequence of your use / access / browsing of the Website or other dealings offline. Any personal information collected from You shall be governed by this privacy policy (Privacy Policy). This Privacy Policy provides for the nature and type of information collected, the manner in which it is collected, use of such information, and disclosure and handling of such information by PuR Energy. The Users are advised to read this Privacy Policy, along with our Terms and Conditions (Terms), before using / accessing / browsing the Website or otherwise providing PuR Energy with their information and/ or personal information.</p>

 
<p>By using the Website or otherwise providing your information, you signify your consent for PuR Energy to manage your information, including personal information in accordance with this Privacy Policy. If you do not agree with this Privacy Policy, then such you shall not be authorized to use / access / browse the Website.</p>

<p>This Privacy Policy is published in compliance with, inter alia:</p>

<p>(a)Section 43A of the Information Technology Act, 2000;</p>

<p>(b) Rule 4 of the Information Technology (Reasonable Security Practices and Procedures and Sensitive Personal Data or Information) Rules, 2011; and</p>

<p>(c)Rule 3(1) of the Information Technology (Intermediaries Guidelines) Rules, 2011.</p>


<h5>1. General</h5>

<p>By using / accessing / browsing the Website or by otherwise giving us your Information (as defined hereunder), you confirm that you have the capacity to enter into a legally binding contract and that you have read, understood and agreed to the practices and policies outlined in this Privacy Policy and our Terms (together the Agreement). You hereby consent to our collection, use, sharing, and disclosure of your Information as described in this Privacy Policy.<br>
Change to this Privacy Policy</p>

<p>Evd is committed to comply with the extant applicable laws of India. PuR Energy reserves the right to amend, modify, add, delete or remove any portion of this Privacy Policy as required under any applicable law or if required to enhance and improve the Users� experience of its Website. Usage of your Information shall be governed by the last updated or revised Privacy Policy which shall be available on the Website. Your continued use / access / browsing of the Website or otherwise providing us your Information after any such amendment or modification signifies your acceptance to such amendment or modification. If you do not agree with this Privacy Policy at any time, in part or as a whole, you may not use / access / browse the Website or provide us with any of your Information.</p>

<h5>2. Information being collected</h5>

<p>We collect the following types of information about you: (i) Personal Information; (ii) Demographic Information; (iii) Cookies; (iv) Behavioural Information; and (v) Indirect Information, (each of which have been defined below, and collectively, Information). We may collect your Information either directly from you through offline collection and documentation, by virtue of your use / access / browsing of the Website or indirectly by using different technologies.</p>
<p>The following Information, may be collected by us:</p>

<p>(a) Your full name, date of birth, contact details, email address, physical address, financial information (credit card / debit card number, expiration date, CVV number, banking details, billing information, payment history, etc.), permanent account number (PAN), Aadhar number, passport copy, telephone / electricity bill copy and any other related information / data;</p>

<p>(b) Details of your company or organisation, including but not limited to, name and address, goods and service tax identification number (GSTIN), permanent account number (PAN), copy of cancelled cheque for bank verification, latest income tax returns, financial statements, memorandum or articles of association, details of directors, rental / lease agreements, insurance details, telephone / electricity bill copy, so on and so forth (paragraph 2.1 (a) and 2.1 (b) being collectively referred to as Personal Information);</p>

<p>(c) Information which refers to selected population characteristics including age, gender and current geographical location details (Demographic Information);</p>

<p>(d) We also store cookies to: (i) track user activity, behaviour and movement on the on the Website; (ii) analyse user patterns and trends; (iii) track the sections, links, tabs or pages that are most visited by the users; and (iv) to build a database of user preferences (Cookies);</p>

<p>(e) We may also collect information about how you use the Website and information about your device, server, software, usage statistics, traffic data, internet protocol (IP) address, browser and operating system type, domain names, access times, URLs, location and location-based information, and details regarding the parts of the Website that you access (Behavioural Information); and</p>

<p>(f) your use of certain third party services on our Website, if any, also requires us to collect such information as is considered necessary for that purpose (Indirect Information).</p>

<p>While we may collect Demographic Information, Cookies, Behavioural Information and Indirect Information when you access or use our Website, we collect Personal Information only from you with your prior consent unless there are other legal grounds for doing so, as further specified in this Privacy Policy. In the event that you provide us with Personal Information of third parties, we understand that You have obtained consent of such third parties, and have sufficient rights, approvals and licenses to provide such information to us.</p>

<h5>3. Consent</h5>

<p>By using / accessing / browsing the Website, you acknowledge and agree that all Information, including Personal Information provided by you to us is voluntarily which can be used in accordance with this Privacy Policy. The collection, use and disclosure of Personal Information requires your express consent, unless there are other legal grounds available to us to collect such information as further specified in this Privacy Policy. By using / accessing / browsing the Website or otherwise providing us with your Personal Information, where applicable, you are providing us with your unconditional consent to our collection, usage, disclosure, retention and processing of the Personal Information in accordance with the terms of this Privacy Policy.</p>

<p>The following Information, may be collected by us:</p>

<p>In the event of a change in the law applicable to data protection in India, you hereby expressly consent to our continued use, storage, collection and disclosure of your Information including Personal Information to the fullest extent permitted under such applicable law. We may reach out to you for obtaining additional consents and approvals as required under the amended law and you will be required to comply with such requests. Should you choose to not provide us with such additional consents and approvals, you shall discontinue use / access of the Website.</p>

<p>You may choose to not provide us with or withdraw any or all information being Personal Information, but in the event that you do so, we may be unable to allow you to use / access / browse the Website or parts or features thereof, for which your Personal Information is being collected or processed. You can also withdraw your consent by writing to us at info@evd.co.in</p>

<h5>4. Use of Personal Information</h5>

<p>We use your Information: (i) to provide our products and services to you; (ii) to operate and improve the Website in order to foster a positive user experience; (iii) for analysing data, tracking trends, building algorithms, creating databases for rating systems, recommendations engines, etc.; (iii) (iv) to conduct audits and quality assessment procedures; and (v) to analyse the use of our resources and troubleshooting problems in relation to the Website.</p>

<p>The following Information, may be collected by us:</p>

<p>In addition to the above, we also use your Information, including Personal Information: (i) for internal operational purpose such as record keeping, accounting and compliance with applicable laws; (ii) for recording information including dates, time and locations at which the Website has been accessed by using various tracking technologies and thereby improve our Website and your experience by providing you with relevant information based on the above. Your disabling of tracking features on the Website by changing settings on your device and / or web browser may result in your inability to use the Website optimally or entirely; (iii) to investigate, prevent, or take action regarding illegal activities, suspected fraud, situations involving potential threats to the safety of any person, or as otherwise required by law; and (v) to respond to any queries that you may have, and to communicate information to you.</p>

<h5>5. Your Rights</h5>

<p>You may review, correct, update, or change your Personal Information collected by us by sending an email to us at info@purenergy.co.in
If you wish to delete your Personal Information provided to PuR Energy, you can always do so by sending a request to us at info@evd.co.in</p>

<p>You may disable the browser cookies before using / accessing / browsing the Website. However, if you do so, you may not be able to access certain features of the Website.</p>

<p>You may choose not to provide us with information for non-mandatory fields.</p>

<p>You may note that correction or deletion of certain Information and / or Personal Information or data may lead to cancellation of your access to the Website or to certain features thereof. You also agree and acknowledge that certain data or Information cannot be corrected or deleted and / or may be prohibited from being deleted under any applicable law or in lieu of law enforcement requests or under any judicial proceedings.</p>

<h5>6. Retention Of Information</h5>

<p>We retain your Information, including Personal Information to provide you with our products and services or in lieu of our dealings thereof or as is reasonably necessary for the purposes listed in this Privacy Policy, including pursuing our legitimate business interests, conducting audits, complying with any legal, regulatory, tax or accounting requirements, preventing any illegal activities or suspected fraud and so on. Further, we may retain your Information excluding Personal Information for the purposes of analysing data, tracking trends, building algorithms, creating databases, derivative data, rating systems, recommendations engines, so on and so forth. However, it is hereby clarified that PuR Energy shall be the sole owner of any databases, derivative data, algorithms, analysis or systems created or maintained by Ev Energy.</p>

<h5>7. Disclosure</h5>

<p>Evd Energy does not disclose any Personal Information to any individual or entity except as provided in this Privacy Policy. PuR Energy may disclose such Personal Information only when required under an applicable law to any authority authorized to collect such information and only to the extent necessary. PuR Energy may at its sole discretion, disclose the Personal Information of its Users to: (i) its employees, agents and service providers who need to know that information in order to process it for us, and who are subject to strict contractual confidentiality obligations; and (ii) third party organizations / entities who may analyse such Personal Information and other related data for the purpose of developing existing as well as new products, enhancing and improving its services, conducting research, marketing of products and services and other related purposes. PuR Energy does not sell or trade in any form or manner, the Personal Information of its Users to any third party.
In the event that PuR Energy discloses the Personal Information of its Users to any third party, it ensures that such third party is bound by confidentiality obligations similar to the confidentiality obligations of PuR Energy under this Privacy Policy, prior to such disclosure to such third party.</p>

<h5>8. Security</h5>

<p>We are committed to ensure that Your Information, including Personal Information is secure with us. To ensure the security and protection from any unauthorized access or disclosure we have in place appropriate physical, electronic and managerial procedures to safeguard and secure the Information, including Personal Information we collect on the Website or during our dealings with you. We do not retain any Personal Information collected from You for any period longer than reasonably required by us for the purpose of providing our products or services or our dealings with you, or such period as may be required by applicable laws. However, please be informed that despite the stringent security measures being adopted by PuR Energy, there may still exist the risk of potential security breaches which are inherent in the use of the internet. Further, PuR Energy shall not be responsible for any breach of security or for any actions of any third parties or events that are beyond our reasonable control, including but not limited to, acts of god, natural calamities, war, terrorism, acts of government, hacking, cyber terrorism, unauthorised access to any Information, Personal Information or data or other electronic devices and storage devices, device crashes, breach of security and encryption, so on and so forth.</p>

<h5>9. Third Party Links</h5>

<p>The Website may host links to third party websites and services (Third Party Links). We have no control over such Third Party Links, which are provided by persons or companies other than us. We are not responsible for any collection or disclosure of any of your Information or Personal Information by such companies or persons on such Third Party Links thereof.</p>

<p>You agree and acknowledge to that Third Party Links have their own privacy policies governing the collection, storage, transfer, retention and / or disclosure of your information or personal information and that you access such Third Party Links at your own risk.</p>

<h5>10. Disclaimer</h5>

<p>Although we are committed to protecting your privacy, we do not make any promise to the effect that your Information, including Personal Information, or private communications will always remain private or be disclosed in ways not otherwise described in this Privacy Policy. You assume all responsibility and risk for: (i) your use of the Website; (ii) use of the internet generally; (iii) the Information you provide to us; and (iv) your conduct on and off the Website. Further, we assume no liability for any actions of third parties with regard to your Information and / or Personal Information which you may have disclosed to such third parties by accessing or visiting Third Party Links. PuR Energy shall disclaim any and all liability arising out of your use of Third Party Links or any other dealings with such third parties.</p>

<h5>11. Governing Law</h5>

<p>This Privacy Policy shall, in all respects, be governed by and construed in all respect in accordance with the laws of India. The Parties agree to submit to the exclusive jurisdiction of the courts in Hyderabad, India in connection with any dispute arising out of or in connection with this Privacy Policy.</p>

<h5>12. Grievance Redressal</h5>

<p>If you have questions, comments, suggestions or grievance with respect to the Privacy Policy, please contact us at any of the following:<br>
PuR Energy Private Limited: info@purenergy.co.in</p>

<p>Or ABC Kumar, Data Protection Officer, Email: ev.service@evd.co.in    </p>
      </div>
      
    </div>
  </div>
</section>
<style>
    .privacy-policy h4 {
    color: #00a66d;
    margin-top: 100px;
    font-size: 28px;
    font-weight: 700;
    margin-bottom: 20px;
}
</style>