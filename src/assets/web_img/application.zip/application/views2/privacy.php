<section class="privacy-policy">
  <div class="container">
    <?php
		echo base64_decode($cms->content);?>
  </div>
</section>
<style>
    .privacy-policy h4 {
    color: #00a66d;
    margin-top: 100px;
    font-size: 28px;
    font-weight: 700;
    margin-bottom: 20px;
}
</style>