<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/admin/css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>evdreamz Admin Panel</title>
  </head>
  <style>
  .lbl{
  color:#222222 !important;
  }
  .signin{
      background-color: #3f51b5 !important;
    border: 2px solid #3f51b5 !important;
	width:100%;
	}
  </style>
  <body style="background-color:#023591;">
    <section class="" >
      <div class="cover"></div>
    </section>
    <section class="login-content">
      
     <div class="login-box" style="
    min-width: 500px !important;
    min-height: 500px !important;
    border-radius: 15px;
">
        <form class="login-form" action="" method="post">
		
		
        
		   
		  <div class="form-group" align="center">
		 <img style=" margin-top: 50px;width:55%;" src="<?php echo base_url('images/LOGGO.png')?>" >
		 
		 	<h2 style="
    font-size: 20px;
    font-family: 'Outfit', Sans-Serif;
    margin: -12px -1px 0px 7px;
    line-height: 3.2;
">Admin Login</h2>
		  </div>
          <div class="form-group">
            <label class="control-label lbl" style="
    font-family: 'Outfit', Sans-Serif;font-size: 18px;
">Email</label>
            <input class="form-control " type="text" name="email" id="LoginEmail" placeholder="Email" autofocus >
          </div>
          <div class="form-group">
            <label class="control-label lbl" style="
    font-family: 'Outfit', Sans-Serif;
    font-size: 18px;
">Password</label>
            <input class="form-control" type="password" name="password" placeholder="Password">
          </div>
		  
          <div class="form-group">
          
<button style="background-color: #222222;color:white;height: 50px;font-size: 25px;font-family: 'Outfit', Sans-Serif;" class="btn  btn-block signin" type="submit"><i></i>Login</button>	
			
          </div>
		
        </form>
		
      </div>
    </section>
    <!-- Essential javascripts for application to work-->
    <script src="<?php echo base_url()?>assets/admin/js/jquery-3.2.1.min.js"></script>
    <script src="<?php echo base_url()?>assets/admin/js/popper.min.js"></script>
    <script src="<?php echo base_url()?>assets/admin/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url()?>assets/admin/js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="<?php echo base_url()?>assets/admin/js/plugins/pace.min.js"></script>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script type="text/javascript">
	
      // Login Page Flipbox control
      $('.login-content [data-toggle="flip"]').click(function() {
      	$('.login-box').toggleClass('flipped');
      	return false;
      });
	 
	<?php 
	  if($this->session->flashdata('error')){?>
   swal('','<?php echo $this->session->flashdata('error');?>','error');
<?php }?>
	  
    </script>
  </body>
</html>