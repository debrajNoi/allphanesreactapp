<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-edit"></i> Edit Profile</h1>
    </div>
   
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="tile">
        <form class="form-horizontal" method="post" action="" enctype="multipart/form-data">
          <div class="tile-body">
          <div class="form-group row">
            <label class="control-label col-md-3" style="margin-top: 47px;">Profile Picture</label>
            <div class="col-md-8">
              <?php
				if($profile->image!=''){ $image=base_url('uploads/profile/'.$profile->image); } else { $image=base_url('uploads/profile/default.png');} ?>
              <img id="blah" src="<?php echo $image;?>" class="profile-pic"  />
             <input type="hidden" name="old_image" value="<?php echo $profile->image;?>" />
             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input type="file" name="image" accept="image/jpeg" id="imgInp" />
            </div>
          </div>
          <div class="form-group row">
            <label class="control-label col-md-3">Name</label>
            <div class="col-md-8">
              <input class="form-control col-md-8" type="text" name="name" placeholder="Name" value="<?=$profile->name?>" required>
            </div>
          </div>
          <div class="form-group row">
            <label class="control-label col-md-3">Email</label>
            <div class="col-md-8">
              <input class="form-control col-md-8" type="email" name="email" placeholder="Name" value="<?=$profile->email?>" required>
            </div>
          </div>
          <div class="form-group row">
            <label class="control-label col-md-3">Phone</label>
            <div class="col-md-8">
              <input class="form-control col-md-8" type="text" name="phone" placeholder="Phone" value="<?=$profile->phone?>" required maxlength="10" onkeypress="return isNumber(event)">
            </div>
          </div>
		  <div class="tile-footer">
            <div class="row">
              <div class="col-md-8 col-md-offset-3">
                <button class="btn btn-primary" type="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>Update</button>
                <a class="btn btn-secondary" href="<?=base_url('Admin/dashboard')?>"><i class="fa fa-fw fa-lg fa-times-circle"></i>Back</a> </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</main>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script>
function readURL(input) {
  if (input.files && input.files[0]) {
    var reader = new FileReader();
    
    reader.onload = function(e) {
      $('#blah').attr('src', e.target.result);
    }
    
    reader.readAsDataURL(input.files[0]); // convert to base64 string
  }
}

$("#imgInp").change(function() {
  readURL(this);
});


<?php
if($this->session->flashdata('error')){?>
   swal('Oops!','<?php echo $this->session->flashdata('error');?>','error');
<?php }

if($this->session->flashdata('success')){?>
   swal('success!','<?php echo $this->session->flashdata('success');?>','success');
<?php }?>



function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}
</script>