<style>
.fa-android{
color:red;
}
</style>
<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
   <aside class="app-sidebar" style="box-shadow: none;">
  <?php  $user_type=$this->session->userdata('user_type');
 $cont= $this->router->fetch_class();
  $method=$this->router->fetch_method();
  //echo $method;
  
  ?>
      <ul class="app-menu">
        <li><a class="app-menu__item" href="<?=base_url()?>Admin/dashboard"><i class="app-menu__icon fa fa-dashboard"></i><span class="app-menu__label">Dashboard</span></a></li>
		
		<li class="treeview <?php if($method=='terms_conditions' || $method=='contact_us' || $method=='about_us' ){?> is-expanded <?php }?>"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-globe"></i><span class="app-menu__label"> Manage Website</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
		  <li><a class="treeview-item" href="<?=base_url('Admin/about_us')?>"><i class="icon fa fa-file-text-o"></i>About Us</a></li>
		 <li><a class="treeview-item" href="<?=base_url('Admin/contact_us')?>"><i class="icon fa fa-file-text-o"></i>Contact Us</a></li>
		  <li><a class="treeview-item" href="<?=base_url('Admin/terms_conditions')?>"><i class="icon fa fa-file-text-o"></i>Terms & Conditions</a></li>
		  <li><a class="treeview-item" href="<?=base_url('Admin/privacy_policy')?>"><i class="icon fa fa-file-text-o"></i> Privacy Policy </a></li>
		 </ul>
		  
		 </li>
		
		 
		
		
		
		<li class="treeview <?php if($method=='product_list' || $method=='product_add' || $method=='product_edit' ){?> is-expanded <?php }?>"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-product-hunt"></i><span class="app-menu__label"> Manage Products</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
		 
		 
		  <li><a class="treeview-item" href="<?=base_url('admin/product_list')?>"><i class="icon fa fa-list"></i>Product List</a></li>
		  <!--<li><a class="treeview-item" href="<?=base_url('admin/product_add')?>"><i class="icon fa fa-plus"></i> Product Add</a></li>-->
		 </ul>
		  
		 </li> 
		 
		 <li><a class="app-menu__item" href="<?=base_url()?>Admin/vendor_list"><i class="app-menu__icon fa fa-user"></i><span class="app-menu__label">Vendor List</span></a></li>
		 
		  <li><a class="app-menu__item" href="<?=base_url()?>Admin/booking_requests"><i class="app-menu__icon fa fa-smile-o"></i><span class="app-menu__label">Booking Requests</span></a></li>
		 
		 
	<!--	<li class="treeview <?php if($method=='counselor_list' || $method=='add_counselor' || $method=='counselor_edit' ){?> is-expanded <?php }?>"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-user-o"></i><span class="app-menu__label"> Manage Counselor</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
		 
		 
		  <li><a class="treeview-item" href="<?=base_url('Admin/counselor_list')?>"><i class="icon fa fa-list"></i>Counselor List</a></li>
		  <li><a class="treeview-item" href="<?=base_url('Admin/add_counselor')?>"><i class="icon fa fa-plus"></i> Counselor Add</a></li>
		 </ul>
		  
		 </li> 
		 
	
	<li class="treeview <?php if($method=='country_list' || $method=='university_list' || $method=='course_list' ){?> is-expanded <?php }?>"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-database"></i><span class="app-menu__label">Masters</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
		 
		 
		  <li><a class="treeview-item <?php if($method=='country_list'){?>active<?php }?>" href="<?=base_url('Admin/country_list')?>"><i class="icon fa fa-flag"></i>Manage Country</a></li>
		  <li><a class="treeview-item <?php if($method=='university_list'){?>active<?php }?>" href="<?=base_url('Admin/university_list')?>"><i class="icon fa fa-university"></i> Manage University</a></li>
		  <li><a class="treeview-item <?php if($method=='course_list'){?>active<?php }?>" href="<?=base_url('Admin/course_list')?>"><i class="icon fa fa-book"></i> Manage Course</a></li>
		 </ul>
		  
		 </li>-->
		   
		 
      </ul>
    </aside>