<!-- Essential javascripts for application to work-->
    <script src="<?=base_url()?>assets/admin/js/jquery-3.2.1.min.js"></script>
    <script src="<?=base_url()?>assets/admin/js/popper.min.js"></script>
    <script src="<?=base_url()?>assets/admin/js/bootstrap.min.js"></script>
    <script src="<?=base_url()?>assets/admin/js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="<?=base_url()?>assets/admin/js/plugins/pace.min.js"></script>
	
    
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<script type="text/javascript" src="<?=base_url()?>assets/admin/js/plugins/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="<?=base_url()?>assets/admin/js/plugins/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">
     
        $('#sampleTable').DataTable();</script>
	
	<!--For Date Picker-->
	<script type="text/javascript" src="<?=base_url()?>assets/admin/js/plugins/bootstrap-datepicker.min.js"></script>
	<script type="text/javascript" src="<?=base_url()?>assets/admin/js/plugins/select2.min.js"></script>
	<!--<script src="<?=base_url()?>assets/ckeditor/ckeditor.js"></script>-->
	<script type="text/javascript" src="https://cdn.ckeditor.com/4.6.2/standard-all/ckeditor.js"></script>   
	
	
<script>
CKEDITOR.replace( 'description', {
  height: 300,
  filebrowserUploadUrl: "<?php echo base_url('Admin/EditorFileUpload')?>"
 });
                // Replace the <textarea id="editor1"> with a CKEditor 4
                // instance, using default configuration.
                //CKEDITOR.replace( 'description' );
				// CKEDITOR.replace( '.ckeditor' );
				
				
            </script>
	<script type="text/javascript">
      $('#sl').click(function(){
      	$('#tl').loadingBtn();
      	$('#tb').loadingBtn({ text : "Signing In"});
      });
      
      $('#el').click(function(){
      	$('#tl').loadingBtnComplete();
      	$('#tb').loadingBtnComplete({ html : "Sign In"});
      });
      
      $('#demoDate').datepicker({
      	format: "dd/mm/yyyy",
      	autoclose: true,
      	todayHighlight: true
      });
      
      $('#demoSelect').select2();
    </script>
    <!-- Google analytics script-->
    <script type="text/javascript">
      if(document.location.hostname == 'pratikborsadiya.in') {
      	(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
      	(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
      	m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
      	})(window,document,'script','//www.google-analytics.com/analytics.js','ga');
      	ga('create', 'UA-72504830-1', 'auto');
      	ga('send', 'pageview');
      }
    </script>
  </body>
</html>