<main class="app-content">
<style>
h5 {
    text-transform: uppercase;
    font-size: 15px;
    margin-top: 12px;
    
}
.red{
color:#FF0066;
}
</style>
      <div class="app-title">
        <div>
          <h1> Dashboard</h1>
          <p>Welcome to EV Dreamz  Admin  panel</p>
        </div>
       
      </div>
      <br/><br/><br/>
   <div class="row">   
	  <div class="col-md-6 col-lg-4">
	 <?php $products = $this->db->query('SELECT * FROM products');?>


          <div class="widget-small primary coloured-icon"><i class="icon fa fa-product-hunt fa-3x"></i>
		  <a href="<?php echo base_url('Admin/product_list');?>">
            <div class="info">
			
			              <h5>  Products</h5>
              <p><b><?php echo $products->num_rows();?></b></p>
            </div>
			 </a>
          </div>
		 
        </div>
		
		<div class="col-md-6 col-lg-4">
	 <?php $vendors = $this->db->query('SELECT * FROM users WHERE user_type="Vendor"');?>


          <div class="widget-small primary coloured-icon"><i class="icon fa fa-user fa-3x"></i>
		  <a href="<?php echo base_url('Admin/vendor_list');?>">
            <div class="info">
			
			              <h5> Vendors</h5>
              <p><b><?php echo $vendors->num_rows();?></b></p>
            </div>
			 </a>
          </div>
		 
        </div>
		
		<div class="col-md-6 col-lg-4">
	 <?php $bookings = $this->db->query('SELECT * FROM customer_bookings ');?>


          <div class="widget-small primary coloured-icon"><i class="icon fa fa-smile-o" aria-hidden="true"></i>
		  <a href="<?php echo base_url('Admin/booking_requests');?>">
            <div class="info">
			
			              <h5> Booking Requests</h5>
              <p><b><?php echo $bookings->num_rows();?></b></p>
            </div>
			 </a>
          </div>
		 
        </div>
		
	<!--<div class="col-md-6 col-lg-4">
	 
          <div class="widget-small primary coloured-icon"><i class="icon fa fa-commenting-o fa-3x"></i>
		  <a href="<?php echo base_url('Admin/testimonial_list');?>">
            <div class="info">
			
			              <h5> Testimonials</h5>
              <p><b>1</b></p>
            </div>
			 </a>
          </div>
		 
        </div>
		
	<div class="col-md-6 col-lg-4">
	 
          <div class="widget-small primary coloured-icon"><i class="icon fa fa-user-o fa-3x"></i>
		  <a href="<?php echo base_url('Admin/counselor_list');?>">
            <div class="info">
			
			              <h5>Counselors</h5>
              <p><b>1</b></p>
            </div>
			 </a>
          </div>
		 
        </div>-->
		

	</div>	
    </main>
    	<style>
	    h5 {
    text-transform: none;
    font-size: 15px;
    margin-top: 12px;
}
	</style>