<section class="conta-set-1">
  <div class="container">
    <div class="row">
      <div class="col-md-7">
        <h3><?php echo $cms->title;?></h3>

        <p><?php echo base64_decode($cms->content);?></p>


      </div>
      <div class="col-md-1"></div>
      <div class="col-md-4">
        <img src="<?php echo base_url('uploads/cms/'.$cms->image);?>" alt="" class="img-fluid">
      </div>
    </div>
  </div>
</section>

<section class="conta-set-2">
  <div class="container">
    <div class="row">
      
      <div class="col-md-5">
      <div class="cont-detail-box">
        <p class="contact-detail"><span><i class="fa fa-map-marker"></i></span><?php echo $cms->address;?></p>
        <p class="contact-detail"><span><i class="fa fa-phone"></i></span> +91 <?php echo $cms->contact;?></p>
        <p class="contact-detail"><span><i class="fa fa-envelope"></i></span> <?php echo $cms->email;?> </p>
        <h5>Contribute to '100% EV adoption by 2030' mission and save our cities.</h5>
       </div>
      </div>
      <div class="col-md-2"></div>
      <div class="col-md-5">
        <h3>Drop us a line</h3>
        <form class="contac-form">
          <div class="form-group">
            <input type="text" class="form-control" id="exampleInputName" aria-describedby="nameHelp" placeholder="Name">
          </div>
          <div class="form-group">
            <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Email">
          </div>
          <div class="form-group">
            <input type="text" class="form-control" id="exampleInputPhone" aria-describedby="phoneHelp" placeholder="Phone">
          </div>
          <div class="form-group">
            <textarea class="form-control" id="exampleFormControlTextarea1" rows="4" placeholder="Your message"></textarea>
          </div>
          <button type="submit" class="btn btn-submit">Submit</button>
        </form>
      </div>
      
    </div>
  </div>
</section>
<style>
    
    .conta-set-2 {
    background-color: #e6e8ee;
}
body {
    font-family: 'Outfit', Sans-Serif;
}
.contact-detail {
   
   
    font-size: 16px;
    
}

.btn-submit {
    color: #fff;
    background-color: #00A76D;
     border-color:#00A76D;
    font-weight: 600;
    font-size: 18px;
    padding: 8px 57px;
    border-radius: 85px;
}
.contac-form .form-control {
    display: block;
    width: 100%;
    height: calc(2em + 0.75rem + 2px);
    padding: 10px 10px;
    font-size: 1rem;
    font-weight: 400;
    line-height: 1.5;
    color: #495057;
    background-color: #fff;
    background-clip: padding-box;
    border: 0px solid #b6c5d5;
    border-radius: 8px;
    transition: border-color .15s ease-in-out, box-shadow .15s ease-in-out;
}
</style>