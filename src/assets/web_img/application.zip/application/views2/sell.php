

<section class="sell-landi-set-1">
  <div class="container">
    <div class="row">
      <div class="col-md-1"></div>
      <div class="col-md-10 text-center">
        <h3>Sell your used electric 2 wheeler in <br/>3 simple steps</h3>
        <div class="sell-steps">
           <ul>
             <li>
               <div class="icon-box"><img src="<?php echo base_url('images/land01.png');?>" alt=""></div>
               <p>List your EV with a fair price tag and all required details</p>
             </li>
              <li>
               <div class="icon-box"><img src="<?php echo base_url('images/land02.png');?>" alt=""></div>
               <p>Recieve the contact details of the interested buyers from us</p>
             </li>
              <li>
               <div class="icon-box"><img src="<?php echo base_url('images/land03.png');?>" alt=""></div>
               <p>Contact the interested buyers, close the deal and deliver the EV</p>
             </li>
           </ul>
           <div class="arrow-la-1"><img src="<?php echo base_url('images/arrow-la.png');?>" alt=""></div>
           <div class="arrow-la-2"><img src="<?php echo base_url('images/arrow-la.png');?>" alt=""></div>
        </div>
          
        
         
        <div class="clearfix"></div> 
        <img src="<?php echo base_url('images/land04.png');?>" alt="" class="sell-landi-car">
        <h4>Contribute to our mission to achieve 100% green transportation by end of 2030 
</h4>
      </div>
      <div class="col-md-1"></div>
      <div class="col-md-12 mb-5 text-center">
            <button class="btn btn-green"><a href="<?php echo base_url('vendor/regisration');?>">Start Selling your EV</button></a>
       </div>
    </div>
  </div>
</section>

<style>
    .sell-steps ul li p {
    text-align: center;
    color: #000000;
    font-size: 18px;
    width: 63%;
    margin: 0px auto;
}
.btn-blu-2 {
    color: #fff;
    font-size: 18px;
    padding: 8px 15px;
    background-color: #00a76d;
    border: 0px solid #023591;
    border-radius: 25px;
    font-family: 'Outfit', Sans-Serif;
    text-align: center;
    width: 287px;
    font-weight : 400;
}
a {
    color: #ffffff;
    text-decoration: none;
    background-color: transparent;
}
a:hover {
    color: #ffffff;
    
}


</style>