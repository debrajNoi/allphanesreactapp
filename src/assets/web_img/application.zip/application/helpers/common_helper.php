<?php

if ( !defined( 'BASEPATH' ) )exit( 'No direct script access allowed' );



// return translation

function get_candidate_name_by_cand_id($id){

	$ci = & get_instance();
	$ci->load->database();
	// $sql = 'SELECT * FROM `users` where `id`='.$id;		        	

	// $query = $ci->db->query($sql);

	$qry = $ci->db->get_where('job_leads', ['id'=>$id]);

	if($qry->num_rows() > 0){
		$res = $qry->row();
		return $res->no_of_intt_can;
	}
	else{
		return 'Not Available.';
	}

}


// Get job name
function get_job_name_by_job_id($id){

	$ci = & get_instance();
	$ci->load->database();
	// $sql = 'SELECT * FROM `users` where `id`='.$id;		        	

	// $query = $ci->db->query($sql);

	$qry = $ci->db->get_where('moderator_jobs', ['job_id'=>$id]);

	if($qry->num_rows() > 0){
		$res = $qry->row();
		return $res->name;
	}
	else{
		return 'Not Available.';
	}

}


// Get job location
function get_job_location_by_job_id($id){

	$ci = & get_instance();
	$ci->load->database();
	// $sql = 'SELECT * FROM `users` where `id`='.$id;		        	

	// $query = $ci->db->query($sql);

	$qry = $ci->db->get_where('moderator_jobs', ['job_id'=>$id]);

	if($qry->num_rows() > 0){
		$res = $qry->row();
		return $res->location;
	}
	else{
		return 'Not Available.';
	}

}



// To get the code from table 
function get_table_value_by_id($table, $id, $field){

	$ci = & get_instance();
	$ci->load->database();

	$ci->db->select($field);
	$ci->db->from($table);
	$ci->db->where('id', $id);
	$qry = $ci->db->get();

	if($qry->num_rows() > 0){
		$res = $qry->row()->$field;
		return $res;
	}
	else{
		return '';
	}

}


// To get the code from table 
function get_page_section($page_id, $title){
    

	$ci = & get_instance();
	$ci->load->database();

	$ci->db->select("*");
	$ci->db->from('cms');
	$ci->db->where('parent', $page_id);
	if($title){
	    $ci->db->like('title', $title);
	}
	
	$qry = $ci->db->get();
	
	return $qry->result();

}


// To get the code from table 
function get_meta_details($page_name){

	$ci = & get_instance();
	$ci->load->database();

	$ci->db->select("*");
	$ci->db->from('cms');
	$ci->db->where('page_name', $page_name);
// 	$ci->db->like('title', $title);
	
	$qry = $ci->db->get();
	
	return $qry->result();

}