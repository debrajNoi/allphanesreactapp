<section class="conta-set-1">

  <div class="container">

    <div class="row">

      <div class="col-md-7">

        <h3><?php echo $cms->title;?></h3>

        <p><?php echo base64_decode($cms->content);?></p>

      </div>

      <div class="col-md-1"></div>

      <div class="col-md-4">

        <img src="<?php echo base_url('uploads/cms/'.$cms->image);?>" alt="<?php echo $cms->img_alt;?>" class="img-fluid">

      </div>

    </div>

  </div>

</section>



<section class="conta-set-2">

  <div class="container">

    <div class="row">

      

      <div class="col-md-7">

      <div class="cont-detail-box">

        <p class="contact-detail"><span><i class="fa fa-map-marker"></i></span><?php echo $cms->address;?></p>

        <p class="contact-detail"><span><i class="fa fa-whatsapp"></i></span> +91 <?php echo $cms->whatsapp_no;?></p>

        <p class="contact-detail"><span><i class="fa fa-phone"></i></span> +91 <?php echo $cms->contact;?></p>

        <p class="contact-detail"><span><i class="fa fa-envelope"></i></span> <?php echo $cms->email;?> </p>

        <h5>Contribute to '100% EV adoption by 2030' mission and save our cities.</h5>

       </div>

      </div>

     

      <div class="col-md-5">

          <?php

          	if($this->session->flashdata('success')){?>

          	<div class="alert alert-success"><?php echo $this->session->flashdata('success');?></div>

          	<?php }?>

        <h3>Drop us a line</h3>

        <form class="contac-form" method="post">

          <div class="form-group">

            <input type="text" class="form-control" id="name" name="name" aria-describedby="nameHelp" placeholder="Name" required>

          </div>

          <div class="form-group">

            <input type="email" class="form-control" id="email" name="email" aria-describedby="emailHelp" placeholder="Email" required>

          </div>

          <div class="form-group">

            <input type="text" class="form-control" id="mobile" name="mobile" aria-describedby="phoneHelp" placeholder="Phone" required>

          </div>

          <div class="form-group">

            <textarea class="form-control" id="message" name="message" rows="4" placeholder="Your message" required></textarea>

          </div>

          <button type="submit" class="btn btn-submit btn_main">Submit</button>

        </form>

      </div>

      

    </div>

  </div>

</section>

<style>

    

.conta-set-2 {

    background-color: #e6e8ee;

}

body {

    font-family: 'Outfit', Sans-Serif;

}

.contact-detail {

   

   

    font-size: 16px;

    

}



.btn-submit {

    color: #fff;

    background-color: #00A76D;

     border-color:#00A76D;

    font-weight: 400;

    font-size: 18px;

    padding: 8px 57px;

    border-radius: 85px;

}

.contac-form .form-control {

    display: block;

    width: 100%;

    height: calc(2em + 0.75rem + 2px);

    padding: 10px 10px;

    font-size: 1rem;

    font-weight: 400;

    line-height: 1.5;

    color: #495057;

    background-color: #fff;

    background-clip: padding-box;

    border: 0px solid #b6c5d5;

    border-radius: 8px;

    transition: border-color .15s ease-in-out, box-shadow .15s ease-in-out;

}

</style>

<script src="//ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

<script>

    $( document ).ready(function() {

    setTimeout(function(){ $('.alert').css('display','none'); }, 10000);



});

</script>