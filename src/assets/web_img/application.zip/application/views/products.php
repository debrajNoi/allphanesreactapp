<section>
  <div class="container-fluid">
  <div class="banner-section">
      </div>
</section>

<section><br/><br/>
<center><h2 style="font-weight: 600;font-family: outfit;">
   Choose your dream electric scooter from certified dealers.
<br/>Buy with peace of mind.</h2></center>  <br/><br/>

  <div class="container-fluid brand-sec">
    <div class="row">
        
	<?php if(!empty($product_list)){?>
	<?php
	foreach($product_list as $pro){?>
     	 <div class="col-lg-4 col-md-6 mb-3">
       <div class="skt-slid-box">
        <div class="">
          <img src="<?php echo base_url('uploads/products/'.$pro->side_view1);?>" class="img-fluid img-thumbnail" style="height: 289px; width: 100%;
"></div>

        </div>
       <table class="cont-table2">
            <tr>
                     <td>
                       <p class="pe-taxt-2-b"><span><?php echo $pro->brand;?></span> &nbsp; | &nbsp; <span>INR <?php echo $pro->price;?></span> </p>

                     </td>
                     <!--<td><a href="<?php echo base_url('product-details?id='.base64_encode($pro->id));?>"><button class="btn btn-view-more2">View More</button></a></td>-->
                     <td><a href="<?php echo base_url('product-details/'.$pro->slug);?>"><button class="btn btn-view-more2">View More</button></a></td>
                   </tr>
                 </table>
         
      </div>
	  
	  <?php }}else{
	    echo ' <div style="margin-top:16px"; class="col-md-3 col-sm-3 col-lg-3 col-xs-6"><div class="alert alert-danger">No data found.</div></div>';
	  }?>
      
    
      
      
      </div>
    </div>
  </div>
</section>


 <br/><br/><br/><br/>

 <section class="partner-sty01">
   <div class="partner-sec01 container">
     <p>Join the Green Transportation Global Movement.
Buy and encourage others to buy EV.  </p>
    
   </div>
 </section>
 
 <style>
     .btn-view-more2 {
    color: #00a76d;
    font-size: 15px;
    padding: 0px 15px;
    background-color: #00a76d00;
    border: 0px solid #023591;
    border-radius: 25px;
    font-family: 'Outfit', Sans-Serif;
    font-weight: 600;
    letter-spacing: 1px;
    outline: none;
}
.skt-slid-box {
    background-color: #ededed;
    padding: 0px 0pxpx;
    border-radius: 10px;
    overflow: hidden;
}
.mb-3, .my-3 {
    margin-bottom: 2rem!important;
}
.btn.focus, .btn:focus {
    outline: 0;
    box-shadow: 0 0 0 0rem rgb(0 123 255 / 25%);
}
 </style>
