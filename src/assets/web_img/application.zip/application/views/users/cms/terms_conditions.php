<style>
.fa-close{
position: absolute;
    margin-top: -9px;
    color: red;
    font-size: 16px;
	cursor:pointer;
	}
	</style>
<main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-edit"></i>  Terms & Conditions </h1>
        </div>
       
      </div>
      <div class="row">
        <div class="col-md-10">
		<?php  if($this->session->flashdata('success')){?>
  		<div class="alert alert-success"><?php echo $this->session->flashdata('success');?></div>
		<?php }?>
  <div class="tile">
    <form class="form-horizontal" method="post" action="" enctype="multipart/form-data">
      <div class="tile-body">
        
        
		
		<div class="form-group row">
          <label class="control-label col-md-3">Content</label>
          <div class="col-md-8">
           <textarea name="content" id="content" class="ckeditor"><?php echo base64_decode($cms->content);?></textarea>
          </div>
        </div>
		
		
		
		
	
        
      </div>
      <div class="tile-footer">
        <div class="row">
          <div class="col-md-8 col-md-offset-3">
            <button class="btn btn-primary" type="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>Update</button>
        </div>
        </div>
      </div>
	 
    </form>
  </div>
</div>
      </div>
    </main>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>	

	<script>





function readURL(input) {
  if (input.files && input.files[0]) {
    var reader = new FileReader();
    
    reader.onload = function(e) {
      $('#blah').attr('src', e.target.result);
    }
    
    reader.readAsDataURL(input.files[0]); // convert to base64 string
  }
}

$("#imgInp").change(function() {
  readURL(this);
});


function HeadreadURL(input) {
  if (input.files && input.files[0]) {
    var reader = new FileReader();
    
    reader.onload = function(e) {
      $('#blah1').attr('src', e.target.result);
    }
    
    reader.readAsDataURL(input.files[0]); // convert to base64 string
  }
}

$("#imgInp1").change(function() {
  HeadreadURL(this);
});


<?php
if($this->session->flashdata('error')){?>
   swal('Oops!','<?php echo $this->session->flashdata('error');?>','error');
<?php }

if($this->session->flashdata('success')){?>
   swal('success!','<?php echo $this->session->flashdata('success');?>','success');
<?php }?>


function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}

</script>

<script>
    function UploadType(file_type){
        if(file_type=='video'){
            $('#UploadText').html('Embeded Video Url ');
            $('#InputTool').html('<input type="text" class="form-control col-md-8" name="video_url" Placeholder="Embeded Video Url" value="<?php echo $cms->video_url;?>" required>');
        }
        
         if(file_type=='image'){
            $('#UploadText').html('Upload Image ');
            $('#InputTool').html('<input type="file"  name="image"  required><input type="hidden"  name="old_image"  value="<?php echo @$cms->old_image;?>">');
        }
        
    }

</script>