<main class="app-content">
<style>
.fa{
cursor:pointer;
}
</style>
<div class="app-title">
  <div>
    <h1><i class="fa fa-plus"></i> Add Banner</h1>
  </div>
  <ul class="app-breadcrumb breadcrumb">
    <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
    <li class="breadcrumb-item">Admin</li>
    <li class="breadcrumb-item"><a href="#">Add Banner</a></li>
  </ul>
</div>
<div class="row">

<div class="col-md-8">

  <div class="tile">
 
 
    <form class="form-horizontal" method="post" action="<?php echo base_url('Admin/banner_add');?>" enctype="multipart/form-data">
      <div class="tile-body">
	  
	  <div class="form-group row">
          <label class="control-label col-md-3">Title</label>
           <div class="col-md-8">
            <input class="form-control " type="text" name="title" placeholder="Title"  required>
          </div>
        </div>
		
		
		
		
		
		<div class="form-group row">
          <label class="control-label col-md-3">Description </label>
           <div class="col-md-8">
            <textarea name="description" class="form-control" required></textarea>
          </div>
        </div>
		
		<div class="form-group row">
          <label class="control-label col-md-3">Upload Image </label>
           <div class="col-md-8">
          <input type="file" name="image" />
          </div>
        </div>
	
      </div>
      <div class="tile-footer" align="right">
        <button class="btn btn-primary" type="submit" name="submit">Submit</button>
      </div>
   
  </div>
</div>




</main>

<script type="text/javascript">
$(document).ready(function(){
    $('#select_all').on('click',function(){
        if(this.checked){
            $('.checkbox').each(function(){
                this.checked = true;
            });
        }else{
             $('.checkbox').each(function(){
                this.checked = false;
            });
        }
    });
    
    $('.checkbox').on('click',function(){
        if($('.checkbox:checked').length == $('.checkbox').length){
            $('#select_all').prop('checked',true);
        }else{
            $('#select_all').prop('checked',false);
        }
    });
	
	
	
	
	
	 $('#item_select').on('click',function(){
        if(this.checked){
            $('.items').each(function(){
                this.checked = true;
            });
        }else{
             $('.items').each(function(){
                this.checked = false;
            });
        }
    });
    
    $('.items').on('click',function(){
        if($('.items:checked').length == $('.items').length){
            $('#item_select').prop('checked',true);
        }else{
            $('#item_select').prop('checked',false);
        }
    });
});
</script>
