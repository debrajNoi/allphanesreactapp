<!DOCTYPE html>
<html lang="en">
<?php
   $user_info = $this->session->userdata('admin_name');
  ?>
  <head>
    <meta name="description" content="Vali is a responsive and free admin theme built with Bootstrap 4, SASS and PUG.js. It's fully customizable and modular.">
    <!-- Twitter meta-->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:site" content="@pratikborsadiya">
    <meta property="twitter:creator" content="@pratikborsadiya">
    <!-- Open Graph Meta-->
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="Vali Admin">
    <meta property="og:title" content="Vali - Free Bootstrap 4 admin theme">
    <meta property="og:url" content="http://pratikborsadiya.in/blog/vali-admin">
    <meta property="og:image" content="http://pratikborsadiya.in/blog/vali-admin/hero-social.png">
    <meta property="og:description" content="Vali is a responsive and free admin theme built with Bootstrap 4, SASS and PUG.js. It's fully customizable and modular.">
    <title>EV Dreamz Admin Panel</title>
    <link rel="icon" href="<?php echo base_url('images/Favicon.png');?>" type="image/png" sizes="16x16">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="<?=base_url()?>assets/admin/css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="<?php echo base_url() ?>assets/css/jquery-ui.css" rel="stylesheet" type="text/css" />
	
	<link href="<?php echo base_url() ?>assets/css/redactor.css" rel="stylesheet" type="text/css" />
	
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="<?php echo base_url('assets/js/jQuery.tagify.min.js');?>"></script>
		 <link href="<?php echo base_url('assets/css/tagify.css');?>" rel="stylesheet" type="text/css" />
		 
    
  </head>
  <body class="app sidebar-mini rtl" >
    <!-- Navbar-->
    <header class="app-header"><a class="app-header__logo" href=""><img src="<?php echo base_url('images/LOGGO.png')?>" style="width:165px;"></a>
      <!-- Sidebar toggle button--><a class="app-sidebar__toggle" href="#" data-toggle="sidebar" aria-label="Hide Sidebar"></a>
      <!-- Navbar Right Menu-->
      <ul class="app-nav">
        <!-- User Menu-->
        <li class="dropdown"><a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Open Profile Menu" style="color: #212529;font-size: 20px;"><?php echo @$user_info;?> 
	&nbsp;<img src="https://creationanddevelopment.com/ecar/images/my_account.png" alt="HTML tutorial" style="width:31px;height:28px;"></a>
          <ul class="dropdown-menu settings-menu dropdown-menu-right">
            
            <li><a class="dropdown-item" href="<?=base_url("admin/profile")?>"> Profile</a></li>
			<li><a class="dropdown-item" href="<?=base_url("admin/change_password")?>"> Change Password</a></li>
            <li><a class="dropdown-item" href="<?=base_url("admin/logout")?>"> Logout</a></li>
          </ul>
        </li>
      </ul>
    </header>
    <style>
        
        .app-header {
    padding-right: 30px;
    background-color: #ffffff;
}
a:hover {
    color: #004a43;
    text-decoration: auto;
}
    </style>
	