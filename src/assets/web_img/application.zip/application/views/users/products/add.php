<main class="app-content">
<style>
.fa{
cursor:pointer;
}
.img-thumbnail{
    border: 2px solid #3f51b5;
	    height: 85px;
    width: 100px;
 }
 .lbl{
     margin-left: 56px;
}
</style>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<div class="app-title">
  <div>
    <h1><i class="fa fa-plus"></i> Add Product</h1>
  </div>
  <ul class="app-breadcrumb breadcrumb">
    <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
    <li class="breadcrumb-item">Admin</li>
    <li class="breadcrumb-item"><a href="#">Add Product</a></li>
  </ul>
</div>

<section>
  <div class="scooter-upload">
    <div class=" container">
      <div class="row">
        
        <form method="post"  class="row" enctype="multipart/form-data">
          <div class="col-md-5">
            <div class="">
              <div class="row">
                
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Year</label>
                    <input type="text" class="form-control date-own" id="year" name="year" required placeholder="Year">
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Make/Brand</label>
                    <input type="text" class="form-control" id="brand" name="brand" placeholder="Brand/Company/Shop Name" required>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Model</label>
                    <input type="text" class="form-control" name="model" id="model" placeholder="Model" required>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Socket Type</label>
                    <input type="text" class="form-control" name="socket_type" id="socket_type" placeholder="Socket Type" required>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Battery Type</label>
                    <div class="select-style">
                      <select class="form-control" name="battery_type" required>
                        <option value="">Select</option>
                        <option value="Lead acid">Lead acid </option>
                        <option value="Lithium ion">Lithium ion</option>
                       
                      </select>
                    </div>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Motor Type</label>
                    <div class="select-style">
                      <select class="form-control" name="motor_type" required>
                        <option value="">Select </option>
                        <option value="Brushed">Brushed</option>
                        <option value="Brushless">Brushless</option>
                        <option value="Hubless">Hubless</option>
                        <option value="Hub">Hub</option>
                      </select>
                    </div>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Range</label>
                    <input type="text" class="form-control" id="range" name="range" required placeholder="Range">
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Charging Time</label>
                    <input type="text" class="form-control" id="charging_time" name="charging_time" placeholder="Charging Time">
                  </div>
                </div>
				
				<div class="col-md-12">
                  <div class="form-group">
                    <label>Price</label>
                    <input type="text" class="form-control" name="price" id="price" required placeholder="Price">
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-2"></div>

          <div class="col-md-5">
            <div class="">
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group form-group-sm">
                    <label>Starting</label>
                    <div class="select-style">
                      <select class="form-control" name="starting" required>
                        <option value="">Select</option>
                        <option value="Kick"> Kick</option>
                       
                      </select>
                    </div>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Safety features</label>
                    <input type="text" class="form-control" id="safety_features" name="safety_features" required placeholder="Safety features">
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Sensors</label>
                    <input type="text" class="form-control" id="sensors" name="sensors" required placeholder="Sensors">
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Chassis and Suspension</label>
                    <input type="text" class="form-control" id="chassis_suspension" name="chassis_suspension" required placeholder="Chassis and Suspension">
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Tyres and Wheels</label>
                    <input type="text" class="form-control" id="tyres" name="tyres" required placeholder="Tyres and Wheels">
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Brakes</label>
                    <div class="select-style">
                      <select class="form-control" name="break_type" required>
                        <option value="">Select</option>
                        <option value="Cable Disk">Cable Disk</option>
                        <option value="Hydraulic">Hydraulic</option>
                        <option value="Semi-hydraulic">Semi-hydraulic</option>
                        <option value="Drum">Drum</option>
                      </select>
                    </div>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Enter Standard Warranty</label>
                    <div class="select-style">
                      <select name="warranty" class="form-control" required>
                        <option value="">Select</option>
                        <option value="1 Year">1 Year</option>
                        <option value="2 Years">2 Years</option>
                        <option value="3 Years">3 Years</option>
                       
                      </select>
                    </div>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Location</label>
					<select name="location" class="form-control" required>
					<option value="">Select</option>
					<?php
					$sql_cities=$this->db->query('SELECT * FROM cities ORDER BY city ASC');
					$cities=$sql_cities->result();
					foreach($cities as $city){?>
                   <option value="<?php echo $city->city;?>"><?php echo $city->city;?></option>
					<?php }?>
					</select>
                  </div>
                </div>
				
				<div class="col-md-12">
                  <div class="form-group">
                    <label>Description</label>
					<textarea name="description" required style="width:100%;"></textarea>
                  </div>
                </div>
                
              </div>
            </div>
          </div>
          <div class="col-md-12 mb-4">
            <h4 class="text-up-ph-1">Upload Photos</h4>
            <p class="text-up-ph-2">Upload phoes that showcase your EV from front, back, sides. Use a couple of close-ups for best results.
              Upload only .JPEG and .PNG files.</p>
          </div>
          <div class="col-md-4 mb-3">
            <div class="up-img-box">
              <div class="img-box">
			 <img id="FrontFrame" src="<?php echo base_url('images/front.jpg');?>" class="img-thumbnail" style="width:63%; height:169px;"/>
			  </div>
              <p>
			  <label for="front_view" class="btn lbl">Front view</label>
			  <input id="front_view" style="visibility:hidden;" name="front_view"  type="file" onchange="FrontView()" accept="image/jpg, image/jpeg,image/png">
			  </p>
            </div>
          </div>
          <div class="col-md-4 mb-3">
            <div class="up-img-box">
              <div class="img-box">
			  <img id="SideFrame1" src="<?php echo base_url('images/sco-02.png');?>" class="img-thumbnail" style="width:63%; height:169px;"/>
			  </div>
              <p> <label for="side_view1" class="btn lbl">Side view 1</label>
			   <input id="side_view1" style="visibility:hidden;" type="file" name="side_view1"  onchange="SideView1()" accept="image/jpg, image/jpeg,image/png">
			  </p>
            </div>
          </div>
          <div class="col-md-4 mb-3">
            <div class="up-img-box">
              <div class="img-box">
			   <img id="SideFrame2" src="<?php echo base_url('images/03.png');?>" class="img-thumbnail" style="width:63%; height:169px;"/>
			  </div>
             <p> <label for="side_view2" class="btn lbl">Side view 2</label>
			   <input id="side_view2" style="visibility:hidden;" type="file" name="side_view2"  onchange="SideView2()" accept="image/jpg, image/jpeg,image/png">
			  </p>
            </div>
          </div>
		  
          <div class="col-md-4 mb-3">
            <div class="up-img-box">
              <div class="img-box">
			   <img id="SideFrame3" src="<?php echo base_url('images/rear.jpg');?>" class="img-thumbnail" style="width:63%; height:169px;"/>
			  </div>
             <p> <label for="rear_view" class="btn lbl">Rear view</label>
			   <input id="rear_view" style="visibility:hidden;" type="file" name="rear_view"  onchange="RearView()" accept="image/jpg, image/jpeg,image/png">
			  </p>
            </div>
          </div>
		  
          <div class="col-md-4 mb-3">
            <div class="up-img-box">
              <div class="img-box">
			   <img id="SideFrame4" src="<?php echo base_url('images/closeup1.jpg');?>" class="img-thumbnail" style="width:63%; height:169px;"/>
			  </div>
             <p> <label for="close_up1" class="btn lbl">Close-up 1</label>
			   <input id="close_up1" style="visibility:hidden;" type="file" name="close_up1"  onchange="CloseUp1()" accept="image/jpg, image/jpeg,image/png">
			  </p>
            </div>
          </div>
		  
          <div class="col-md-4 mb-3">
            <div class="up-img-box">
              <div class="img-box">
			   <img id="SideFrame5" src="<?php echo base_url('images/closeup2.jpg');?>" class="img-thumbnail" style="width:63%; height:169px;"/>
			  </div>
             <p> <label for="close_up2" class="btn lbl">Close-up 2</label>
			   <input id="close_up2" style="visibility:hidden;" type="file" name="close_up2"  onchange="CloseUp2()" accept="image/jpg, image/jpeg,image/png">
			  </p>
            </div>
          </div>
          <div class="col-md-12" align="right"><hr /> <button type="submit" class=" btn btn-primary signup text-left" style="display:inline-block;">Submit</button>
            <!--<p class="repli-mes">Thank you for submitting your EV. We will review it and if all is in good shape, it will be publised within 1 working day. Or else, we will get in touch with you for required information.</p>-->
          </div>
        </form>
		
		
      </div>
    </div>
    <div class="clearfix"></div>
  </div>
</section>



</main>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/js/bootstrap-datepicker.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/css/bootstrap-datepicker.css" rel="stylesheet"/>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<script>
<?php
if($this->session->flashdata('success')){?>
swal('Success','<?php echo $this->session->flashdata('success');?>','success');
<?php }?>
function FrontView() {
    FrontFrame.src=URL.createObjectURL(event.target.files[0]);
}

function SideView1() {
    SideFrame1.src=URL.createObjectURL(event.target.files[0]);
}

function SideView2() {
    SideFrame2.src=URL.createObjectURL(event.target.files[0]);
}

function RearView() {
    SideFrame3.src=URL.createObjectURL(event.target.files[0]);
}

function CloseUp1() {
    SideFrame4.src=URL.createObjectURL(event.target.files[0]);
}

function CloseUp2() {
    SideFrame5.src=URL.createObjectURL(event.target.files[0]);
}

$('.date-own').datepicker({
         format: " yyyy", // Notice the Extra space at the beginning
         viewMode: "years", 
       minViewMode: "years"
       });
</script>
