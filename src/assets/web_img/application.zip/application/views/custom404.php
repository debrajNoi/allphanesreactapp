<!doctype html>
<html>
 <head>
   <title>404 Page Not Found</title>
   <style>
   body{
/*
     width: 99%;
     height: 100%;
*/
     background-color: white;
     color: black;
      font-family: 'Outfit', Sans-Serif;
	   margin: 0;
   }

   h2{
    font-size: 28px;
    margin-bottom: 35px;
    font-weight: 300;
	   text-align: center;
	
   }
/*
   a{
background-color: #fb4949 !important;
    color: #ffffff !important;
    border: none !important;
    font-size: 20px !important;
    border-radius: 25px;
    font-family: 'Outfit', Sans-Serif;
    padding: 10px;
    text-decoration: none;
    margin: auto;
    display: block;
    width: 230px;
    text-align: center;
   }
*/
	   
	   img{width: 100%; max-width:560px;}
   </style>
 </head>
 <body>
   <div style="position:absolute;width:100%;height:100%;display: flex; align-content: center; align-items: center">
<div style="margin: auto;max-width: 560px;text-align: center">
	
<!--
	   <img src="<?php echo base_url('images/404_image_.png');?>" alt="" class="img-fluid bann-img">
	    <h2>Whoops! :(</h2>
	   <p style="text-align: center; margin:40px 0">We can’t seem to find the page that you’re looking for</p>
     <a href='<?= base_url(); ?>' >Back to Homepage</a>
	   
-->
	
	  
<!--
	    <h2>Whoops! :(</h2>
	   <p style="text-align: center; margin:40px 0">We can’t seem to find the page that you’re looking for</p>
-->
     <a href='<?= base_url(); ?>' ><img src="<?php echo base_url('images/404_image_2.png');?>" alt="404_image_2" class="img-fluid bann-img"></a>
	   
	
	   
	   </div>
	 
   </div>
 </body>
</html>