<style>
    .privacy-policy h4 {
        color: #00a66d;
        margin-top: 100px;
        font-size: 28px;
        font-weight: 700;
        margin-bottom: 20px;
    }
    .terms a{
        color: #00A76D;
    }
    .terms a:hover{
        text-decoration: underline;
    }
</style>
<section class="privacy-policy">
  <div class="container">
    <div class="row">
        
      <div class="col-md-12 terms">
        <h4><?php echo $cms->title;?></h4>
        <?php echo base64_decode($cms->content);?>
      </div>
      
    </div>
  </div>
</section>
