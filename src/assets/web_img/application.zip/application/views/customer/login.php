  <style>
    .lbl{
      color:#222222 !important;
    }
    .signin{
      background-color: #3f51b5 !important;
      border: 2px solid #3f51b5 !important;
      width:100%;
  	}

    .login-content{
      display: flex; 
      justify-content: center; 
      background-color: #e6e8ee;
    }
    .login-box{
      background-color: #ffffff; 
      border-radius: 25px; 
      position: relative; 
      margin: 80px; 
      padding: 40px;
      width: 500px !important;
    }
    .form-control{
      border: 1px solid #00a76d !important;
    }
  </style>
  <!-- <body style="background-color:#e6e8ee;"> -->
    <section class="" >
      <div class="cover"></div>
    </section>

    <section class="login-content">

      <div class="login-box">
        <form class="login-form" action="" method="post">
		
		      <div class="form-group" align="center">
		        <!-- <img style="margin-top: 50px; width:55%;" src="<?php echo base_url('images/LOGGO.png')?>" > -->
	          <p></p>
            <h2 style="font-size: 20px;font-family: 'Outfit', Sans-Serif;margin: -12px -1px 0px 7px;">
              User Login
            </h2>
		      </div>
		
          <div class="form-group">
            <label class="control-label lbl" style="font-family: 'Outfit', Sans-Serif;font-size: 18px;">Email</label>
            <input class="form-control " type="text" name="email" id="LoginEmail" placeholder="Email" autofocus >
          </div>

          <div class="form-group">
            <label class="control-label lbl" style="font-family: 'Outfit', Sans-Serif; font-size: 18px;">Password</label>
            <input class="form-control" type="password" name="password" placeholder="Password">
          </div>
		  
          <div class="form-group">
            <button style="background-color: #222222;color:white;height: 50px;font-size: 25px;font-family: 'Outfit', Sans-Serif;" class="btn  btn-block signin" type="submit"><i></i>Login</button>			
            <br/>  
        
            <center>	
              <p>
                <a href="<?php echo base_url('user/forgot_password');?>" style="font-family: 'Outfit', Sans-Serif;font-size: 16px;color: #00a76d;">
                  Forgot password ? Click here
                </a>
              </p>  
            </center> 
      
            <center>	
              <p style="margin-top: -16px;">
                <a href="<?=base_url('users/registration')?>" style="font-family: 'Outfit', Sans-Serif;font-size: 16px;color: #00a76d;">
                  Don't have an Account ? Register here
                </a>
              </p>
            </center>
          </div>
		
        </form>

      </div>

    </section>
    
    <!-- Essential javascripts for application to work-->
    <script src="<?php echo base_url()?>assets/admin/js/jquery-3.2.1.min.js"></script>
    <script src="<?php echo base_url()?>assets/admin/js/popper.min.js"></script>
    <script src="<?php echo base_url()?>assets/admin/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url()?>assets/admin/js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="<?php echo base_url()?>assets/admin/js/plugins/pace.min.js"></script>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    <script type="text/javascript">
      // Login Page Flipbox control
      $('.login-content [data-toggle="flip"]').click(function() {
      	$('.login-box').toggleClass('flipped');
      	return false;
      });
	 
    <?php if($this->session->flashdata('error')){ ?>
        swal('','<?php echo $this->session->flashdata('error');?>','error');
    <?php } ?>
	  
    </script>
