<style type="text/css">
  .app-content{
      display: flex; 
      justify-content: center; 
      background-color: #e6e8ee;
    }
    .form-control{
      border: 1px solid #00a76d !important;
    }

    .cng-password{
      background-color: #ffffff; 
      border-radius: 25px; 
      position: relative; 
      margin: 80px; 
      padding: 40px;
    }

    .btn-update-color{
      background-color: #00A76D !important;
      color: #ffffff !important;
    }
    .btn-update-color :hover{
      background-color: #00A76D !important;
    }
</style>

<!-- <main class="app-content" style="margin-left: 0px !important; background-color: white !important;"> -->
<main class="app-content">
  <div class="row cng-password">
    <div class="col-md-12">
      <div class="tile">
        <div>
          <h3 class="text-center"> Change User Password</h1>
        </div>
        <form class="form-horizontal" method="post" action="" enctype="multipart/form-data">
          <div class="tile-body">
          <br/><br/>
          <div class="form-group row">
            <label class="control-label col-md-5">Current Password</label>
            <div class="col-md-7">
              <input class="form-control col-md-12" type="text" name="old_password" placeholder="Old Password" required>
            </div>
          </div>
          <div class="form-group row">
            <label class="control-label col-md-5">New Password</label>
            <div class="col-md-7">
              <input class="form-control col-md-12" type="text" name="new_password" placeholder="New Password" required>
            </div>
          </div>
          <div class="form-group row">
            <label class="control-label col-md-5">Confirm Password</label>
            <div class="col-md-7">
              <input class="form-control col-md-12" type="text" name="confirm_password" placeholder="Confirm Password" required>
            </div>
          </div>
		      <div class="tile-footer mt-5">
            <div class="row">
              <div class="col-md-12 text-center">
                <button class="btn btn-update-color" type="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>Update</button>
                <a class="btn btn-secondary" href="<?=base_url('Admin/dashboard')?>"><i class="fa fa-fw fa-lg fa-times-circle"></i>Back</a> </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</main>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script>
function readURL(input) {
  if (input.files && input.files[0]) {
    var reader = new FileReader();
    
    reader.onload = function(e) {
      $('#blah').attr('src', e.target.result);
    }
    
    reader.readAsDataURL(input.files[0]); // convert to base64 string
  }
}

$("#imgInp").change(function() {
  readURL(this);
});


<?php
if($this->session->flashdata('error')){?>
   swal('Oops!','<?php echo $this->session->flashdata('error');?>','error');
<?php }

if($this->session->flashdata('success')){?>
   swal('success!','<?php echo $this->session->flashdata('success');?>','success');
<?php }?>



function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}
</script>