<style>

.fa-android{

color:red;

}

</style>

<div class="app-sidebar__overlay" data-toggle="sidebar"></div>

    <aside class="app-sidebar">

  <?php  $user_type=$this->session->userdata('user_type');

 $cont= $this->router->fetch_class();

  $method=$this->router->fetch_method();

  //echo $method;

  

  ?>

      <ul class="app-menu">

        <li><a class="app-menu__item" href="<?=base_url()?>customer/dashboard"><i class="app-menu__icon fa fa-dashboard"></i><span class="app-menu__label">Dashboard</span></a></li>

		

		<li class="treeview <?php if($method=='product_list' || $method=='product_add' || $method=='product_edit' ){?> is-expanded <?php }?>"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-product-hunt"></i><span class="app-menu__label"> Manage Products</span><i class="treeview-indicator fa fa-angle-right"></i></a>

          <ul class="treeview-menu">


		  <li><a class="treeview-item" href="<?=base_url('customer/product_list')?>"><i class="icon fa fa-list"></i>Product List</a></li>

		  <li><a class="treeview-item" href="<?=base_url('customer/product_add')?>"><i class="icon fa fa-plus"></i>Add Product</a></li>

		 </ul>

		  

		 </li> 


         <li>
            <a class="app-menu__item" href="<?=base_url()?>customer/customer_reviews">
                <i class="app-menu__icon fa fa-smile-o" aria-hidden="true"></i>
                <span class="app-menu__label">Customer reviews</span>
            </a>
        </li>
		 

		 <li><a class="app-menu__item" href="<?=base_url()?>customer/booking_requests"><i class="app-menu__icon fa fa-smile-o" aria-hidden="true"></i><span class="app-menu__label">Booking Request</span></a></li>

		   

		 

      </ul>

    </aside>

    <style>

        .app-sidebar {

    position: fixed;

    top: 0;

    bottom: 0;

    left: 0;

    padding-top: 70px;

    width: 230px;

    overflow: auto;

    z-index: 10;

    background-color: #223f8b;

    -webkit-box-shadow: 0px 8px 17px rgb(0 0 0 / 20%);

    box-shadow: 0px 8px 17px rgb(0 0 0 / 20%);

    -webkit-transition: left 0.3s ease, width 0.3s ease;

    -o-transition: left 0.3s ease, width 0.3s ease;

    transition: left 0.3s ease, width 0.3s ease;

}

    </style>