<link rel="stylesheet" type="text/css" href="<?=base_url('/css/customer_profile.css')?>" />
<style type="text/css">
  .profile-icons{
    font-size:26px; 
    margin-right: 15px; 
    margin-left: 6px;
  }
  .edit-btn{
      color: #01A86D;
  }
</style>

<main class="app-content" style="margin-left: 0px !important; background-color: white !important;">

  <!--<div class="row">-->

  <!--  <div class="col-md-12">-->

      <!-- profile section  -->
      <section id="profile">
          <div class="container mt-4">
              <!-- cards  -->
              <div class="row justify-content-center">
                  <div class="col-lg-4 col-md-6 mt-2">
                      <div class="cardx c-y">
                          <div class="card-head card-img">
                              <div class="pos-center">
                                  <img id="HotImage1" style="border-radius: 50%;" src="<?=($profile->image==''? base_url('uploads/profile/default_img_background.png'):base_url('/uploads/users/'.$profile->image))?>" width="140px" height="140px" alt="not found">
                                  <!--'https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Circle-icons-profile.svg/1024px-Circle-icons-profile.svg.png'-->
                              </div>
                          </div>
                          <div class="card-bod">
                              <!--<p><?php //print_r($profile);?></p>-->
                              <a href="javascript: void(0)" class="cl-2 text-center mt-3 edit-btn">
                                <i class="fa fa-pencil" style="color: #000" aria-hidden="true"></i> 
                                <?php if($profile->image==''){ ?>
                                  <label for="hot-image1" style="color: #01A86D !important">Upload photo</label>
                                <?php } else{ ?>
                                  <!-- <a href="<?=base_url('customer/update_photo')?>"><span class="cl-2">update photo</span></a> -->
                                  <label for="hot-image1" class="btn lbl" style="color: #01A86D !important">Update photo</label>
                                  
                                <?php } ?>
                                <input id="hot-image1" style="display:none;" type="file" name="hotImage1" onchange="hot_image1(this)" accept="image/jpg, image/jpeg,image/png">
                              </a>


                              <div class="i-verified mt-3 text-center">
                                <?php if($profile->email_verification == 1 && $profile->mobile_verified == 1){ ?>
                                <img src="<?=base_url('/assets/img/pricing/check.png')?>" width="15px" style="margin-right: 10px;">
                                <?php } else { ?>
                                <i class="fa fa-check-circle" aria-hidden="true"></i>
                                <?php } ?> 
                                <span class="cl-3"> 
                                  <?=(($profile->email_verification == 1 && $profile->mobile_verified == 1)?' Identity Verified':'Verification Required')?>
                                </span>
                              </div>
                              <div class="h-1">
                                <style type="text/css">
                                  h4.my_f{
                                    font-weight: 500;
                                    color: #111;
                                  }
                                </style>
                                  <!--<h4 class="my_f">My Favorites</h4>-->
                                  <h4 class="my_f mt-2">My Bookings</h4>
                              </div>
                          </div>
                          
                          <div class="c-foot">
                              <div class="fs-s text-center">
                                  A complete profile with your own 
                                  photo gets you more positive results in our amazing community.
                              </div>
                          </div>
                      </div>
                  </div>

                  

                  <div class="col-lg-4 col-md-6 mt-2">
                      <div class="mt-4 pl-3">
                          <div class="card-head">
                             <h3 class="mb-4"><?=($profile->name==''?'':$profile->name) ?></h3>
                             <a href="<?=base_url('customer/edit_profile/'.$profile->id);?>" class="edit-pro"><i class="fa fa-pencil cl-3 mr-1" aria-hidden="true"></i> <span class="cl-2">Edit profile</span></a>
                          </div>
                          <div class="card-bod">
                              <!-- <div class="address-det"> -->
                              <div class="">
                                  <div class="card-des fs-l">
                                      <div class="cl-3">
                                        <i class="fa fa-home text-center profile-icons" aria-hidden="true" style="font-size: 20px"></i>
                                      </div>
                                      <div>
                                        <?=($profile->city==''?'':$this->db->get_where('cities', ['id'=>$profile->city])->row()->city) ?>
                                      </div>
                                  </div>
                                  <div class="card-des fs-l">
                                      <div class="cl-3">
                                        <!-- <i class="fa fa-envelope text-center" aria-hidden="true" style="font-size: 16px"></i> -->
                                        <!-- <span class="text-center profile-icons" style="margin-left: 5px; margin-right: 4px; font-style: normal; font-size: 27px;">@ </span> -->
                                        <div class="cl-3">
                                          <i class="fas fa-at profile-icons" style="font-size: 21px"></i>
                                        </div>
                                      </div>
                                      <div><?=($profile->email==''?'':$profile->email) ?></div>
                                  </div>
                                  <div class="card-des fs-l">
                                      <div class="cl-3">
                                        <i class="fa fa-mobile text-center profile-icons" style="font-size:30px;" aria-hidden="true" style="font-size: 20px">
                                        </i>
                                      </div>
                                      <div><?=($profile->mobile==''?'':$profile->mobile) ?></div>
                                  </div>
                                  <div class="card-des fs-l">
                                      <div class="cl-3">
                                        <!-- <img src="<?php echo base_url('images/i-16.png');?>" alt="" style="width: 20%;" /> -->
                                        <i class="fa fa-map-marker profile-icons" style="" aria-hidden="true"></i>
                                      </div>
                                      <div><?=($profile->pincode==''?'':$profile->pincode) ?></div>
                                  </div>
                                  
                              </div>
                              <div style="margin-top: 30px;" class="reviews">
                                <i class="fa fa-star w-4" aria-hidden="true" style="color: #01A86D;"></i> Reviews
                              </div>
                          </div>
                          
                          <div class="c-foot mt-5">
                              <!-- <a href="#" class="mt-5 rby">Reviews by you</a> -->
                              <a href="#" class="mt-5" style="color: #111111">Reviews by you</a>
                          </div>
                      </div>
                  </div>
                  <!-- end card  -->

                  
              </div>
          </div>
          
      </section>
      <!-- end profile section  -->
      
      
      <section class="scrt-slider">
        <div class="container-fluid brand-sec">
          <!-- D -->
          <div class="row pt-4 pb-4">
              <!-- compare body  -->
              <div class="col-md-12 text-left">
                <h4 style="margin-bottom: 8px !important;">My Favorites</h4>
              </div>

              <?php foreach($products as $key => $val){ ?>
              <div class="mt-4 col-lg-3 col-md-4 col-md-3 col-sm-6 col-xs-12 popular">
                  <?php if($val['front_view'] == ""){ ?>
                  <div class="full-sec-brand">
                      <div class="image-brand-sec">
                          <img src="<?=base_url('/uploads/products/'.$val['front_view'])?>" class="img" alt="<?php echo $val['slug'];?>">
                      </div>
                  </div>
                  
                  <?php }else{ ?>
                  <div class="full-sec-brand">
                      <div class="image-brand-sec">
                          <img src="<?=base_url('/uploads/products/'.$val['front_view'])?>" alt="<?php echo $val['slug'];?>">
                      </div>
                  </div>
                  <?php } ?>
                  <div class="comp-pricing row mt-2">
                      <div class="name-price col-md-7">
                        <span><?=$val['model']?></span> | <span><?=$val['price']?></span>
                      </div>

                      <div class="viewmore col-md-5 text-right">
                          <a href="<?=base_url('product-details/'.$val['slug'])?>" class="text-right" style="color: #00a76d !important;">View More</a>
                      </div>
                  </div>
              </div>
              <?php } ?>
              <!-- end comp body  -->
          </div>
          <!-- end D  -->
        </div>        
      </section>

  <!--  </div>-->

  <!--</div>-->

</main>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<script type="text/javascript">
  function hot_image1(elements) {
    HotImage1.src=URL.createObjectURL(event.target.files[0]);
    
    let file = elements.files[0]
    const form_data = new FormData();
    form_data.append('hotImage1', file);
    
    var uid = '<?php echo $profile->id;?>';
    form_data.append('id', uid)
    
    
    fetch("<?=site_url("customer/upload_profile_image")?>", {
    method:"POST",
    body : form_data
    }).then(function(response){
    return response.json();
    }).then(function(responseData){
    // console.log
    
    // 	document.getElementById('uploaded_image').innerHTML = '<div class="alert alert-success">Image Uploaded Successfully</div> <img src="'+responseData.image_source+'" class="img-thumbnail" />';
    
    // 	document.getElementsByName('sample_image')[0].value = '';
    
    });
  }
</script>

<script>

function readURL(input) {

  if (input.files && input.files[0]) {

    var reader = new FileReader();

    

    reader.onload = function(e) {

      $('#blah').attr('src', e.target.result);

    }

    

    reader.readAsDataURL(input.files[0]); // convert to base64 string

  }

}



$("#imgInp").change(function() {

  readURL(this);

});





<?php

if($this->session->flashdata('error')){?>

   swal('Oops!','<?php echo $this->session->flashdata('error');?>','error');

<?php }



if($this->session->flashdata('success')){?>

   swal('success!','<?php echo $this->session->flashdata('success');?>','success');

<?php }?>







function isNumber(evt) {

    evt = (evt) ? evt : window.event;

    var charCode = (evt.which) ? evt.which : evt.keyCode;

    if (charCode > 31 && (charCode < 48 || charCode > 57)) {

        return false;

    }

    return true;

}

</script>