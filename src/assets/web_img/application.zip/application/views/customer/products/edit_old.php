<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Outfit&display=swap" rel="stylesheet">

<main class="app-content">
<style>
.fa{
cursor:pointer;
}
.img-thumbnail{
    border: 2px solid #3f51b5;
	    height: 85px;
    width: 100px;
 }
 .lbl{
     margin-left: 56px;
}
.form-control{
border:1px solid blue !important;
}
</style>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<div class="app-title">
  <div>
    <h1> Edit Product</h1>
  </div>

</div>

<section>
  <div class="scooter-upload">
   <div class=" container" style="padding: 45px 0px 3px 0px;">
      <div class="row">
        
        <form method="post"  class="row" enctype="multipart/form-data">
          <div class="col-md-5">
            <div class="">
              <div class="row">
                  <div class="col-md-12">
                  <div class="form-group">
                     <label style="font-size: 18px;">Vehicle Type</label>
                    <div class="select-style">
                      <select class="form-control" name="vehicle_type" required>
                        <option value="">Select</option>
                        <option value="Used" <?php if($product->vehicle_type=='Used'){?> selected="selected"<?php }?>>Used </option>
                        <option value="New" <?php if($product->vehicle_type=='New'){?> selected="selected"<?php }?>>New</option>
                       
                      </select>
                    </div>
                  </div>
                </div>
                
                <div class="col-md-12">
                  <div class="form-group">
                  <label style="font-size: 18px;">Brand Name</label>
                    <input type="text" class="form-control" id="brand_name" name="brand_name" required placeholder="Brand Name"  value="<?php echo $product->brand;?>">
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                     <label style="font-size: 18px;">Top Speed</label>
                    <input type="text" class="form-control" id="top_speed" name="top_speed" placeholder="Top Speed"  value="<?php echo $product->top_speed;?>" required>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                     <label style="font-size: 18px;">Range</label>
                    <input type="text" class="form-control" name="range" id="range" placeholder="Range" value="<?php echo $product->product_range;?>" required>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                     <label style="font-size: 18px;">Full Charge</label>
                    <input type="text" class="form-control" name="charging_time" id="charging_time" placeholder="Full Charge" value="<?php echo $product->charging_time;?>" required>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                     <label style="font-size: 18px;">Motor Power</label>
                    <input type="text" class="form-control" name="motor_power" id="motor_power" placeholder="Motor Power" value="<?php echo $product->motor_power;?>"  required>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                     <label style="font-size: 18px;">Registration Required ?</label>
                    <div class="select-style">
                      <select class="form-control" name="registration_required" required>
                        <option value="">Select </option>
                        <option value="Yes" <?php if($product->registration_required=='Yes'){?> selected="selected"<?php }?>>Yes</option>
                        <option value="No" <?php if($product->registration_required=='No'){?> selected="selected"<?php }?>>No</option>
                       
                      </select>
                    </div>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                     <label style="font-size: 18px;">Wheel Size</label>
                    <input type="text" class="form-control" id="wheel_size" name="wheel_size" required placeholder="Wheel Size" value="<?php echo $product->tyres;?>" >
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                     <label style="font-size: 18px;">Battery Capacity</label>
                    <input type="text" class="form-control" id="battery_capacity" name="battery_capacity" placeholder="Battery Capacity" value="<?php echo $product->battery_capacity;?>" >
                  </div>
                </div>
				
				<div class="col-md-12">
                  <div class="form-group">
                     <label style="font-size: 18px;">Year</label>
                    <input type="text" class="form-control" name="year" id="year" required placeholder="Year" value="<?php echo $product->year;?>">
                  </div>
                </div>
              </div>
            </div>
          </div>
         <div class="col-md-2" style="max-width: 62px;"></div>

          <div class="col-md-5">
            <div class="">
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                     <label style="font-size: 18px;">Model</label>
                    <input type="text" class="form-control" id="model" name="model" required placeholder="Model" value="<?php echo $product->model;?>">
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                     <label style="font-size: 18px;">Socket Type</label>
                    <input type="text" class="form-control" id="socket_type" name="socket_type" required placeholder="Socket Type" value="<?php echo $product->socket_type;?>">
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                     <label style="font-size: 18px;">Starting</label>
                   <div class="select-style">
                      <select class="form-control" name="starting" required>
                        <option value="">Select </option>
                        <option value="Button" <?php if($product->starting_type=='Button'){?> selected="selected"<?php }?>>Button</option>
                        <option value="Kick" <?php if($product->starting_type=='Kick'){?> selected="selected"<?php }?>>Kick</option>
                       
                      </select>
                    </div>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                     <label style="font-size: 18px;">Safety Fearures</label>
                    <input type="text" class="form-control" id="safety_features" name="safety_features" required placeholder="Safety Fearures" value="<?php echo $product->safety_features;?>">
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                     <label style="font-size: 18px;">Sensor</label>
                    <input type="text" class="form-control" id="sensors" name="sensors" required placeholder="Sensor" value="<?php echo $product->sensors;?>">
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                     <label style="font-size: 18px;">Brake</label>
                    <div class="select-style">
                      <select class="form-control" name="break_type" required>
                        <option value="">Select</option>
                        <option value="Cable Disk" <?php if($product->break_type=='Cable Disk'){?> selected="selected"<?php }?>>Cable Disk</option>
                        <option value="Hydraulic" <?php if($product->break_type=='Hydraulic'){?> selected="selected"<?php }?>>Hydraulic</option>
                        <option value="Semi-hydraulic" <?php if($product->break_type=='Semi-hydraulic'){?> selected="selected"<?php }?>>Semi-hydraulic</option>
                        <option value="Drum" <?php if($product->break_type=='Drum'){?> selected="selected"<?php }?>>Drum</option>
                      </select>
                    </div>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                     <label style="font-size: 18px;">Enter Standard Warranty</label>
                    <div class="select-style">
                      <select name="warranty" class="form-control" required>
                        <option value="">Select</option>
                        <option value="1 Year" <?php if($product->warranty=='1 Year'){?> selected="selected"<?php }?>>1 Year</option>
                        <option value="2 Years" <?php if($product->warranty=='2 Years'){?> selected="selected"<?php }?>>2 Years</option>
                        <option value="3 Years" <?php if($product->warranty=='3 Years'){?> selected="selected"<?php }?>>3 Years</option>
                       
                      </select>
                    </div>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                     <label style="font-size: 18px;">Location</label>
					 <input type="text" class="form-control" id="location" name="location" required placeholder="Location" value="<?php echo $product->location;?>">
                  </div>
                </div>
                 <div class="col-md-12">
                  <div class="form-group">
                     <label style="font-size: 18px;">Pincode</label>
					 <input type="text" class="form-control" id="pincode" name="pincode" required placeholder="Pincode" value="<?php echo $product->pincode;?>">
                  </div>
                </div>
				
				<div class="col-md-12">
                  <div class="form-group">
                     <label style="font-size: 18px;">Price</label>
			<input type="text" class="form-control" id="price" name="price" required placeholder="Price" value="<?php echo $product->price;?>">

                  </div>
                </div>
                
              </div>
            </div>
            
          </div>
          	<div class="col-md-12">
                  <div class="form-group">
                     <label style="font-size: 18px;">Description</label>
<textarea name="description" class="form-control"  required style="width:88%;"><?php echo $product->description;?></textarea>
                  </div>
                </div>
          <div class="col-md-12 mb-4">
           <h4 class="text-up-ph-1" style="padding: 46px 0 0 0; font-weight: 400;">Upload Photos</h4>
            <p class="text-up-ph-2">(Upload photos that showcase your EV from front, back, sides. Use a couple of close-ups for best results.
              Upload only .JPEG and .PNG files.</p>
          </div>
          <div class="col-md-4 mb-3">
            <div class="up-img-box">
              <div class="img-box">
			 <img id="FrontFrame" src="<?php echo base_url('images/front.jpg');?>" class="img-thumbnail" style="width:95%; height:230px;"/>
			  </div>
              <p>
			  <label for="front_view" class="btn lbl">Click to Upload</label>
			  <input id="front_view" style="visibility:hidden;" name="front_view"  type="file" onchange="FrontView()" accept="image/jpg, image/jpeg,image/png">
			  </p>
            </div>
          </div>
          <div class="col-md-4 mb-3">
            <div class="up-img-box">
              <div class="img-box">
			  <img id="SideFrame1" src="<?php echo base_url('images/sco-02.png');?>" class="img-thumbnail" style="width:95%; height:230px;"/>
			  </div>
              <p> <label for="side_view1" class="btn lbl">Click to Upload</label>
			   <input id="side_view1" style="visibility:hidden;" type="file" name="side_view1"  onchange="SideView1()" accept="image/jpg, image/jpeg,image/png">
			  </p>
            </div>
          </div>
          <div class="col-md-4 mb-3">
            <div class="up-img-box">
              <div class="img-box">
			   <img id="SideFrame2" src="<?php echo base_url('images/03.png');?>" class="img-thumbnail" style="width:95%; height:230px;"/>
			  </div>
             <p> <label for="side_view2" class="btn lbl">Click to Upload</label>
			   <input id="side_view2" style="visibility:hidden;" type="file" name="side_view2"  onchange="SideView2()" accept="image/jpg, image/jpeg,image/png">
			  </p>
            </div>
          </div>
		  
          <div class="col-md-4 mb-3">
            <div class="up-img-box">
              <div class="img-box">
			   <img id="SideFrame3" src="<?php echo base_url('images/rear.jpg');?>" class="img-thumbnail" style="width:95%; height:230px;"/>
			  </div>
             <p> <label for="rear_view" class="btn lbl">Click to Upload</label>
			   <input id="rear_view" style="visibility:hidden;" type="file" name="rear_view"  onchange="RearView()" accept="image/jpg, image/jpeg,image/png">
			  </p>
            </div>
          </div>
		  
          <div class="col-md-4 mb-3">
            <div class="up-img-box">
              <div class="img-box">
			   <img id="SideFrame4" src="<?php echo base_url('images/closeup1.jpg');?>" class="img-thumbnail" style="width:95%; height:230px;"/>
			  </div>
             <p> <label for="close_up1" class="btn lbl">Click to Upload</label>
			   <input id="close_up1" style="visibility:hidden;" type="file" name="close_up1"  onchange="CloseUp1()" accept="image/jpg, image/jpeg,image/png">
			  </p>
            </div>
          </div>
		  
          <div class="col-md-4 mb-3">
            <div class="up-img-box">
              <div class="img-box">
			   <img id="SideFrame5" src="<?php echo base_url('images/closeup2.jpg');?>" class="img-thumbnail" style="width:95%; height:230px;"/>
			  </div>
             <p> <label for="close_up2" class="btn lbl">Click to Upload</label>
			   <input id="close_up2" style="visibility:hidden;" type="file" name="close_up2"  onchange="CloseUp2()" accept="image/jpg, image/jpeg,image/png">
			  </p>
            </div>
          </div>
          <div class="col-md-12" align="center"> <button type="submit" class=" btn btn-primary signup text-left" style="display: inline;color: #fff;font-size: 18px;padding: 8px 115px;background-color: #023591;border: 1px solid #023591;border-radius: 25px;font-family: 'Outfit', Sans-Serif;">Submit</button>
           <br/>
           <br/>
             <br/>
               <br/>
                 <br/>
                   <br/>
                     <br/>
                       <br/><!--<p class="repli-mes">Thank you for submitting your EV. We will review it and if all is in good shape, it will be publised within 1 working day. Or else, we will get in touch with you for required information.</p>-->
          </div>
        </form>
		
		
      </div>
    </div>
    <div class="clearfix"></div>
  </div>
</section>



</main>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/js/bootstrap-datepicker.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/css/bootstrap-datepicker.css" rel="stylesheet"/>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<script>
<?php
if($this->session->flashdata('success')){?>
swal('Success','<?php echo $this->session->flashdata('success');?>','success');
<?php }?>
function FrontView() {
    FrontFrame.src=URL.createObjectURL(event.target.files[0]);
}

function SideView1() {
    SideFrame1.src=URL.createObjectURL(event.target.files[0]);
}

function SideView2() {
    SideFrame2.src=URL.createObjectURL(event.target.files[0]);
}

function RearView() {
    SideFrame3.src=URL.createObjectURL(event.target.files[0]);
}

function CloseUp1() {
    SideFrame4.src=URL.createObjectURL(event.target.files[0]);
}

function CloseUp2() {
    SideFrame5.src=URL.createObjectURL(event.target.files[0]);
}

$('.date-own').datepicker({
         format: " yyyy", // Notice the Extra space at the beginning
         viewMode: "years", 
       minViewMode: "years"
       });
</script>

<style>
    @media (min-width: 768px)
.col-md-2 {
    -webkit-box-flex: 0;
    -ms-flex: 0 0 16.6666666667%;
    flex: 0 0 16.6666666667%;
    max-width: 3.666667% !important;
}
.app-content {
    min-height: calc(100vh - 50px);
    margin-top: 50px;
    padding: 30px;
    background-color: #E6E8EE;
}
.img-thumbnail {
    border: 0px solid #3f51b5;
}

.form-control {
    display: block;
    width: 100%;
    padding: 0.375rem 0.75rem;
    font-size: 0.875rem;
    line-height: 1.5;
    color: #222222;
    background-color: #FFF;
    background-clip: padding-box;
    border: 0px solid #3f51b5;
    border-radius: 4px;
    -webkit-transition: border-color 0.15s ease-in-out, -webkit-box-shadow 0.15s ease-in-out;
    transition: border-color 0.15s ease-in-out, -webkit-box-shadow 0.15s ease-in-out;
    -o-transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
    transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
    transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out, -webkit-box-shadow 0.15s ease-in-out;
}
body {
    font-family: 'Outfit', Sans-Serif;
}
.app-title {

  background-color: #e6e8ee !important;
 
}
.app-title h1 {
    margin: 0;
    font-size: 24px;
    font-weight: 400;
    margin-left: 29px;
}
.lbl {
    margin-left: 115px;
}
.btn:not([disabled]):not(.disabled):not(.btn-link):hover, .btn:not([disabled]):not(.disabled):not(.btn-link):focus {
    text-decoration: none;
    -webkit-transform: translate3d(0, -1px, 0);
    transform: translate3d(0, -1px, 0);
    -webkit-box-shadow: 0 0px 0px 0 rgb(0 0 0 / 40%);
    box-shadow: 0 0px 0px 0 rgb(0 0 0 / 40%);
}
</style>
