<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Outfit&display=swap" rel="stylesheet">
<main class="app-content">
    <style>
        .fa{
        cursor:pointer;
        }
        .img-thumbnail{
        border: 2px solid #3f51b5;
        height: 85px;
        width: 100px;
        }
        .lbl{
        margin-left: 56px;
        }
        .form-control{
        border:1px solid blue !important;
        }
    </style>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <div class="app-title">
        <div>
            <h1 style="margin-left: 0;"> Edit Product</h1>
        </div>
    </div>
    <section>
        <div class="scooter-upload">
            <div class=" container" style="padding: 15px 0px 3px 0px;">                
              <form method="post" enctype="multipart/form-data">
                <div class="row">
                  <div class="col-md-6">
                      <div class="form-group">
                          <label style="font-size: 18px;">Vehicle Type</label>
                          <div class="select-style">
                              <select class="form-control" name="vehicle_type" required>
                                  <option value="">Select</option>
                                  <option value="New" <?php if($product->vehicle_type=='New'){?> selected="selected"<?php }?>>Brand New 2 Wheeler </option>
                                  <option value="Used" <?php if($product->vehicle_type=='Used'){?> selected="selected"<?php }?>>Used 2 Wheeler</option>
                              </select>
                          </div>
                      </div>
                  </div>
                  <div class="col-md-6">
                      <div class="form-group">
                          <label style="font-size: 18px;">Model</label>
                          <input type="text" class="form-control" id="model" name="model" required placeholder="Model" value="<?php echo $product->model;?>">
                      </div>
                  </div>
                  <div class="col-md-6">
                      <div class="form-group">
                          <label style="font-size: 18px;">Brand Name</label>
                          <input type="text" class="form-control" id="brand_name" name="brand_name" required placeholder="Brand Name" value="<?php echo $product->brand;?>">
                      </div>
                  </div>
                  <div class="col-md-6">
                      <div class="form-group">
                          <label style="font-size: 18px;">Display</label>
                          <input type="text" class="form-control" id="display" name="display" required placeholder="Display" value="<?php echo $product->display;?>">
                      </div>
                  </div>
                  <div class="col-md-6">
                      <div class="form-group">
                          <label style="font-size: 18px;">Top Speed</label>
                          <input type="text" class="form-control" id="top_speed" name="top_speed" placeholder="Top Speed" required value="<?php echo $product->top_speed;?>">
                      </div>
                  </div>
                  <div class="col-md-6">
                      <div class="form-group">
                          <label style="font-size: 18px;">Connectivity</label>
                          <input type="text" class="form-control" id="connectivity" name="connectivity" required placeholder="Connectivity" value="<?php echo $product->connectivity;?>">
                      </div>
                  </div>
                  <div class="col-md-6">
                      <div class="form-group">
                          <label style="font-size: 18px;">Range</label>
                          <input type="text" class="form-control" name="range" id="range" placeholder="Range" required value="<?php echo $product->product_range;?>">
                      </div>
                  </div>
                  <div class="col-md-6">
                      <div class="form-group">
                          <label style="font-size: 18px;">Safety Fearures</label>
                          <input type="text" class="form-control" id="safety_features" name="safety_features" required placeholder="Safety Fearures" value="<?php echo $product->safety_features;?>">
                      </div>
                  </div>
                  <div class="col-md-6">
                      <div class="form-group">
                          <label style="font-size: 18px;">Full Charge</label>
                          <input type="text" class="form-control" name="charging_time" id="charging_time" placeholder="Full Charge" required value="<?php echo $product->charging_time;?>">
                      </div>
                  </div>
                  <div class="col-md-6">
                      <div class="form-group">
                          <label style="font-size: 18px;">Colors Available</label>
                          <input type="text" class="form-control" id="color" name="color" required placeholder="color" value="<?php echo $product->color;?>">
                      </div>
                  </div>
                  <div class="col-md-6">
                      <div class="form-group">
                          <label style="font-size: 18px;">Motor Power</label>
                          <input type="text" class="form-control" name="motor_power" id="motor_power" placeholder="Motor Power" required value="<?php echo $product->motor_power;?>">
                      </div>
                  </div>
                  <div class="col-md-6">
                      <div class="form-group">
                          <label style="font-size: 18px;">Brake</label>
                          <input type="text" class="form-control" id="break_type" name="break_type" required placeholder="break " value="<?php echo $product->break_type;?>">
                      </div>
                  </div>
                  <div class="col-md-6">
                      <div class="form-group">
                          <label style="font-size: 18px;">Registration Required ?</label>
                          <div class="select-style">
                              <select class="form-control" name="registration_required" required>
                                  <option value="">Select </option>
                                  <option value="Yes" <?php if($product->registration_required=='Yes'){?> selected="selected"<?php }?>>Yes</option>
                                  <option value="No" <?php if($product->registration_required=='No'){?> selected="selected"<?php }?>>No</option>
                              </select>
                          </div>
                      </div>
                  </div>
                  <div class="col-md-6">
                      <div class="form-group">
                          <label style="font-size: 18px;"> Standard Warranty</label>
                          <input type="text" class="form-control" id="warranty" name="warranty" required placeholder="warranty " value="<?php echo $product->warranty;?>">
                      </div>
                  </div>

                  <div class="col-md-6">
                      <div class="form-group">
                          <label style="font-size: 18px;">Wheel</label>
                          <input type="text" class="form-control" id="wheel_size" name="wheel_size" required placeholder="Wheel Size" value="<?php echo $product->tyres;?>">
                      </div>
                  </div>
                  <div class="col-md-6">
                      <div class="form-group">
                          <label style="font-size: 18px;">City</label>
                          <input type="text" class="form-control" id="location" name="location" required placeholder="Location" value="<?php echo $product->location;?>">
                      </div>
                  </div>
                  <div class="col-md-6">
                      <div class="form-group">
                          <label style="font-size: 18px;">Battery</label>
                          <input type="text" class="form-control" id="battery_capacity" name="battery_capacity" placeholder="Battery Capacity" value="<?php echo $product->battery_capacity;?>">
                      </div>
                  </div>
                   <div class="col-md-6">
                      <div class="form-group">
                          <label style="font-size: 18px;">Pincode</label>
                          <input type="text" class="form-control" id="pincode" name="pincode" required placeholder="Pincode" value="<?php echo $product->pincode;?>">
                      </div>
                  </div>
                  <div class="col-md-6">
                      <div class="form-group">
                          <label style="font-size: 18px;">Year</label>
                          <input type="text" class="form-control" name="year" id="year" required placeholder="Year" value="<?php echo $product->year;?>">
                      </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                        <label style="font-size: 18px;">Price</label>
                        <input type="text" class="form-control" id="price" name="price" required placeholder="Price" value="<?php echo $product->price;?>">
                    </div>
                  </div>

                  <div class="col-md-12">
                      <div class="form-group">
                          <label style="font-size: 18px;">Description</label>
                          <textarea name="description" class="form-control" id="description"  required style="width:88%;"><?php echo base64_decode($product->description);?></textarea>
                      </div>
                  </div>
                  <div class="col-md-12 mb-4">
                      <h4 class="text-up-ph-1" style="padding: 46px 0 0 0; font-weight: 400;">Upload Photos</h4>
                      <p class="text-up-ph-2">Upload photos that showcase your EV from front, back, sides. Use a couple of close-ups for best results.
                          Upload only .JPEG and .PNG files.
                      </p>
                  </div>
                  
                  <!-- Image started-->
                  <div class="col-md-4 mb-3">
                      <div class="up-img-box">
                          <div class="img-box">
                              <?php
                                  if($product->front_view==''){ $front_view=base_url('images/placeholder.png');} else{ $front_view=base_url('uploads/products/'.$product->front_view);}
                                  ?>
                              <img id="FrontFrame" src="<?php echo $front_view;?>" class="upload-image img-thumbnail" style="width:95%; height:230px;"/>
                          </div>
                          <p>
                              <label for="front_view" class="btn lbl">Front view</label>   &nbsp <a onClick="FrontViewClose('FrontFrame', <?=$product->id?>, 'front_view')"> <label style="font-size:20px;color:red">X</label></a>
                              <input type="hidden" name="old_front_view" id="old_front_view" value="<?php echo $product->front_view;?>" />
                              <input id="front_view" style="visibility:hidden;" name="front_view"  type="file" onchange="FrontView()" accept="image/jpg, image/jpeg,image/png">
                          </p>
                           
                      </div>
                  </div>
                  <div class="col-md-4 mb-3">
                      <div class="up-img-box">
                          <div class="img-box">
                              <?php
                                  if($product->side_view1=='' ){ $side_view1=base_url('images/placeholder.png');} else{ $side_view1=base_url('uploads/products/'.$product->side_view1);}
                                  ?>
                              <img id="SideFrame1" src="<?php echo $side_view1;?>" class="img-thumbnail upload-image" style="width:95%; height:230px"/>
                          </div>
                          <p> <label for="side_view1" class="btn lbl">Side view 1</label>   &nbsp <a onClick="FrontViewClose('SideFrame1', <?=$product->id?>, 'side_view1')"> <label style="font-size:20px;color:red">X</label></a>
                              <input type="hidden" name="old_side_view1" id="old_side_view1" value="<?php echo $product->side_view1;?>" />
                              <input id="side_view1" style="visibility:hidden;" type="file" name="side_view1"  onchange="SideView1()" accept="image/jpg, image/jpeg,image/png">
                          </p>
                      </div>
                  </div>
                  <div class="col-md-4 mb-3">
                      <div class="up-img-box">
                          <div class="img-box">
                              <?php
                                  if($product->side_view2==''){ $side_view2=base_url('images/placeholder.png');} else{ $side_view2=base_url('uploads/products/'.$product->side_view2);}
                                  ?>
                              <img id="SideFrame2" src="<?php echo $side_view2;?>" class="img-thumbnail upload-image" style="width:95%; height:230px"/>
                          </div>
                          <p> <label for="side_view2" class="btn lbl">Side view 2</label>   &nbsp <a onClick="FrontViewClose('SideFrame2', <?=$product->id?>, 'side_view2')"> <label style="font-size:20px;color:red">X</label></a>
                              <input type="hidden" name="old_side_view2" id="old_side_view2" value="<?php echo $product->side_view2;?>" />
                              <input id="side_view2" style="visibility:hidden;" type="file" name="side_view2"  onchange="SideView2()" accept="image/jpg, image/jpeg,image/png">
                          </p>
                      </div>
                  </div>
                  <div class="col-md-4 mb-3">
                      <div class="up-img-box">
                          <div class="img-box">
                              <?php
                                  if($product->rear_view==''){ $rear_view=base_url('images/placeholder.png');} else{ $rear_view=base_url('uploads/products/'.$product->rear_view);}
                                  ?>
                              <img id="SideFrame3" src="<?php echo $rear_view;?>" class="img-thumbnail upload-image" style="width:95%; height:230px"/>
                          </div>
                          <p> <label for="rear_view" class="btn lbl">Rear view</label>   &nbsp <a onClick="FrontViewClose('SideFrame3', <?=$product->id?>, 'rear_view')"> <label style="font-size:20px;color:red">X</label></a>
                              <input type="hidden" name="old_rear_view" id="old_rear_view" value="<?php echo $product->rear_view;?>" />
                              <input id="rear_view" style="visibility:hidden;" type="file" name="rear_view"  onchange="RearView()" accept="image/jpg, image/jpeg,image/png">
                          </p>
                      </div>
                  </div>
                  <div class="col-md-4 mb-3">
                      <div class="up-img-box">
                          <div class="img-box">
                              <?php
                                  if($product->close_up1==''){ $close_up1=base_url('images/placeholder.png');} else{ $close_up1=base_url('uploads/products/'.$product->close_up1);}
                                  ?>
                              <img id="SideFrame4" src="<?php echo $close_up1;?>" class="img-thumbnail upload-image" style="width:95%; height:230px"/>
                          </div>
                          <p> <label for="close_up1" class="btn lbl">Close-up 1</label>   &nbsp<a onClick="FrontViewClose('SideFrame4', <?=$product->id?>, 'close_up1')"> <label style="font-size:20px;color:red">X</label></a>
                              <input type="hidden" name="old_close_up1" id="old_close_up1" value="<?php echo $product->close_up1;?>" />
                              <input id="close_up1" style="visibility:hidden;" type="file" name="close_up1"  onchange="CloseUp1()" accept="image/jpg, image/jpeg,image/png">
                          </p>
                      </div>
                  </div>
                  <div class="col-md-4 mb-3">
                      <div class="up-img-box">
                          <div class="img-box">
                              <?php
                                  if($product->close_up2==''){ $close_up2=base_url('images/placeholder.png');} else{ $close_up2=base_url('uploads/products/'.$product->close_up2);}
                                  ?>
                              <img id="SideFrame5" src="<?php echo $close_up2;?>" class="img-thumbnail upload-image" style="width:95%; height:230px"/>
                          </div>
                          <p> 
                            <!--<a href="<?=base_url('vendor/delete_image/6/'.$product->id.'/'.$product->close_up2);?>">-->
                              <label for="close_up2" class="btn lbl">Close-up 2</label>   &nbsp <a onClick="FrontViewClose('SideFrame5', <?=$product->id?>, 'close_up2')"> <label style="font-size:20px;color:red">X</label></a>
                              <input type="hidden" name="old_close_up2" id="old_close_up2" value="<?php echo $product->close_up2;?>" />
                              <input id="close_up2" style="visibility:hidden;" type="file" name="close_up2"  onchange="CloseUp2()" accept="image/jpg, image/jpeg,image/png">
                          </p>
                      </div>
                  </div>
                  <!-- Image ended -->
                  
                  <div class="col-md-12" align="center">
                      <button type="submit" class=" btn btn-primary signup text-left" style="display: inline;color: #fff;font-size: 18px;padding: 8px 115px;background-color: #00A76D;border: 0px solid #023591;border-radius: 25px;font-family: 'Outfit', Sans-Serif;">Submit</button>
                      <br/>
                      <br/>
                      <br/>
                      <br/>
                      <br/>
                      <br/>
                      <br/>
                      <br/><!--<p class="repli-mes">Thank you for submitting your EV. We will review it and if all is in good shape, it will be publised within 1 working day. Or else, we will get in touch with you for required information.</p>-->
                  </div>
                </div>
              </form>
            </div>
            <div class="clearfix"></div>
        </div>
    </section>
</main>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/js/bootstrap-datepicker.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/css/bootstrap-datepicker.css" rel="stylesheet"/>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script>

    // function FrontViewClose() {
    //     console.log('ggg');
    //     // $('.upload-image').attr('src') = "abcd";
    //     // var a = $('#FrontFrame').attr('src'); // = "abcd";
    //     // a = "";
        
    //     // $('#FrontFrame').attr('src', 'abcd');
        
    //     console.log($this.parent());
        
    //     // console.log('val : '+a);
    // }
    
    
    function FrontViewClose(id, product_id, image){
        $('#'+id).attr('src','<?=base_url('images/placeholder.png')?>');
        
        $('#old_'+image).val('');
        
        $.ajax({
              url:'<?=site_url("vendor/delete_image/")?>'+product_id+'/'+image,
              method:"GET",
              async: false,
              success:function(data)
              {
                console.log(data);
              }
          });
    }
    
    
    <?php
        if($this->session->flashdata('success')){?>
    swal('Success','<?php echo $this->session->flashdata('success');?>','success');
    <?php }?>
    function FrontView() {
        FrontFrame.src=URL.createObjectURL(event.target.files[0]);
    }
    
    
    function SideView1() {
        SideFrame1.src=URL.createObjectURL(event.target.files[0]);
    }
    
    function SideView2() {
        SideFrame2.src=URL.createObjectURL(event.target.files[0]);
    }
    
    function RearView() {
        SideFrame3.src=URL.createObjectURL(event.target.files[0]);
    }
    
    function CloseUp1() {
        SideFrame4.src=URL.createObjectURL(event.target.files[0]);
    }
    
    function CloseUp2() {
        SideFrame5.src=URL.createObjectURL(event.target.files[0]);
    }
    
    $('.date-own').datepicker({
             format: " yyyy", // Notice the Extra space at the beginning
             viewMode: "years", 
           minViewMode: "years"
           });
           
           
    // Ajax function to delete an image
    // $(document).ready(function(){
    //     alert('Helo');
    // });
    
    
    
    
    // $.get( 
    //     "<?=base_url('/vendor/delete_image/2/3/amre.jpg')?>", 
    //     ).done(function( data ) {
    //         alert( "Data Loaded: " + data );
    //     });
    
</script>
<style>
    @media (min-width: 768px)
    .col-md-2 {
    -webkit-box-flex: 0;
    -ms-flex: 0 0 16.6666666667%;
    flex: 0 0 16.6666666667%;
    max-width: 3.666667% !important;
    }
    .app-content {
    min-height: calc(100vh - 50px);
    margin-top: 50px;
    padding: 30px;
    background-color: #E6E8EE;
    }
    .img-thumbnail {
    border: 0px solid #3f51b5;
    }
    .form-control {
    display: block;
    width: 100%;
    padding: 0.375rem 0.75rem;
    font-size: 0.875rem;
    line-height: 1.5;
    color: #222222;
    background-color: #FFF;
    background-clip: padding-box;
    border: 0px solid #3f51b5;
    border-radius: 4px;
    -webkit-transition: border-color 0.15s ease-in-out, -webkit-box-shadow 0.15s ease-in-out;
    transition: border-color 0.15s ease-in-out, -webkit-box-shadow 0.15s ease-in-out;
    -o-transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
    transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
    transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out, -webkit-box-shadow 0.15s ease-in-out;
    }
    body {
    font-family: 'Outfit', Sans-Serif;
    }
    .app-title {
    background-color: #e6e8ee !important;
    }
    .app-title h1 {
    margin: 0;
    font-size: 24px;
    font-weight: 400;
    margin-left: 29px;
    }
    .lbl {
    margin-left: 115px;
    }
    .btn:not([disabled]):not(.disabled):not(.btn-link):hover, .btn:not([disabled]):not(.disabled):not(.btn-link):focus {
    text-decoration: none;
    -webkit-transform: translate3d(0, -1px, 0);
    transform: translate3d(0, -1px, 0);
    -webkit-box-shadow: 0 0px 0px 0 rgb(0 0 0 / 40%);
    box-shadow: 0 0px 0px 0 rgb(0 0 0 / 40%);
    }
    .form-control {
    border: 0px solid blue !important;
    }
</style>