<?php 
error_reporting(0);
?>
<style>
    .fa{
        font-size:20px;
        cursor:pointer;
    }
	.badge{
    	color: white;
        font-size: 12px;
    	width:100%;
	}
</style>

<main class="app-content">
    <div class="app-title">
        <div>
          <h1> Your Product List</h1>
        </div>
        <ul class="app-breadcrumb breadcrumb side">
          <!--<li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item">Admin</li>
          <li class="breadcrumb-item active"><a href="#">User List</a></li>-->
		  <a href="<?=base_url('vendor/product_add')?>"><button class="btn btn-primary" type="button">Add New Product</button></a>
		</ul>
    </div>

    <div class="row">
        <div class="col-md-12">
		    <div class="row" style="margin-left: 22%;margin-top: -17px;padding-bottom: 6px;">
		        <div class="com-md-3"></div>
		    </div>
		</div>
		<div class="col-md-12">
            <div class="tile">
                <div class="tile-body" style="overflow-x:auto;">
                    <table class="table table-hover table-bordered" id="sampleTable">
                        <thead>
                            <tr>
                  	            <th align="center">ID</th>
                  	            <!--<th>Vehicle Type</th>-->
                  	            <th align="center">Brand</th>
								<th align="center">Model</th>
								<th align="center">Year</th>
                                <!--<th>Top Speed</th>
                                <th>Range</th>
                                <th>Full Charge</th>-->
                                <th align="center">Price</th>
                                <th align="center">Active / Inactive</th>
                                <th align="center">Claim Status</th>
                                <th align="center">Verification Status</th>
                                <th align="center">Action</th>
                            </tr>
                        </thead>

                        <tbody>
        
                            <?php 
        					$today=date('Y-m-d');
        					$i=1;
        					foreach($product_list as $list)
        					{
        					   if($list->vehicle_type=='Used'){
        					       $vehicle_type="Used 2 Wheeler";
        					   }
        
        					   if($list->vehicle_type=='New'){
        					        $vehicle_type="Brand New 2 Wheeler";
        					   }
        					?>
                            <tr>
        
                                <td><?=$i;?></td>
        						<!--<td><?=$vehicle_type;?></td>-->
                               	<td><?=$list->brand;?></td>
                               	<td><?=$list->model;?></td>
                               	<td><?=$list->year;?></td>
                               	<!--<td><?=$list->top_speed;?></td>
                               	<td><?=$list->product_range;?></td>
                                <td><?=$list->charging_time;?></td>-->
        						<td><?=$list->price;?>KOL</td>
        						<td>
        							<?php 
        							if($list->status==1){ 
        							    $text="Active"; 
        							    $status="on"; 
        							    $style="color:green;cursor:pointer;font-size: 34px";
        							}
        							if($list->status==0){
        							    $text="Inactive"; 
        							    $status="off"; 
        							    $style="color:red;cursor:pointer;font-size: 34px";
        							} 
        							echo $text;
        							?>
        						</td>
        						<td align="center">
                                    <!--<div class="row">
                                        <div class="com-md-4">-->
                                        <?php if($list->is_claimed == 1){ ?>
                                            <a class="btn btn-primary" style="padding:5px 25px;" href="#<?php //echo base_url('vendor/upgrade_product/'.$list->id);?>" <?php echo $disable;?>>
                                                <?php echo 'Upgrade' ?>
                                            </a>
                                        <?php }else{ ?>
                                            <a class="btn btn-primary" style="padding:5px 25px;" href="<?php echo base_url('vendor/claim_product/'.$list->id);?>/1" <?php echo $disable;?>>
                                                <?php echo 'Claim' ?>
                                            </a>
                                        <?php } ?>
                                        <!--</div>
                                    
        
        							    <div class="com-md-4">-->
                                        
        								<!--</div>					
        							</div>-->
                                </td>
                                <td align="center">
                                    <?php if($list->is_verified == 0){?>
                                            <a class="btn btn-primary" style="padding:5px 25px;" href="<?php echo base_url('vendor/verify_product/'.$list->id);?>/1" <?php echo $disable;?>>
                                            <?php echo 'Verify' ?>
                                            </a>
                                        <?php }else{ 
                                            echo '<i class="fa fa-check" aria-hidden="true"></i> Verified';
                                            }?>
                                </td>
                                <td align="center">
                                    <?php 
                                    if($list->status==0){ 
                                        echo 'Not Approved Yet';
                                    } else{
                                    ?>  
                                    <a href="<?php echo base_url('vendor/view_product/'.$list->id);?>" class="action-icon">
                                        <i class="fa fa-eye" aria-hidden="true"></i>
                                    </a>
                                    <a href="<?php echo base_url('vendor/edit_product/'.$list->id);?>" class="action-icon">
                                        <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                                    </a>
                                    <a onclick="delete_product(<?=$list->id?>)" href="javascript:void(0);" class="action-icon">
                                        <i class="fa fa-trash-o" aria-hidden="true"></i>
                                    </a>
                                    
                                    <?php 
                                    }
                                    ?> 
                                </td>
        
                            </tr>
                          	<?php $i++; } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>

	

	

	







	

	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>

	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

	



	

<script>

function DoRenew(user_id){

  if (confirm('Are you sure you want to Renew this banner?')) 

	{

		$.ajax({

			url: "<?=base_url('Admin/user_renew')?>",

			type: "POST",		

			data:  {user_id:user_id},

			success: function(data)

			{		

				var obj= JSON.parse(data);

				var success=obj.success;

				var message=obj.message; 

				if(success=='1')

				{

					

					window.location="<?=base_url()?>Admin/banner_list";

				}

				else

				{

					;

					window.location="<?=base_url()?>Admin/banner_list";

				}

			}

		});	

	}

}





<?php

if($this->session->flashdata('error')){?>

   swal('Oops!','<?php echo $this->session->flashdata('error');?>','error');

<?php }



if($this->session->flashdata('success')){?>

   swal('success!','<?php echo $this->session->flashdata('success');?>','success');

<?php }?>

function delete_banner(id)

{

	if (confirm('Are you sure you want to delete this banner?')) 

	{

		$.ajax({

			url: "<?=base_url('Admin/delete_banner')?>",

			type: "POST",		

			data:  {id:id},

			success: function(data)

			{		

				var obj= JSON.parse(data);

				var success=obj.success;

				var message=obj.message; 

				if(success=='1')

				{

					

					window.location="<?=base_url()?>Admin/banner_list";

				}

				else

				{

					;

					window.location="<?=base_url()?>Admin/banner_list";

				}

			}

		});	

	}

}





function ChanageStatus(id,status){

 swal({

      title: "Are you sure?",

      text: "Status will be change",

      icon: "warning",

      buttons: [

        'Cancel',

        'OK'

      ],

      dangerMode: true,

    }).then(function(isConfirm) {

      if (isConfirm) {

        swal({

          title: 'Success!',

          text: 'Status has been changed successfully',

          icon: 'success'

        }).then(function() {

		var table="banners";

	

          $.post("<?php echo base_url('Admin/ChangeStatus')?>",{table:table,id:id,status:status},function(data){

		    window.location.reload();

			

		  });

        });

      } else {

        //swal("Cancelled", "Your imaginary file is safe :)", "error");

      }

    })

}





</script>



