<main class="app-content">
<style>
h5 {
    
    
    margin-top: 12px;
    
}
.red{
color:#FF0066;
}
</style>
 <?php $vendor_id= $this->session->userdata('admin_id');?>
      <div class="app-title">
        <div>
         
         <p style="font-size: 24px;margin: 0 0 0 33px;">Welcome to Your EV Dreamz Vendor Dashboard</p>
        </div>
        
      </div>
      
  <div class="row" style="margin: 70px 4px 1px 20px;"> 
	  <div class="col-md-6 col-lg-4">
	 <?php $products = $this->db->query('SELECT * FROM products WHERE vendor_id="'.$vendor_id.'"');?>


          <div class="widget-small primary coloured-icon"><i class="icon fa fa-product-hunt fa-3x"></i>
		  <a href="<?php echo base_url('vendor/product_list');?>">
            <div class="info">
			
			              <h5>  Products</h5>
              <p><b><?php echo $products->num_rows();?></b></p>
            </div>
			 </a>
          </div>
		 
        </div>
		
		
		
		<div class="col-md-6 col-lg-4">
	 <?php 
	  $this->db->select('*');
    $this->db->from('customer_bookings');
    $this->db->join('products', 'products.id = customer_bookings.product_id'); 
	$this->db->where('products.vendor_id',$vendor_id);
    $query = $this->db->get();
   $bookings= $query->num_rows();
	 ?>
	 
	 


          <div class="widget-small primary coloured-icon"><i class="icon fa fa-smile-o" aria-hidden="true"></i>
		  <a href="<?php echo base_url('Admin/booking_requests');?>">
            <div class="info">
			
			              <h5> Booking Requests</h5>
              <p><b><?php echo $bookings;?></b></p>
            </div>
			 </a>
          </div>
		 
        </div>
		
		
		
		
		
	
	</div>	
    </main>