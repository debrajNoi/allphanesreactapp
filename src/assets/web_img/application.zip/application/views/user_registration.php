    <section>

  <div class="registration-sec">

    <div class=" container-fluid">

    <div class="row">

      <div class="col-md-5 p-0"><img src="<?php echo base_url('images/registration page visual-10 1300.png');?>" alt="" class="img-fluid"></div>

      <div class="col-md-6">

       <h1>Please Sign up to browse and make the most of this EV Community</h1>

       <div class="form-sec">

        <form method="post" action="" onsubmit="return checkForm(this);">

            <div class="row">

    		  <div class="col-md-12">

				<?php

				$temp=  $this->session->userdata('temp');

				if($this->session->flashdata('success')){?>

				<div class="alert alert-success"><?php echo $this->session->flashdata('success');?></div>

				<?php }

				

				if($this->session->flashdata('error')){?>

				<div class="alert alert-danger"><?php echo $this->session->flashdata('error');?></div>

				<?php }?>

				

                    <!-- <div class="form-group form-group-sm">

                      <div class="select-style">

                        <select id="user_role" name="user_role" required>

                            <option value="">Select Account Type</option>

                            <option value="1">Vendor</option>

                            <option value="2">Customer</option>

                        </select>

                      </div>

                    </div> -->

<!-- 
                    <div id="div_user_type" class="form-group form-group-sm">

                      <div class="select-style">

                        <select id="user_type" name="user_type" required>

                            <option value="">Select</option>

                          <option value="Vendor">I am Selling Brand New 2 Wheeler  </option>

                          <option value="Charger Vendor">I am Selling used 2 Wheeler</option>

                        </select>

                      </div>

                    </div>

                </div> -->

                <input type="hidden" name="user_role" value="2" />

                <input type="hidden" name="user_type" value="customer" />

                <div class="col-md-12">

                    <div class="form-group">

                        <input type="text" class="form-control" id="name" name="name" required placeholder="Full Name" >

                    </div>

                </div>

<!--                 <div id="div_shop_name" class="col-md-12">

                    <div class="form-group">

                        <input type="text" class="form-control" name="company_name" id="company_name" required placeholder="Brand/Company/Shop Name" >

                    </div>

                </div> -->

                <div class="col-md-12">

                    <div class="form-group">

                        <input type="text" class="form-control" id="email" name="email" pattern="[a-zA-Z0-9!#$%&amp;'*+\/=?^_`{|}~.-]+@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*" required placeholder="Email" >

                    </div>

                </div>

                <div class="col-md-12">

                    <div class="form-group">                       

                        <input type="number" class="form-control" id="mobile" name="mobile" maxlength="10" placeholder="Phone" required >

                    </div>

                </div>

                

                <div class="col-md-12">

                    <div class="form-group">

                        <div class="select-style">

                          <select name="state" id="state" required onchange="GetCityByState(this.value)">

						  <option value="" >Select State</option>

						  <?php

							foreach($state_list as $state){?>

                              <option value="<?php echo $state->id;?>" ><?php echo $state->name;?></option>

							<?php }?>

                          </select>

                        </div>

                    </div>

                </div>

				

				<div class="col-md-12">

                    <div class="form-group">

                       <div class="select-style">

                            <select name="city" id="city" required >

                                <option value="">Select city</option> 

                            </select>

                        </div>

                    </div>

                </div>

                <!-- <div id="div_neighborhood" class="col-md-12">

                    <div class="form-group">

                      <input type="text" class="form-control" id="neighborhood" name="neighborhood" placeholder="Showroom Address" >

                    </div>

                </div> -->

                <div class="col-md-12">

                    <div class="form-group">

                         <input type="number" class="form-control" id="pincode" name="pincode" maxlength="6"  placeholder="Pincode" required>

                    </div>

                </div>

				

				<div class="col-md-12">

                    <div class="form-group">

                         <input type="password" class="form-control" id="password" name="password" minlength="6" required placeholder="Password" required>

                    </div>

                </div>

				

				<div class="col-md-12">

                    <div class="form-group">                       

                         <input type="password" class="form-control" id="confirm_password" name="confirm_password" required placeholder="Confirm Password" minlength="6" required onkeyup="PasswordValidate(this.value)">

						 <p id="Response"></p>

                    </div>

                </div>



                <div class="col-md-12">

                    <div class="form-group">

                        <fieldset>

                            <label for="accessible" class="trem-sec"> 

                                <input type="checkbox" value="accessible" name="terms" id="accessible" required > I accept the <span><a href="https://www.evdreamz.com/terms" style="color: #00a76d;">Terms and Condition</a></span>

                            </label>

                        </fieldset>

                    </div>

                </div>

                <div class="col-md-12">

                   <button type="submit" class="signup" id="SignupBtn">Sign up with EV Dreamz</button>

                </div>

            </div>

    </form>





  </div>

       </div>

      <div class="col-md-2"></div>

    </div>

  </div>

  <div class="clearfix"></div>

  </div>

</section>

<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script type="text/javascript">
    // Function to switch form from vendor to customer
    $('#user_role').change(function() {
        if ($(this).val() === '1') {
            console.log('Vendor selected ');

            // To show the divs
            $('#div_user_type').show();
            $('#div_shop_name').show();
            $('#div_neighborhood').show();

            // To make required true
            $( "#user_type" ).prop( "required", true );
            $( "#company_name" ).prop( "required", true );
            $( "#neighborhood" ).prop( "required", true );
        }
        else{
            console.log('Customer selected');

            // To hide the divs
            $('#div_user_type').hide();
            $('#div_shop_name').hide();
            $('#div_neighborhood').hide();

            // To make required false
            $( "#user_type" ).prop( "required", false );
            $( "#company_name" ).prop( "required", false );
            $( "#neighborhood" ).prop( "required", false );
        }
    });
</script>

<script>

setTimeout(function(){ $('.alert').fadeOut(); }, 10000);

function GetCityByState(state_id){

   if(state_id!=''){

     $.get("<?php echo base_url('Front/GetCityByState');?>",{state_id:state_id},function(data){

	 $('#city').html(data);

	

	 });

   }

}



function PasswordValidate(confirm_password){

 var password =$('#password').val();

 

 if(password!=confirm_password){

    $('#Response').html('<font color="red">Confirm password does not matched</font>');

	document.getElementById('SignupBtn').disabled=true;

 }else{

    $('#Response').html('');

	document.getElementById('SignupBtn').disabled=false;

 }

}

</script>

<style>

    body {

    font-family: 'Outfit', Sans-Serif;

}

.trem-sec {

    font-size: 14px;

    font-family: 'Outfit', Sans-Serif !important;

}

.registration-sec .form-control {

    height: 55px;

    font-size: 15px;

    border: #aaacaf 0px solid;

}

.select-style {

    border: 0px solid #ced4da;

    width: auto;

    height: 55px;

    overflow: hidden;

    padding: 10px;

    background: #fff url(../images/arrow.png) no-repeat 95% 24px;

    background-size: 3%;

    border-radius: 0px;

    font-size: 15px;

    border-bottom: none;

    border-radius: 0.25rem;

}

.signup {

    font-size: 18px;

}



.trem-sec span {

    color: #00a66d;

    font-size: 16px;

    font-family: 'Outfit',Sans-Serif;

}

button:focus {

    outline: 0px dotted;

    outline: 0px auto -webkit-focus-ring-color;

}





</style>

    

