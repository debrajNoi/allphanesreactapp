<?php 
error_reporting(0);?>
<style>
    .fa{
        font-size:20px;
        cursor:pointer;
    }
	.badge{
	color: white;
    font-size: 12px;
	width:100%;
	}
</style>
<main class="app-content">
      <div class="app-title">
        <div>
          <h1> About Us</h1>
          
        </div>
        <ul class="app-breadcrumb breadcrumb side">
          <!--<li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item">Admin</li>
          <li class="breadcrumb-item active"><a href="#">User List</a></li>-->
          
		  
		<!--<a href="<?=base_url('admin/about_us_add')?>"><button class="btn btn-primary" type="button">Add New </button></a></ul>-->
      </div>
     
     
      <div class="row">
         <div class="col-12">
               <div class="tile">
    <form class="form-horizontal" method="post" action="<?php echo base_url('admin/seo_page/about-us/about_us'); ?>" enctype="multipart/form-data">
      
      
      <div class="tile-body">
        
        
		
		<div class="form-group row">
          <label class="control-label col-md-3">SEO Details</label>
          <div class="col-md-8">
            <div class="form-group">
                <label for="exampleFormControlTextarea1">Meta Title</label>
                <input type="text" class="form-control" placeholder="meta-title" name="metaTitle" value="<?php echo $cms[0]->meta_title;?>">
            </div>
            
            <div class="form-group">
                <label for="exampleFormControlTextarea1">Meta Keyword</label>
                <textarea class="form-control" name="metaKeyword" rows="3"><?php echo $cms[0]->meta_keyword;?></textarea>
            </div>
              
            <div class="form-group">
                <label for="exampleFormControlTextarea1">Meta Description</label>
                <textarea class="form-control" name="metaDescription" rows="3"><?php echo $cms[0]->meta_description;?></textarea>
            </div>
              
          </div>
        </div>
		
		
		
		
	
        
      </div>
      
      <div class="tile-footer">
        <div class="row">
          <div class="col-md-8 col-md-offset-3">
            <button class="btn btn-primary" type="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>Update</button>
        </div>
        </div>
      </div>
	 
    </form>
    </div>
         </div>
         
         
        <div class="col-md-12 mt-4">
		<div class="row" style="margin-left: 22%;margin-top: -17px;padding-bottom: 6px;">
		<div class="com-md-3"></div>
		
		</div>
		</div>
		<h4 class="m-4">Contents</h4>
		<div class="col-md-12">
          <div class="tile">
            <div class="tile-body" style="overflow-x:auto;">
              <table class="table table-hover table-bordered" id="sampleTable">
                <thead>
                  <tr>
                  	<th>ID</th>
					<th>Title</th>
					<th>Content</th>
					<th>Image</th>
                  	
					
					<th>Action</th>
                  </tr>
                </thead>
                <tbody>
                    <?php 
					
					$today=date('Y-m-d');
					$i=1;
					
					foreach($cms_sections as $list)
					{
					   
					?>
                      <tr>
                        <td><?=$i;?></td>
						<td><?=$list->title;?></td>
						<td><?=base64_decode($list->content);?></td>
                        <td>
                             <img src="<?php echo $list->image ? base_url('uploads/cms/'.$list->image): '';?>" class="img-thumbnail" />
                        </td>
						
						 
						  
                        <td align="center">
                           
                            
                            
                          
                            <a href="<?php echo base_url('admin/edit_content/'.$list->id.'/about_us');?>">
                                <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                            </a>
                           
                          <!--<a onclick="delete_about(<?=$list->id?>)" class="">
                                <i class="fa fa-trash-o" aria-hidden="true"></i>
                            </a>-->
                        </td>
                      </tr>
                  	<?php $i++; } ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </main>
	
	
	



	
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	

	
<script>



<?php
if($this->session->flashdata('error')){?>
   swal('Oops!','<?php echo $this->session->flashdata('error');?>','error');
<?php }

if($this->session->flashdata('success')){?>
   swal('success!','<?php echo $this->session->flashdata('success');?>','success');
<?php }?>
function delete_about(id)
{
	if (confirm('Are you sure you want to delete this content?')) 
	{
		$.ajax({
			url: "<?=base_url('Admin/delete_about')?>",
			type: "POST",		
			data:  {id:id},
			success: function(data)
			{		
				var obj= JSON.parse(data);
				var success=obj.success;
				var message=obj.message; 
				if(success=='1')
				{
					
					window.location="<?=base_url()?>Admin/about_us";
				}
				else
				{
					;
					window.location="<?=base_url()?>Admin/about_us";
				}
			}
		});	
	}
}


function ChanageStatus(id,status){
 swal({
      title: "Are you sure?",
      text: "Status will be change",
      icon: "warning",
      buttons: [
        'Cancel',
        'OK'
      ],
      dangerMode: true,
    }).then(function(isConfirm) {
      if (isConfirm) {
        swal({
          title: 'Success!',
          text: 'Status has been changed successfully',
          icon: 'success'
        }).then(function() {
		var table="products";
	
          $.post("<?php echo base_url('Admin/ChangeStatus')?>",{table:table,id:id,status:status},function(data){
		    window.location.reload();
			
		  });
        });
      } else {
        //swal("Cancelled", "Your imaginary file is safe :)", "error");
      }
    })
}


function ChanagefeaturedStatus(id,status){
 if(status==0){var msg="Publish on Featured?";}
 if(status==1){var msg="Unpublish on Featured?";}
 swal({
      title: "Are you sure want to "+msg,
      text: "",
      icon: "warning",
      buttons: [
        'Cancel',
        'OK'
      ],
      dangerMode: true,
    }).then(function(isConfirm) {
      if (isConfirm) {
        swal({
          title: 'Success!',
          text: 'Status has been changed successfully',
          icon: 'success'
        }).then(function() {
		var table="products";
	
          $.post("<?php echo base_url('Admin/ChangeFeaturedStatus')?>",{table:table,id:id,status:status},function(data){
		    window.location.reload();
			
		  });
        });
      } else {
        //swal("Cancelled", "Your imaginary file is safe :)", "error");
      }
    })
}

function ChanageBannerStatus(id,status){
 if(status==0){var msg="Publish on Banner?";}
 if(status==1){var msg="Unpublish on Banner?";}
 swal({
      title: "Are you sure want to "+msg,
      text: "",
      icon: "warning",
      buttons: [
        'Cancel',
        'OK'
      ],
      dangerMode: true,
    }).then(function(isConfirm) {
      if (isConfirm) {
        swal({
          title: 'Success!',
          text: 'Status has been changed successfully',
          icon: 'success'
        }).then(function() {
		var table="products";
	
          $.post("<?php echo base_url('Admin/ChangeBannerStatus')?>",{table:table,id:id,status:status},function(data){
		    window.location.reload();
			
		  });
        });
      } else {
        //swal("Cancelled", "Your imaginary file is safe :)", "error");
      }
    })
}


</script>

