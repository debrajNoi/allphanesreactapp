<?php 

error_reporting(0);?>

<style>

	.fa{

		font-size:20px;

		cursor:pointer;

	}

	.badge{

		color: white;

		font-size: 12px;

		width:100%;

	}

</style>

<main class="app-content">

  <div class="app-title">

    <div>

      <h1> Website Trial List</h1>

    </div>

    <ul class="app-breadcrumb breadcrumb side"></ul>

  </div>


  <div class="row">

    <div class="col-md-12">

			<div class="row" style="margin-left: 22%;margin-top: -17px;padding-bottom: 6px;">

				<div class="com-md-3">
					
				</div>

			</div>

		</div>

		<div class="col-md-12">

      <div class="tile">

        <div class="tile-body" style="overflow-x:auto;">

        	<!-- <pre><?php print_r($request_list); ?></pre> -->

          <table class="table table-hover table-bordered" id="sampleTable">

            <thead>

              <tr>

								<th>ID</th>

								<th>Name</th>

								<th>Email</th>

								<th>Mobile</th>

								<th>Whatsapp</th>

								<th>Start Date</th>

								<th>End Date</th>

              </tr>

            </thead>

            <tbody>

              <?php 

								$today=date('Y-m-d');

								$i=1;

								foreach($request_list as $list)
								{
									

							?>

              	<tr>

									<td><?=$i;?></td>

									<td><?=$list->name;?></td>

									<td><?=$list->email;?></td>

									<td><?=$list->mobile;?></td>

									<td><?=$list->whatsapp;?></td>

									<td><?=$list->is_website_activated == 1?date('d-M,Y', strtotime($list->trial_start_date)):'';?></td>
									<!-- <td><?=date('d-M,Y', strtotime($list->trial_start_date))?></td> -->

									<td>
										<?php
											if($list->is_website_activated == 1){
												$date = date_create($list->trial_start_date);
												date_add($date,date_interval_create_from_date_string("30 days"));
												echo date_format($date,"d, M-Y");
											}
										?>
									</td>

                </tr>

            	<?php $i++; } ?>

            </tbody>

          </table>

        </div>

      </div>

    </div>

  </div>

</main>

	

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>

<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	

<script>

	function DoRenew(user_id){

		if (confirm('Are you sure you want to Renew this banner?')) 

		{

			$.ajax({

				url: "<?=base_url('Admin/user_renew')?>",

				type: "POST",		

				data:  {user_id:user_id},

				success: function(data)

				{		

					var obj= JSON.parse(data);

					var success=obj.success;

					var message=obj.message; 

					if(success=='1')

					{
						window.location="<?=base_url()?>Admin/banner_list";
					}
					else
					{
						window.location="<?=base_url()?>Admin/banner_list";
					}

				}

			});	

		}

	}





<?php

if($this->session->flashdata('error')){?>

   swal('Oops!','<?php echo $this->session->flashdata('error');?>','error');

<?php }



if($this->session->flashdata('success')){?>

   swal('success!','<?php echo $this->session->flashdata('success');?>','success');

<?php }?>

function delete_banner(id)

{

	if (confirm('Are you sure you want to delete this banner?')) 

	{

		$.ajax({

			url: "<?=base_url('Admin/delete_banner')?>",

			type: "POST",		

			data:  {id:id},

			success: function(data)

			{		

				var obj= JSON.parse(data);

				var success=obj.success;

				var message=obj.message; 

				if(success=='1')
				{
					window.location="<?=base_url()?>Admin/banner_list";
				}
				else
				{					
					window.location="<?=base_url()?>Admin/banner_list";
				}

			}

		});	

	}

}





function ChanageStatus(id,status){

 swal({

      title: "Are you sure?",

      text: "Status will be change",

      icon: "warning",

      buttons: [

        'Cancel',

        'OK'

      ],

      dangerMode: true,

    }).then(function(isConfirm) {

      if (isConfirm) {

        swal({

          title: 'Success!',

          text: 'Status has been changed successfully',

          icon: 'success'

        }).then(function() {

				var table="banners";

        $.post(
        	"<?php echo base_url('Admin/ChangeStatus')?>",
        	{
        		table:table,
        		id:id,
        		status:status
        	},
        	function(data){
		    		window.location.reload();
		  		});
        });
      } else {
        //swal("Cancelled", "Your imaginary file is safe :)", "error");
      }

    })

}

</script>