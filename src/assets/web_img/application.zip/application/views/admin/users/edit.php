<main class="app-content">
<style>
.fa{
cursor:pointer;
}
</style>
<div class="app-title">
  <div>
    <h1> Edit Vendor</h1>
  </div>
</div>
<div class="row">
<div class="col-md-8">

  <div class="tile">
  
  <br/>
    <form class="form-horizontal" method="post" action="" enctype="multipart/form-data">
      <div class="tile-body">
	 
	  <div class="form-group row">
          <label class="control-label col-md-3">Name </label>
           <div class="col-md-8">
            <input class="form-control " type="text" name="name" placeholder="Name" value="<?php echo $vendor->name;?>" required>
          </div>
        </div>
		
		<div class="form-group row">
          <label class="control-label col-md-3">Company </label>
           <div class="col-md-8">
            <input class="form-control " type="text" name="company" placeholder="Company" value="<?php echo $vendor->company_name;?>" required>
          </div>
        </div>
		
		<div class="form-group row">
          <label class="control-label col-md-3">Email </label>
           <div class="col-md-8">
            <input class="form-control " type="email" name="email" placeholder="Phone" value="<?php echo $vendor->email;?>" readonly required>
          </div>
        </div>
		
	
	  	<div class="form-group row">
          <label class="control-label col-md-3">Mobile </label>
           <div class="col-md-8">
            <input class="form-control " type="text"  name="mobile" placeholder="Phone" value="<?php echo $vendor->mobile;?>"  required>
          </div>
        </div>
        
		
	
       
	<div class="form-group row">
          <label class="control-label col-md-3">City </label>
           <div class="col-md-8">
               <?php
               $sql_city = $this->db->query('SELECT * FROM cities');
               $cities=$sql_city->result();?>
               <select name="city" class="form-control" required>
                   <option value="">Select</option>
              <?php 
               foreach($cities as $ct){?>
                   <option value="<?php echo $ct->id;?>" <?php if($ct->city==$vendor->city){?> selected<?php }?>><?php echo $ct->city;?></option>
               <?php } ?>
               </select>
           
          </div>
        </div>
	
		
		<div class="form-group row">
          <label class="control-label col-md-3">State </label>
           <div class="col-md-8">
           <?php
               $sql_state = $this->db->query('SELECT * FROM states');
               $states=$sql_state->result();?>
               <select name="state" class="form-control" required>
                   <option value="">Select</option>
              <?php 
               foreach($states as $st){?>
                   <option value="<?php echo $st->id;?>" <?php if($st->id==$vendor->state){?> selected<?php }?>><?php echo $st->name;?></option>
               <?php } ?>
               </select>
          </div>
        </div>
		
		
		
		<div class="form-group row">
          <label class="control-label col-md-3">Neighborhood </label>
           <div class="col-md-8">
                 <input class="form-control " type="text"  name="neighborhood" placeholder="Neighborhood" value="<?php echo $vendor->neighborhood;?>" required>
          
          </div>
        </div>
		
		<div class="form-group row">
          <label class="control-label col-md-3">Pincode </label>
           <div class="col-md-8">
            <input class="form-control" maxlength="6"  type="number" name="pincode" placeholder="Pincode" value="<?php echo $vendor->pincode;?>" required>
          </div>
        </div>
        
        	<div class="form-group row">
          <label class="control-label col-md-3">Image </label>
           <div class="col-md-8">
           <input type="file" name="image">
           <img src="<?php echo base_url('uploads/users/'.$vendor->image)?>" class="img-thumbnail" style="height:100px;">
           <input type="hidden" name="old_image" value="<?php echo $vendor->image?>">
          </div>
        </div>
	
      </div>
      
      <div class="tile-footer">
         <button class="btn btn-primary" type="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>Update</button>
        <a class="btn btn-secondary" href="<?=base_url('Admin/vendor_list')?>"><i class="fa fa-fw fa-lg fa-times-circle"></i>Back</a> 
      </div>
   
  </div>
</div>



   
        
        
        
        
      </div>
      <div class="tile-footer">
       
      </div>
    </form>
  </div>
</div>
</main>

<script type="text/javascript">
$(document).ready(function(){
    $('#select_all').on('click',function(){
        if(this.checked){
            $('.checkbox').each(function(){
                this.checked = true;
            });
        }else{
             $('.checkbox').each(function(){
                this.checked = false;
            });
        }
    });
    
    $('.checkbox').on('click',function(){
        if($('.checkbox:checked').length == $('.checkbox').length){
            $('#select_all').prop('checked',true);
        }else{
            $('#select_all').prop('checked',false);
        }
    });
	
	
	
	
	
	 $('#item_select').on('click',function(){
        if(this.checked){
            $('.items').each(function(){
                this.checked = true;
            });
        }else{
             $('.items').each(function(){
                this.checked = false;
            });
        }
    });
    
    $('.items').on('click',function(){
        if($('.items:checked').length == $('.items').length){
            $('#item_select').prop('checked',true);
        }else{
            $('#item_select').prop('checked',false);
        }
    });
});
</script>
