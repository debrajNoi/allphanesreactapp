<main class="app-content">
<style>
.fa{
cursor:pointer;
}
</style>
<div class="app-title">
  <div>
    <h1><i class="fa fa-plus"></i> Add Customer</h1>
  </div>
  <ul class="app-breadcrumb breadcrumb">
    <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
    <li class="breadcrumb-item">Admin</li>
    <li class="breadcrumb-item"><a href="#">Add Customer</a></li>
  </ul>
</div>
<div class="row">
<div class="col-md-6">

  <div class="tile">
  <h4>Customer Details</h4>
  <hr />
    <form class="form-horizontal" method="post" action="" enctype="multipart/form-data">
      <div class="tile-body">
	  
	  <div class="form-group row">
          <label class="control-label col-md-3">GST Number </label>
           <div class="col-md-8">
            <input class="form-control " type="text" name="gst_number" placeholder="GST Number"  required>
          </div>
        </div>
		
		<div class="form-group row">
          <label class="control-label col-md-3">Company </label>
           <div class="col-md-8">
            <input class="form-control " type="text" name="company" placeholder="Company"  required>
          </div>
        </div>
		
		<div class="form-group row">
          <label class="control-label col-md-3">Phone </label>
           <div class="col-md-8">
            <input class="form-control " type="text" name="phone" placeholder="Phone"  required>
          </div>
        </div>
		
		<div class="form-group row">
          <label class="control-label col-md-3">Website </label>
           <div class="col-md-8">
            <input class="form-control " type="text" name="website" placeholder="Website"  required>
          </div>
        </div>
	  
        <div class="form-group row">
          
		    <hr style="border: 1px solid red;width: 100%;" />
			<label class="control-label col-md-3"><strong>Groups</strong></label>
          <div class="row">
		 <div class="col-md-8" style="margin-left:56px;">
			 <input type="checkbox" name="group[]" id="select_all"/> All
			 </div>
             <?php
			 $sql=$this->db->query('SELECT * FROM groups WHERE remove_status=0 AND status=1');
				$group=$sql->result();
				foreach($group as $grp){?>
				
			 <div class="col-md-8" style="margin-left:56px;">
			 <input type="checkbox" name="group[]" class="checkbox" value="<?php echo $grp->id;?>" /> <?php echo $grp->name;?>
			 </div>
			 <?php }?>
          </div>
        </div>
		
		<div class="form-group row">
         <hr style="border: 1px solid red;width: 100%;" />
			<label class="control-label col-md-3"><strong>Item</strong></label>
			<p></p>
			<div class="row">
			 <div class="col-md-8" style="margin-left:10px;">
			 <input type="checkbox" name="group[]" id="item_select"/> All
			 </div>
           
            <?php
			$sql_item=$this->db->query('SELECT * FROM items WHERE remove_status=0');
			$items=$sql_item->result();
			foreach($items as $item){?> <div class="col-md-8" style="margin-left:10px;">
			 <input type="checkbox" name="item[]" class="items" value="<?php echo $item->id;?>" /> <?php echo $item->description;?>
			 </div>
			
			<?php }?>
          </div>
        </div>
       
		<div class="form-group row">
          <label class="control-label col-md-3">Currency </label>
           <div class="col-md-8">
         <select name="currency" id="currency" class="form-control" required>
		  <option value="">Select</option>
		  <option value="usd">USD</option>
		  <option value="eur">EUR</option>
		  <option value="inr">INR</option>
		  
		 </select>
          </div>
        </div>
		
		<div class="form-group row">
          <label class="control-label col-md-3">Country </label>
           <div class="col-md-8">
         <select name="country" id="country" class="form-control" required>
		  <option value="">Select</option>
		 <?php
		 $sql_country=$this->db->query('SELECT * FROM country');
		 $country=$sql_country->result();
		 foreach($country as $cont){?>
		  <option value="<?php echo $cont->nicename;?>"><?php echo $cont->nicename;?></option>
		 <?php }?>
		  
		 </select>
          </div>
        </div>
		
		<div class="form-group row">
          <label class="control-label col-md-3">State </label>
           <div class="col-md-8">
            <input class="form-control " type="text" name="state" placeholder="State"  required>
          </div>
        </div>
		
		<div class="form-group row">
          <label class="control-label col-md-3">City </label>
           <div class="col-md-8">
            <input class="form-control " type="text" name="city" placeholder="City"  required>
          </div>
        </div>
		
		<div class="form-group row">
          <label class="control-label col-md-3">Address </label>
           <div class="col-md-8">
            <textarea name="address" class="form-control" required></textarea>
          </div>
        </div>
		
		<div class="form-group row">
          <label class="control-label col-md-3">Pincode </label>
           <div class="col-md-8">
            <input class="form-control" maxlength="6"  type="number" name="pincode" placeholder="Pincode"  required>
          </div>
        </div>
	
      </div>
      <div class="tile-footer">
        
      </div>
   
  </div>
</div>



<div class="col-md-6">
  <div class="tile">
   <h4>Billing & Shipping</h4>
  <hr />
  <h4>Billing</h4>
   <hr />
    <form class="form-horizontal" method="post" action="" enctype="multipart/form-data">
      <div class="tile-body">
        <div class="form-group row">
          <label class="control-label col-md-3"> Address </label>
           <div class="col-md-8">
            <textarea name="billing_address" class="form-control" required></textarea>
          </div>
        </div>
        
		
		<div class="form-group row">
          <label class="control-label col-md-3">City </label>
           <div class="col-md-8">
            <input class="form-control " type="text" name="billing_city" placeholder=" City"  required>
          </div>
        </div>
		
		<div class="form-group row">
          <label class="control-label col-md-3"> State </label>
           <div class="col-md-8">
            <input class="form-control " type="text" name="billing_state" placeholder=" State"  required>
          </div>
        </div>
		
		
		<div class="form-group row">
          <label class="control-label col-md-3"> Pincode </label>
           <div class="col-md-8">
            <input class="form-control" maxlength="6"  type="number" name="billing_pincode" placeholder=" Pincode"  required>
          </div>
        </div>
		
		
	<div class="form-group row">
          <label class="control-label col-md-3"> Country </label>
           <div class="col-md-8">
         <select name="billing_country" id="billing_country" class="form-control" required>
		  <option value="">Select</option>
		 <?php
		 $sql_country=$this->db->query('SELECT * FROM country');
		 $country=$sql_country->result();
		 foreach($country as $cont){?>
		  <option value="<?php echo $cont->nicename;?>"><?php echo $cont->nicename;?></option>
		 <?php }?>
		  
		 </select>
          </div>
        </div>	
      
  <h4>Shipping</h4>
  <hr />
   <div class="form-group row">
          <label class="control-label col-md-3"> Address </label>
           <div class="col-md-8">
            <textarea name="shipping_address" class="form-control" required></textarea>
          </div>
        </div>
        
		
		<div class="form-group row">
          <label class="control-label col-md-3">City </label>
           <div class="col-md-8">
            <input class="form-control " type="text" name="shipping_city" placeholder=" City"  required>
          </div>
        </div>
		
		<div class="form-group row">
          <label class="control-label col-md-3"> State </label>
           <div class="col-md-8">
            <input class="form-control " type="text" name="shipping_state" placeholder=" State"  required>
          </div>
        </div>
		
		
		<div class="form-group row">
          <label class="control-label col-md-3"> Pincode </label>
           <div class="col-md-8">
            <input class="form-control" maxlength="6"  type="number" name="shipping_pincode" placeholder=" Pincode"  required>
          </div>
        </div>
		
		
	<div class="form-group row">
          <label class="control-label col-md-3"> Country </label>
           <div class="col-md-8">
         <select name="shipping_country" id="shipping_country" class="form-control" required>
		  <option value="">Select</option>
		 <?php
		 $sql_country=$this->db->query('SELECT * FROM country');
		 $country=$sql_country->result();
		 foreach($country as $cont){?>
		  <option value="<?php echo $cont->nicename;?>"><?php echo $cont->nicename;?></option>
		 <?php }?>
		  
		 </select>
          </div>
        </div>	       
        
        
        
        
      </div>
      <div class="tile-footer">
        <div class="row">
          <div class="  col-md-offset-3">
            <button class="btn btn-primary" type="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>Add</button>
        <a class="btn btn-secondary" href="<?=base_url('Admin/customer_list')?>"><i class="fa fa-fw fa-lg fa-times-circle"></i>Back</a> </div>
        </div>
      </div>
    </form>
  </div>
</div>
</main>

<script type="text/javascript">
$(document).ready(function(){
    $('#select_all').on('click',function(){
        if(this.checked){
            $('.checkbox').each(function(){
                this.checked = true;
            });
        }else{
             $('.checkbox').each(function(){
                this.checked = false;
            });
        }
    });
    
    $('.checkbox').on('click',function(){
        if($('.checkbox:checked').length == $('.checkbox').length){
            $('#select_all').prop('checked',true);
        }else{
            $('#select_all').prop('checked',false);
        }
    });
	
	
	
	
	
	 $('#item_select').on('click',function(){
        if(this.checked){
            $('.items').each(function(){
                this.checked = true;
            });
        }else{
             $('.items').each(function(){
                this.checked = false;
            });
        }
    });
    
    $('.items').on('click',function(){
        if($('.items:checked').length == $('.items').length){
            $('#item_select').prop('checked',true);
        }else{
            $('#item_select').prop('checked',false);
        }
    });
});
</script>
