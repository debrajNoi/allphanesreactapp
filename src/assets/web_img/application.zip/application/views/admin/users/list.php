<?php 
error_reporting(0);?>
<style>
    .fa{
        font-size:20px;
        cursor:pointer;
    }
	.badge{
	color: white;
    font-size: 12px;
	width:100%;
	}
</style>
<main class="app-content">
      <div class="app-title">
        <div>
          <h1>User List</h1>
         
        </div>
        <ul class="app-breadcrumb breadcrumb side">
          <!--<li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item">Admin</li>
          <li class="breadcrumb-item active"><a href="#">User List</a></li>-->
          
		  
		 <!-- <a href="<?=base_url('Admin/customer_add')?>"><button class="btn btn-primary" type="button">Add New Customer</button></a-->
		
        </ul>
      </div>
     
     
      <div class="row">
        <div class="col-md-12">
		<div class="row" style="margin-left: 22%;margin-top: -17px;padding-bottom: 6px;">
		<div class="com-md-3"></div>
		
		</div>
		</div>
		<div class="col-md-12">
          <div class="tile">
            <div class="tile-body" style="overflow-x:auto;">

            	<pre><?php //print_r($user_list)?></pre>

              <table class="table table-hover table-bordered" id="sampleTable">
                <thead>
                  <tr>
                  	<th>ID</th>
										<!-- <th>User Type</th> -->
										<th>Name</th>
										<th>Email</th>
										<th>Mobile</th>
										<!-- <th>Company</th> -->
										<!-- <th>Neighborhood</th> -->
										<th>City</th>
										<th>State</th>
										<th>Pincode</th>
										<th>Registered on</th>
										<th>Action</th>
                  </tr>
                </thead>
                <tbody>
	                <?php 
											
										$today=date('Y-m-d');
										$i=1;
						
										foreach($user_list as $user)
										{
						   
									?>
                  <tr>
                    <td><?=$i;?></td>
										<!-- <td> -->
						    		<?php
						    			// if($user->user_type=='Vendor'){$user_type='Selling Brand New EV'; }
						      	// 	if($user->user_type=='Charger Vendor'){$user_type='Selling used EV'; }  
						      	?> 
						        
						    		<?//=$user_type?>
						    		<!-- </td>					    			 -->
                    <td><?=$user->vendor_name?></td>
                    <td><?=$user->email?></td>
										<td><?=$user->mobile?></td>
										<!-- <td><?=$user->company_name?></td> -->
										<!-- <td><?=$user->neighborhood?></td> -->
										<td><?=$user->city_name?></td>
										<td><?=$user->state_name?></td>
										<td><?=$user->pincode?></td>
										<td><?=date('d-m-Y',strtotime($user->dated));?></td>
						 
										<td>
											<div class="d-flex">
												<?php if($user->status==1){ $text="Active"; $status="on"; $style="color:green;cursor:pointer;font-size: 34px";}
												if($user->status==0){$text="Inactive"; $status="off"; $style="color:red;cursor:pointer;font-size: 34px";}?>
												<i onclick="ChanageStatus('<?php echo $user->user_id;?>', '<?php echo $user->status;?>');" style="<?php echo $style;?>" class="fa fa-toggle-<?php echo $status;?>" aria-hidden="true" title="<?php echo $text;?>"></i>
												<a href="<?php echo base_url('Admin/edit_user/'.$user->user_id);?>" style="margin-top: 8px; margin-left: 5px;"><i class="fa fa-edit"></i></a>
												<a onclick="delete_user(<?=$user->user_id?>)" class="" style="margin-top: 6px; margin-left: 5px;">
				                  <i class="fa fa-trash-o" aria-hidden="true"></i>
		                    </a>
											</div>
										</td>
                  </tr>
                	<?php $i++; } ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </main>
	
	
	



	
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	

	
<script>

function delete_user(id)
{
	if (confirm('Are you sure you want to delete this user?'))
	{
		$.ajax({
			url: "<?=base_url('Admin/delete_user')?>",
			type: "POST",		
			data:  {id:id},
			success: function(data)
			{		
				var obj= JSON.parse(data);
				var success=obj.success;
				var message=obj.message; 
				if(success=='1')
				{
					window.location="<?=base_url()?>Admin/user_list";
				}
				else
				{
					window.location="<?=base_url()?>Admin/user_list";
				}
			}
		});	
	}
}




<?php
if($this->session->flashdata('error')){?>
   swal('Oops!','<?php echo $this->session->flashdata('error');?>','error');
<?php }

if($this->session->flashdata('success')){?>
   swal('success!','<?php echo $this->session->flashdata('success');?>','success');
<?php }?>


function ChanageStatus(id,status){
  if(status==1){ var text="Inactive";}if(status==0){ var text="Active";}
 swal({
      title: "Are you sure want to "+text+"?" ,
      text: "",
      icon: "warning",
      buttons: [
        'Cancel',
        'OK'
      ],
      dangerMode: true,
    }).then(function(isConfirm) {
      if (isConfirm) {
        swal({
          title: 'Success!',
          text: text+' successfully',
          icon: 'success'
        }).then(function() {
		var table="users";
	
          $.post("<?php echo base_url('Admin/ChangeStatus')?>",{table:table,id:id,status:status},function(data){
		  window.location.reload();
		   console.log(data);
			
		  });
        });
      } else {
        //swal("Cancelled", "Your imaginary file is safe :)", "error");
      }
    })
}


</script>

