<?php 

error_reporting(0);?>
<style>
    .fa{
        font-size:20px;
        cursor:pointer;
    }
	.badge{
	color: white;
    font-size: 12px;
	width:100%;
	}
</style>
<main class="app-content">
      <div class="app-title">
        <div>
          <h1>All Verified Product List</h1>
        
        </div>
        <ul class="app-breadcrumb breadcrumb side">
          <!--<li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item">Admin</li>
          <li class="breadcrumb-item active"><a href="#">User List</a></li>-->
          
		  
		  <!--<a href="<?=base_url('admin/product_add')?>"><button class="btn btn-primary" type="button">Add New Product</button></a>--></ul>
      </div>
     
     
      <div class="row">
        <div class="col-md-12">
		<div class="row" style="margin-left: 22%;margin-top: -17px;padding-bottom: 6px;">
		<div class="com-md-3"></div>
		
		</div>
		</div>
		<div class="col-md-12">
          <div class="tile">
            <div class="tile-body" style="overflow-x:auto;">
              <table class="table table-hover table-bordered" id="sampleTable">
                <thead>
                  <tr>
                  	<th>ID</th>
					<th>Company Name</th>
					<th>Vendor Name</th>
					<th>City</th>
                  	
					<th>Brand</th>
					
					 <th>Model</th>
					<th>Top Speed</th>
					
					
					<th>Price</th>
					<th>Active / Inactive</th>
					<th>Popular</th>
					<th>Featured Premium</th>
					<th>Hot & happening</th>
					<th>Action</th>
                  </tr>
                </thead>
                <tbody>
                    <?php 
					
					$today=date('Y-m-d');
					$i=1;
					
					foreach($product_list as $list)
					{
					   $sql_vendor = $this->db->query('SELECT * FROM users WHERE id="'.$list->vendor_id.'"');
					   $vendor = $sql_vendor->row();
					?>
                      <tr>
                        <td><?=$i;?></td>
												<td><?=$vendor->model;?></td>
												<td><?=$vendor->brand;?></td>
                         <td><?=$list->location;?></td>
												 <td><?=$list->brand;?></td>
						                        
												 <td><?=$list->model;?></td>
												 <td><?=$list->top_speed;?></td>
						                      	 
						                        
												<td><?=$list->price;?></td>
												<td>
													<?php if($list->status==1){ $text="Active"; $status="on"; $style="color:green;cursor:pointer;font-size: 34px";}
													if($list->status==0){$text="Inactive"; $status="off"; $style="color:red;cursor:pointer;font-size: 34px";}?>
													<i onclick="ChanageStatus('<?php echo $list->id;?>', '<?php echo $list->status;?>');" style="<?php echo $style;?>" class="fa fa-toggle-<?php echo $status;?>" aria-hidden="true" title="<?php echo $text;?>"></i>
													
													
													</td>
                      
													<td>
														<?php if($list->popular==1){ $text="Active"; $popular_status="on"; $style="color:green;cursor:pointer;font-size: 34px";}
														if($list->popular==0){$text="Inactive"; $popular_status="off"; $style="color:red;cursor:pointer;font-size: 34px";}?>
														<i onclick="ChanagePopularStatus('<?php echo $list->id;?>', '<?php echo $list->popular;?>');" style="<?php echo $style;?>" class="fa fa-toggle-<?php echo $popular_status;?>" aria-hidden="true" title="<?php echo $text;?>"></i>
														
														
														</td>	 
						
														<td>
														
																	<?php if($list->is_featured==1){ $text="Active"; $featured_status="on"; $style="color:green;cursor:pointer;font-size: 34px";}
															if($list->is_featured==0){$text="Inactive"; $featured_status="off"; $style="color:red;cursor:pointer;font-size: 34px";}?>
															<i onclick="ChanagefeaturedStatus('<?php echo $list->id;?>', '<?php echo $list->is_featured;?>');" style="<?php echo $style;?>" class="fa fa-toggle-<?php echo $featured_status;?>" aria-hidden="true" title="<?php echo $text;?>"></i>
															
															</td>
												<td>
												<?php if($list->show_banner==1){ $text="Active"; $publish_status="on"; $style="color:green;cursor:pointer;font-size: 34px";}
												if($list->show_banner==0){$text="Inactive"; $publish_status="off"; $style="color:red;cursor:pointer;font-size: 34px";}?>
												<i onclick="ChanageBannerStatus('<?php echo $list->id;?>', '<?php echo $list->show_banner;?>');" style="<?php echo $style;?>" class="fa fa-toggle-<?php echo $publish_status;?>" aria-hidden="true" title="<?php echo $text;?>"></i>
												
												
												</td>
						 
						  
                        <td align="center">
                          <a href="<?php echo base_url('admin/edit_product/'.$list->id);?>">
                            <i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                          </a>   
                          <a onclick="delete_product(<?=$list->id?>)" class="">
                            <i class="fa fa-trash-o" aria-hidden="true"></i>
                          </a>
                        </td>
                      </tr>
                  	<?php $i++; } ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </main>
	
	
	



	
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	

	
<script>



<?php
if($this->session->flashdata('error')){?>
   swal('Oops!','<?php echo $this->session->flashdata('error');?>','error');
<?php }

if($this->session->flashdata('success')){?>
   swal('success!','<?php echo $this->session->flashdata('success');?>','success');
<?php }?>
function delete_product(id)
{
	if (confirm('Are you sure you want to delete this banner?')) 
	{
		$.ajax({
			url: "<?=base_url('Admin/delete_product')?>",
			type: "POST",		
			data:  {id:id},
			success: function(data)
			{		
				var obj= JSON.parse(data);
				var success=obj.success;
				var message=obj.message; 
				if(success=='1')
				{
					
					window.location="<?=base_url()?>Admin/product_list";
				}
				else
				{
					;
					window.location="<?=base_url()?>Admin/product_list";
				}
			}
		});	
	}
}


function ChanageStatus(id,status){
 swal({
      title: "Are you sure?",
      text: "Status will be changed",
      icon: "warning",
      buttons: [
        'Cancel',
        'OK'
      ],
      dangerMode: true,
    }).then(function(isConfirm) {
      if (isConfirm) {
        swal({
          title: 'Success!',
          text: 'Status has been changed successfully',
          icon: 'success'
        }).then(function() {
		var table="products";
	
          $.post("<?php echo base_url('Admin/ChangeStatus')?>",{table:table,id:id,status:status},function(data){
		    window.location.reload();
			
		  });
        });
      } else {
        //swal("Cancelled", "Your imaginary file is safe :)", "error");
      }
    })
}


function ChanagefeaturedStatus(id,status){
 if(status==0){var msg="Publish on Featured?";}
 if(status==1){var msg="Unpublish on Featured?";}
 swal({
      title: "Are you sure want to "+msg,
      text: "",
      icon: "warning",
      buttons: [
        'Cancel',
        'OK'
      ],
      dangerMode: true,
    }).then(function(isConfirm) {
      if (isConfirm) {
        swal({
          title: 'Success!',
          text: 'Status has been changed successfully',
          icon: 'success'
        }).then(function() {
		var table="products";
	
          $.post("<?php echo base_url('Admin/ChangeFeaturedStatus')?>",{table:table,id:id,status:status},function(data){
		    window.location.reload();
			
		  });
        });
      } else {
        //swal("Cancelled", "Your imaginary file is safe :)", "error");
      }
    })
}

function ChanagePopularStatus(id,status){
 if(status==0){var msg="Publish on Popular Showroom?";}
 if(status==1){var msg="Unpublish on Popular Showroom?";}
 swal({
      title: "Are you sure want to "+msg,
      text: "",
      icon: "warning",
      buttons: [
        'Cancel',
        'OK'
      ],
      dangerMode: true,
    }).then(function(isConfirm) {
      if (isConfirm) {
        swal({
          title: 'Success!',
          text: 'Status has been changed successfully',
          icon: 'success'
        }).then(function() {
		var table="products";
	
          $.post("<?php echo base_url('Admin/ChangePopularStatus')?>",{table:table,id:id,status:status},function(data){
		    window.location.reload();
			
		  });
        });
      } else {
        //swal("Cancelled", "Your imaginary file is safe :)", "error");
      }
    })
}



function ChanageBannerStatus(id,status){
 if(status==0){var msg="Publish on Hot n Happening Showroom?";}
 if(status==1){var msg="Unpublish on Hot n Happening Showroom?";}
 swal({
      title: "Are you sure want to "+msg,
      text: "",
      icon: "warning",
      buttons: [
        'Cancel',
        'OK'
      ],
      dangerMode: true,
    }).then(function(isConfirm) {
      if (isConfirm) {
        swal({
          title: 'Success!',
          text: 'Status has been changed successfully',
          icon: 'success'
        }).then(function() {
		var table="products";
	
          $.post("<?php echo base_url('Admin/ChangeBannerStatus')?>",{table:table,id:id,status:status},function(data){
		    window.location.reload();
			
		  });
        });
      } else {
        //swal("Cancelled", "Your imaginary file is safe :)", "error");
      }
    })
}


</script>

