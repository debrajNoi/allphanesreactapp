<main class="app-content">
<style>
.fa{
cursor:pointer;
}
.img-thumbnail{
    border: 2px solid #3f51b5;
	    height: 85px;
    width: 100px;
 }
 .lbl{
     margin-left: 56px;
}
</style>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<div class="app-title">
  <div>
    <h1><i class="fa fa-plus"></i> Edit Product</h1>
  </div>
  <ul class="app-breadcrumb breadcrumb">
    <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
    <li class="breadcrumb-item">Admin</li>
    <li class="breadcrumb-item"><a href="#">Edit Product</a></li>
  </ul>
</div>

<section>
  <div class="scooter-upload">
    <div class=" container">
      <div class="row">
        
        <form method="post"  class="row" enctype="multipart/form-data">
          <div class="col-md-5">
            <div class="">
              <div class="row">
                
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Year</label>
                    <input type="text" class="form-control date-own" id="year" name="year" required placeholder="Year" value="<?php echo $product->year;?>">
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Make/Brand</label>
                    <input type="text" class="form-control" id="brand" name="brand" placeholder="Brand/Company/Shop Name" value="<?php echo $product->brand;?>" required>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Model</label>
                    <input type="text" class="form-control" name="model" id="model" placeholder="Model" value="<?php echo $product->model;?>" required>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Socket Type</label>
                    <input type="text" class="form-control" name="socket_type" id="socket_type" placeholder="Socket Type" value="<?php echo $product->socket_type;?>" required>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Battery Type</label>
                    <div class="select-style">
                      <select class="form-control" name="battery_type" required>
                        <option value="">Select</option>
                        <option value="Lead acid" <?php if($product->battery_type=='Lead acid'){?> selected="selected"<?php }?>>Lead acid </option>
                        <option value="Lithium ion" <?php if($product->battery_type=='Lithium ion'){?> selected="selected"<?php }?>>Lithium ion</option>
                       
                      </select>
                    </div>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Motor Type</label>
                    <div class="select-style">
                      <select class="form-control" name="motor_type" required>
                        <option value="">Select </option>
                        <option value="Brushed" <?php if($product->motor_type=='Brushed'){?> selected="selected"<?php }?>>Brushed</option>
                        <option value="Brushless" <?php if($product->motor_type=='Brushless'){?> selected="selected"<?php }?>>Brushless</option>
                        <option value="Hubless" <?php if($product->motor_type=='Hubless'){?> selected="selected"<?php }?>>Hubless</option>
                        <option value="Hub" <?php if($product->motor_type=='Hub'){?> selected="selected"<?php }?>>Hub</option>
                      </select>
                    </div>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Range</label>
                    <input type="text" class="form-control" id="range" name="range" required placeholder="Range" value="<?php echo $product->product_range;?>">
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Charging Time</label>
                    <input type="text" class="form-control" id="charging_time" name="charging_time" placeholder="Charging Time" value="<?php echo $product->charging_time;?>">
                  </div>
                </div>
				
				<div class="col-md-12">
                  <div class="form-group">
                    <label>Price</label>
                    <input type="text" class="form-control" name="price" id="price" required placeholder="Price" value="<?php echo $product->price;?>">
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-2"></div>

          <div class="col-md-5">
            <div class="">
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group form-group-sm">
                    <label>Starting</label>
                    <div class="select-style">
                      <select class="form-control" name="starting" required>
                        <option value="">Select</option>
                        <option value="Kick" selected="selected"> Kick</option>
                       
                      </select>
                    </div>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Safety features</label>
                    <input type="text" class="form-control" id="safety_features" name="safety_features" required placeholder="Safety features" value="<?php echo $product->safety_features;?>">
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Sensors</label>
                    <input type="text" class="form-control" id="sensors" name="sensors" required placeholder="Sensors" value="<?php echo $product->sensors;?>">
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Chassis and Suspension</label>
                    <input type="text" class="form-control" id="chassis_suspension" name="chassis_suspension" required placeholder="Chassis and Suspension" value="<?php echo $product->chassis_suspension;?>">
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Tyres and Wheels</label>
                    <input type="text" class="form-control" id="tyres" name="tyres" required placeholder="Tyres and Wheels" value="<?php echo $product->tyres;?>">
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Brakes</label>
                    <div class="select-style">
                      <select class="form-control" name="break_type" required>
                        <option value="">Select</option>
                        <option value="Cable Disk" <?php if($product->break_type=='Cable Disk'){?> selected="selected"<?php }?>>Cable Disk</option>
                        <option value="Hydraulic" <?php if($product->break_type=='Hydraulic'){?> selected="selected"<?php }?>>Hydraulic</option>
                        <option value="Semi-hydraulic" <?php if($product->break_type=='Semi-hydraulic'){?> selected="selected"<?php }?>>Semi-hydraulic</option>
                        <option value="Drum" <?php if($product->break_type=='Drum'){?> selected="selected"<?php }?>>Drum</option>
                      </select>
                    </div>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Enter Standard Warranty</label>
                    <div class="select-style">
                      <select name="warranty" class="form-control" required>
                        <option value="">Select</option>
                        <option value="1 Year" <?php if($product->warranty=='1 Year'){?> selected="selected"<?php }?>>1 Year</option>
                        <option value="2 Years" <?php if($product->warranty=='2 Years'){?> selected="selected"<?php }?>>2 Years</option>
                        <option value="3 Years" <?php if($product->warranty=='3 Years'){?> selected="selected"<?php }?>>3 Years</option>
                       
                      </select>
                    </div>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Location</label>
					<select name="location" class="form-control" required>
					<option value="">Select</option>
					<?php
					$sql_cities=$this->db->query('SELECT * FROM cities ORDER BY city ASC');
					$cities=$sql_cities->result();
					foreach($cities as $city){?>
                   <option value="<?php echo $city->city;?>" <?php if($product->location==$city->city){?> selected="selected"<?php }?>><?php echo $city->city;?></option>
					<?php }?>
					</select>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Description</label>
					<textarea name="description" required style="width:100%;"><?php echo $product->description;?></textarea>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-12 mb-4">
            <h4 class="text-up-ph-1">Upload Photos</h4>
            <p class="text-up-ph-2">(Upload phoes that showcase your EV from front, back, sides. Use a couple of close-ups for best results.
              Upload only .JPEG and .PNG files.</p>
          </div>
          <div class="col-md-4 mb-3">
            <div class="up-img-box">
              <div class="img-box">
			 <img id="FrontFrame" src="<?php echo base_url('uploads/products/'.$product->front_view);?>" class="img-thumbnail" style="width:63%; height:169px;"/>
			  </div>
              <p>
			  <label for="front_view" class="btn lbl">Front view</label>
			  <input type="hidden" name="old_front_view" value="<?php echo $product->front_view;?>" />
			  <input id="front_view" style="visibility:hidden;" name="front_view"  type="file" onchange="FrontView()" accept="image/jpg, image/jpeg,image/png">
			  </p>
            </div>
          </div>
          <div class="col-md-4 mb-3">
            <div class="up-img-box">
              <div class="img-box">
			  <img id="SideFrame1" src="<?php echo base_url('uploads/products/'.$product->side_view1);?>" class="img-thumbnail" style="width:63%; height:169px;"/>
			  </div>
              <p> <label for="side_view1" class="btn lbl">Side view 1</label>
			  <input type="hidden" name="old_side_view1" value="<?php echo $product->side_view1;?>" />
			   <input id="side_view1" style="visibility:hidden;" type="file" name="side_view1"  onchange="SideView1()" accept="image/jpg, image/jpeg,image/png">
			  </p>
            </div>
          </div>
          <div class="col-md-4 mb-3">
            <div class="up-img-box">
              <div class="img-box">
			   <img id="SideFrame2" src="<?php echo base_url('uploads/products/'.$product->side_view2);?>" class="img-thumbnail" style="width:63%; height:169px;"/>
			  </div>
             <p> <label for="side_view2" class="btn lbl">Side view 2</label>
			  <input type="hidden" name="old_side_view2" value="<?php echo $product->side_view2;?>" />
			   <input id="side_view2" style="visibility:hidden;" type="file" name="side_view2"  onchange="SideView2()" accept="image/jpg, image/jpeg,image/png">
			  </p>
            </div>
          </div>
		  
          <div class="col-md-4 mb-3">
            <div class="up-img-box">
              <div class="img-box">
			   <img id="SideFrame3" src="<?php echo base_url('uploads/products/'.$product->rear_view);?>" class="img-thumbnail" style="width:63%; height:169px;"/>
			  </div>
             <p> <label for="rear_view" class="btn lbl">Rear view</label>
			  <input type="hidden" name="old_rear_view" value="<?php echo $product->rear_view;?>" />
			   <input id="rear_view" style="visibility:hidden;" type="file" name="rear_view"  onchange="RearView()" accept="image/jpg, image/jpeg,image/png">
			  </p>
            </div>
          </div>
		  
          <div class="col-md-4 mb-3">
            <div class="up-img-box">
              <div class="img-box">
			   <img id="SideFrame4" src="<?php echo base_url('uploads/products/'.$product->close_up1);?>" class="img-thumbnail" style="width:63%; height:169px;"/>
			  </div>
             <p> <label for="close_up1" class="btn lbl">Close-up 1</label>
			 <input type="hidden" name="old_close_up1" value="<?php echo $product->close_up1;?>" />
			   <input id="close_up1" style="visibility:hidden;" type="file" name="close_up1"  onchange="CloseUp1()" accept="image/jpg, image/jpeg,image/png">
			  </p>
            </div>
          </div>
		  
          <div class="col-md-4 mb-3">
            <div class="up-img-box">
              <div class="img-box">
			   <img id="SideFrame5" src="<?php echo base_url('uploads/products/'.$product->close_up2);?>" class="img-thumbnail" style="width:63%; height:169px;"/>
			  </div>
             <p> <label for="close_up2" class="btn lbl">Close-up 2</label>
			  <input type="hidden" name="old_close_up2" value="<?php echo $product->close_up2;?>" />
			   <input id="close_up2" style="visibility:hidden;" type="file" name="close_up2"  onchange="CloseUp2()" accept="image/jpg, image/jpeg,image/png">
			  </p>
            </div>
          </div>
          <div class="col-md-12" align="right"><hr /> <button type="submit" class=" btn btn-primary signup text-left" style="display:inline-block;">Update</button>
            <!--<p class="repli-mes">Thank you for submitting your EV. We will review it and if all is in good shape, it will be publised within 1 working day. Or else, we will get in touch with you for required information.</p>-->
          </div>
        </form>
		
		
      </div>
    </div>
    <div class="clearfix"></div>
  </div>
</section>



</main>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/js/bootstrap-datepicker.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/css/bootstrap-datepicker.css" rel="stylesheet"/>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<script>
<?php
if($this->session->flashdata('success')){?>
swal('Success','<?php echo $this->session->flashdata('success');?>','success');
<?php }?>
function FrontView() {
    FrontFrame.src=URL.createObjectURL(event.target.files[0]);
}

function SideView1() {
    SideFrame1.src=URL.createObjectURL(event.target.files[0]);
}

function SideView2() {
    SideFrame2.src=URL.createObjectURL(event.target.files[0]);
}

function RearView() {
    SideFrame3.src=URL.createObjectURL(event.target.files[0]);
}

function CloseUp1() {
    SideFrame4.src=URL.createObjectURL(event.target.files[0]);
}

function CloseUp2() {
    SideFrame5.src=URL.createObjectURL(event.target.files[0]);
}

$('.date-own').datepicker({
         format: " yyyy", // Notice the Extra space at the beginning
         viewMode: "years", 
       minViewMode: "years"
       });
</script>
