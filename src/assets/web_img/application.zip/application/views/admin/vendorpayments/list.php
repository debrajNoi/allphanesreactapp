<?php 

error_reporting(0);?>

<style>

	.fa{

		font-size:20px;

		cursor:pointer;

	}

	.badge{

		color: white;

		font-size: 12px;

		width:100%;

	}

</style>

<main class="app-content">

  <div class="app-title">

    <div>

      <h1> Vendor Payments List</h1>

    </div>

    <ul class="app-breadcrumb breadcrumb side"></ul>

  </div>


  <div class="row">

    <div class="col-md-12">

			<div class="row" style="margin-left: 22%;margin-top: -17px;padding-bottom: 6px;">

				<div class="com-md-3">
					
				</div>

			</div>

		</div>

		<div class="col-md-12">

      <div class="tile">

        <div class="tile-body" style="overflow-x:auto;">

        	<!-- <pre><?php print_r($request_list); ?></pre> -->

          <table class="table table-hover table-bordered" id="sampleTable">

            <thead>

              <tr>

								<th>ID</th>

								<th>Name</th>

								<th>Email</th>

								<th>Mobile</th>

								<!--<th>Whatsapp</th>-->

								<th>City</th>
								<th>Payment Details</th>

								<!--<th>End Date</th>-->

              </tr>

            </thead>

            <tbody>

              <?php 

								$today=date('Y-m-d');

								$i=1;

								foreach($request_list as $list)
								{
									

							?>

              	<tr>

									<td><?=$list->payment_user;?></td>
									<td><?=$list->name;?></td>
									<td><?=$list->email;?></td>
									<td><?=$list->mobile;?></td>
									<td><?=$list->city;?></td>
									<td>
									    <a href="<?=base_url('Admin/vendor_payment_details/').$list->payment_user.'/website';?>" class="btn btn-primary">Websites</a>
									    <a href="<?=base_url('Admin/vendor_payment_details/').$list->payment_user.'/claimed'?>" class="btn btn-primary">Claimed Products</a>
									    <a href="<?=base_url('Admin/vendor_payment_details/').$list->payment_user.'/verification'?>" class="btn btn-primary">Verified Products</a>
									</td>

									<!--<td><?=$list->whatsapp;?></td>-->

									

                </tr>

            	<?php $i++; } ?>

            </tbody>

          </table>

        </div>

      </div>

    </div>

  </div>

</main>

	

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>

<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	

<script>

	function DoRenew(user_id){

		if (confirm('Are you sure you want to Renew this banner?')) 

		{

			$.ajax({

				url: "<?=base_url('Admin/user_renew')?>",

				type: "POST",		

				data:  {user_id:user_id},

				success: function(data)

				{		

					var obj= JSON.parse(data);

					var success=obj.success;

					var message=obj.message; 

					if(success=='1')

					{
						window.location="<?=base_url()?>Admin/banner_list";
					}
					else
					{
						window.location="<?=base_url()?>Admin/banner_list";
					}

				}

			});	

		}

	}





<?php

if($this->session->flashdata('error')){?>

   swal('Oops!','<?php echo $this->session->flashdata('error');?>','error');

<?php }



if($this->session->flashdata('success')){?>

   swal('success!','<?php echo $this->session->flashdata('success');?>','success');

<?php }?>

function delete_banner(id)

{

	if (confirm('Are you sure you want to delete this banner?')) 

	{

		$.ajax({

			url: "<?=base_url('Admin/delete_banner')?>",

			type: "POST",		

			data:  {id:id},

			success: function(data)

			{		

				var obj= JSON.parse(data);

				var success=obj.success;

				var message=obj.message; 

				if(success=='1')
				{
					window.location="<?=base_url()?>Admin/banner_list";
				}
				else
				{					
					window.location="<?=base_url()?>Admin/banner_list";
				}

			}

		});	

	}

}





function ChanageStatus(id,status){

 swal({

      title: "Are you sure?",

      text: "Status will be change",

      icon: "warning",

      buttons: [

        'Cancel',

        'OK'

      ],

      dangerMode: true,

    }).then(function(isConfirm) {

      if (isConfirm) {

        swal({

          title: 'Success!',

          text: 'Status has been changed successfully',

          icon: 'success'

        }).then(function() {

				var table="banners";

        $.post(
        	"<?php echo base_url('Admin/ChangeStatus')?>",
        	{
        		table:table,
        		id:id,
        		status:status
        	},
        	function(data){
		    		window.location.reload();
		  		});
        });
      } else {
        //swal("Cancelled", "Your imaginary file is safe :)", "error");
      }

    })

}

</script>