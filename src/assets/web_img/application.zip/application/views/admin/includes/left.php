<style>

.fa-android{

	color:red;

}

</style>

<div class="app-sidebar__overlay" data-toggle="sidebar"></div>

   <aside class="app-sidebar" style="box-shadow: none;">

  <?php  $user_type=$this->session->userdata('user_type');

 $cont= $this->router->fetch_class();

  $method=$this->router->fetch_method();

  //echo $method;

  

  ?>

      <ul class="app-menu">

        <li><a class="app-menu__item" href="<?=base_url()?>Admin/dashboard"><i class="app-menu__icon fa fa-dashboard"></i><span class="app-menu__label">Dashboard</span></a></li>

		

				<li class="treeview <?php if($method=='terms_conditions' || $method=='contact_us' || $method=='about_us' || $method=='partner_with_us' || $method == 'sell' || $method == 'pricing' || $method == 'privacy_policy' || $method == 'cancellation_policy' || $method == 'privacy_policy' || $method == 'home'){?> is-expanded <?php }?>"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-globe"></i><span class="app-menu__label"> Manage Website</span><i class="treeview-indicator fa fa-angle-right"></i></a>

        <ul class="treeview-menu">

				  <li>
				  	<a class="treeview-item" data-toggle="treeview" href="#">
				  		<i class="fa fa-usd" aria-hidden="true"></i> &nbsp Pricing
				  	</a>
		        <ul class="treeview-menu-pricing">
						  <li>
						  	<a class="treeview-item" href="<?=base_url('Admin/pricing_free_listing')?>">
						  		<i class="icon fa fa-file-text-o"></i>Free
						  	</a>
					  	</li>
						  <li>
						  	<a class="treeview-item" href="<?=base_url('Admin/pricing_featured_listing')?>">
						  		<i class="icon fa fa-file-text-o"></i>Featured
						  	</a>
					  	</li>
						  <li>
						  	<a class="treeview-item" href="<?=base_url('Admin/pricing_hot_listing')?>">
						  		<i class="icon fa fa-file-text-o"></i>Hot & Happening
						  	</a>
					  	</li>
					  </ul>
			  	</li>
			  	
			  	    <li><a class="treeview-item" href="<?=base_url('Admin/pricing')?>"><i class="icon fa fa-file-text-o"></i>Pricing</a></li>
				  
				  <li><a class="treeview-item" href="<?=base_url('Admin/home')?>"><i class="icon fa fa-file-text-o"></i>Home</a></li>
				  <li><a class="treeview-item" href="<?=base_url('Admin/about_us')?>"><i class="icon fa fa-file-text-o"></i>About Us</a></li>

				 <li><a class="treeview-item" href="<?=base_url('Admin/contact_us')?>"><i class="icon fa fa-file-text-o"></i>Contact Us</a></li>

				  <li><a class="treeview-item" href="<?=base_url('Admin/terms_conditions')?>"><i class="icon fa fa-file-text-o"></i>Terms & Conditions</a></li>

				  <li><a class="treeview-item" href="<?=base_url('Admin/privacy_policy')?>"><i class="icon fa fa-file-text-o"></i> Privacy Policy </a></li>

				  <li><a class="treeview-item" href="<?=base_url('Admin/cancellation_policy')?>"><i class="icon fa fa-file-text-o"></i> Cancellation Policy </a></li>
				  
				  <li><a class="treeview-item" href="<?=base_url('Admin/sell')?>"><i class="icon fa fa-file-text-o"></i>Sell</a></li>
				  <li><a class="treeview-item" href="<?=base_url('Admin/partner_with_us')?>"><i class="icon fa fa-file-text-o"></i>Partner With Us</a></li>

		 		</ul>

		 </li>


		<li class="treeview <?php if($method=='product_list' || $method=='product_add' || $method=='product_edit' ){?> is-expanded <?php }?>"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-product-hunt"></i><span class="app-menu__label"> Manage Products</span><i class="treeview-indicator fa fa-angle-right"></i></a>

      <ul class="treeview-menu">

		  	<li><a class="treeview-item" href="<?=base_url('admin/product_list')?>"><i class="icon fa fa-list"></i>Product List</a></li>

		  <!--<li><a class="treeview-item" href="<?=base_url('admin/product_add')?>"><i class="icon fa fa-plus"></i> Product Add</a></li>-->

		 	</ul>

	 	</li> 
		  


		 

	 	<li><a class="app-menu__item" href="<?=base_url()?>Admin/vendor_list"><i class="app-menu__icon fa fa-user"></i><span class="app-menu__label">Vendor List</span></a></li>

	 	<!-- <li><a class="app-menu__item" href="<?=base_url()?>Admin/vendor_details"><i class="app-menu__icon fa fa-user-circle-o"></i><span class="app-menu__label">Vendor Details</span></a></li> -->


	 	<li><a class="app-menu__item" href="<?=base_url()?>Admin/user_list"><i class="app-menu__icon fa fa-address-card-o"></i><span class="app-menu__label"> User List</span></a></li>


	 	<li><a class="app-menu__item" href="<?=base_url()?>Admin/verfied_product_list"><i class="app-menu__icon fa fa-address-card-o"></i><span class="app-menu__label"> Verfied Product List</span></a></li>


	 	<li><a class="app-menu__item" href="<?=base_url()?>Admin/claimed_product_list"><i class="app-menu__icon fa fa-address-card-o"></i><span class="app-menu__label"> Claimed Product List</span></a></li>


  	<li><a class="app-menu__item" href="<?=base_url()?>Admin/booking_requests"><i class="app-menu__icon fa fa-smile-o"></i><span class="app-menu__label">Booking Requests</span></a></li>


  	<li><a class="app-menu__item" href="<?=base_url()?>Admin/website_free_trials"><i class="app-menu__icon fa fa-smile-o"></i><span class="app-menu__label">Website Free Trials</span></a></li>

  	<!--<li><a class="app-menu__item" href="<?=base_url()?>Admin/payments"><i class="app-menu__icon fa fa-product-hunt"></i><span class="app-menu__label">Payments</span></a></li>-->
  	
  	<li><a class="app-menu__item" href="<?=base_url()?>Admin/vendor_payments"><i class="app-menu__icon fa fa-product-hunt"></i><span class="app-menu__label">Vendor Payments</span></a></li>

		 

		 

	<!--	<li class="treeview <?php if($method=='counselor_list' || $method=='add_counselor' || $method=='counselor_edit' ){?> is-expanded <?php }?>"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-user-o"></i><span class="app-menu__label"> Manage Counselor</span><i class="treeview-indicator fa fa-angle-right"></i></a>

          <ul class="treeview-menu">

		 

		 

		  <li><a class="treeview-item" href="<?=base_url('Admin/counselor_list')?>"><i class="icon fa fa-list"></i>Counselor List</a></li>

		  <li><a class="treeview-item" href="<?=base_url('Admin/add_counselor')?>"><i class="icon fa fa-plus"></i> Counselor Add</a></li>

		 </ul>

		  

		 </li> 

		 

	

	<li class="treeview <?php if($method=='country_list' || $method=='university_list' || $method=='course_list' ){?> is-expanded <?php }?>"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-database"></i><span class="app-menu__label">Masters</span><i class="treeview-indicator fa fa-angle-right"></i></a>

          <ul class="treeview-menu">

		 

		 

		  <li><a class="treeview-item <?php if($method=='country_list'){?>active<?php }?>" href="<?=base_url('Admin/country_list')?>"><i class="icon fa fa-flag"></i>Manage Country</a></li>

		  <li><a class="treeview-item <?php if($method=='university_list'){?>active<?php }?>" href="<?=base_url('Admin/university_list')?>"><i class="icon fa fa-university"></i> Manage University</a></li>

		  <li><a class="treeview-item <?php if($method=='course_list'){?>active<?php }?>" href="<?=base_url('Admin/course_list')?>"><i class="icon fa fa-book"></i> Manage Course</a></li>

		 </ul>

		  

		 </li>-->

		   

		 

      </ul>

    </aside>