<section>
  <div class="registration-sec">
    <div class="container ">
    <h1>Please Sign up to sell and buy EVs</h1>
</div>
 
  <div class="form-sec">
     <form method="post" action="#" onsubmit="return checkForm(this);">
        <div class="row">
                <div class="col-md-12">
				<?php
				if($this->session->flashdata('success')){?>
				<div class="alert alert-success"><?php echo $this->session->flashdata('success');?></div>
				<?php }?>
				
                    <div class="form-group form-group-sm">
                       
                      <div class="select-style">
                        <select name="user_type" required>
                            <option value="">Select</option>
                          <option value="Vendor">I am a 2 Wheeler Vendor </option>
                          <option value="Charger Vendor">I am a Charger Vendor</option>
                          <option value="Customer">I am a User</option>
                         
                        </select>
                      </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="form-group">
                       
                        <input type="text" class="form-control" id="name" name="name" placeholder="Full Name" required>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="form-group">
                       
                        <input type="text" class="form-control" id="company_name" name="company_name" placeholder="Brand/Company/Shop Name" requied>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="form-group">
                       
                        <input type="email" class="form-control" id="email" name="email" placeholder="Email" required>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="form-group">
                       
                        <input type="number" class="form-control" id="mobile" name="mobile" maxlength="10" placeholder="Phone" required>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="form-group">
                       
                       <div class="select-style">
                            <select name="city" required>
                                <option value="">Select city</option>
                              <option value="Pune">Pune</option>
                              <option value="Kolkata">Kolkata</option>
                              <option value="Patna">Patna</option>
                              <option value="Katak">Katak</option>
                            </select>
                          </div>
                                              </div>
                </div>
                <div class="col-md-12">
                    <div class="form-group">
                       
                        <div class="select-style">
                          <select name="state" required>
                              <option value="">Select State</option>
                            <option value="West Bengal">West Bengal</option>
                            <option value="Mumbai">Mumbai</option>
                            <option value="Delhi">Delhi</option>
                            <option value="Punjab">Punjab</option>
                          </select>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="form-group">
                       
                        <input type="text" class="form-control" id="neighborhood" name="neighborhood" placeholder="Neighborhood">
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="form-group">
                       
                        <input type="text" class="form-control" id="pincode" name="pincode" maxlength="6" placeholder="Pincode" required>
                    </div>
                </div>

                    <div class="col-md-12">
                    <div class="form-group">
                    <fieldset>
                   
                    <label for="accessible" class="trem-sec"> 
                      <input type="checkbox" name="terms" required > I accept the <span>Terms and Condition</span>
                    </label>
                  </fieldset>
                  </div>
                  </div>
                  <button type="submit" class="signup" id="SignupBtn">Sign up with Evdreamz</button>

        </div>
      
    </form>


  </div>
  <div class="clearfix">
</section>

<section>
  <div class="registration-sec log-from">
    <div class="container ">
    <h1>Welcome back!!  Please Log In to continue</h1>
</div>
 
  <div class="form-sec">
     <form action="#">
        <div class="row">
                
                <div class="col-md-12">
                    <div class="form-group">
                       
                        <input type="text" class="form-control" id="lastname" placeholder="Email">
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="form-group">
                       
                        <input type="text" class="form-control" id="lastname" placeholder="Password">
                    </div>
                </div>
                

                    <div class="col-md-12">
                    <div class="form-group">
                    <fieldset class="fl-sec">
                   
                    <label for="accessible" class="trem-sec"> 
                      <input type="checkbox" value="accessible" name="quality" id="accessible" ><span class="rem01"> Remember</span>
                    </label>
                     <label for="accessible" class="trem-sec"> <span class="pull-right">Forget your password ?</span></label>
                  </fieldset>
                  </div>
                  </div>
                  <a href="" class="signup">Sign up with Evdreamz</a>

        </div>
      
    </form>


  </div>
  <div class="clearfix">
</section>

