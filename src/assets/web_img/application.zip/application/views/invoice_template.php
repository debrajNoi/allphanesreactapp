<table style="border-collapse:collapse;margin-left:5.975pt" cellspacing="0">
        <tr style="height:66pt">
            <td style="width:324pt;border-top-style:solid;border-top-width:1pt;border-top-color:#9E9E9E;border-left-style:solid;border-left-width:1pt;border-left-color:#9E9E9E;border-bottom-style:solid;border-bottom-width:1pt;border-bottom-color:#9E9E9E"
                colspan="3">
                <p class="s1"
                    style="padding-top: 2pt;padding-left: 97pt;padding-right: 13pt;text-indent: 0pt;text-align: left;">
                    BRANDMONKEY COMMUNICATIONS TECHNOLOGY PRIVATE LIMITED</p>
                <p class="s2"
                    style="padding-top: 3pt;padding-left: 97pt;padding-right: 13pt;text-indent: 0pt;line-height: 108%;text-align: left;">
                    <a href="mailto:sajan@brandmonkey.in" class="s3" target="_blank">6/6 III/F, Mohalla Maharam, Near
                        Main Road, Shahdara Delhi - 110032, India </a>sajan@brandmonkey.in 8890923432 GSTIN
                    07AAJCB8478M1ZV</p>
            </td>
            <td
                style="width:18pt;border-top-style:solid;border-top-width:1pt;border-top-color:#9E9E9E;border-bottom-style:solid;border-bottom-width:1pt;border-bottom-color:#9E9E9E">
                <p style="text-indent: 0pt;text-align: left;"><br /></p>
            </td>
            <td style="width:184pt;border-top-style:solid;border-top-width:1pt;border-top-color:#9E9E9E;border-bottom-style:solid;border-bottom-width:1pt;border-bottom-color:#9E9E9E;border-right-style:solid;border-right-width:1pt;border-right-color:#9E9E9E"
                colspan="2">
                <p style="text-indent: 0pt;text-align: left;"><br /></p>
                <p class="s4" style="padding-left: 69pt;text-indent: 0pt;text-align: left;">Tax Invoice</p>
            </td>
        </tr>
        <tr style="height:29pt">
            <td style="width:263pt;border-top-style:solid;border-top-width:1pt;border-top-color:#9E9E9E;border-left-style:solid;border-left-width:1pt;border-left-color:#9E9E9E;border-bottom-style:solid;border-bottom-width:1pt;border-bottom-color:#9E9E9E;border-right-style:solid;border-right-width:1pt;border-right-color:#9E9E9E"
                colspan="2">
                <p class="s5" style="padding-left: 4pt;text-indent: 0pt;text-align: left;"># <span class="s6">:
                        BM2122-00041</span></p>
                <p class="s5" style="padding-top: 1pt;padding-left: 4pt;text-indent: 0pt;text-align: left;">Invoice Date
                    <span class="s6">: 19/02/2022</span></p>
            </td>
            <td
                style="width:26pt;border-top-style:solid;border-top-width:1pt;border-top-color:#9E9E9E;border-left-style:solid;border-left-width:1pt;border-left-color:#9E9E9E;border-bottom-style:solid;border-bottom-width:1pt;border-bottom-color:#9E9E9E">
                <p class="s5" style="padding-top: 1pt;padding-left: 4pt;text-indent: 0pt;text-align: left;">Place</p>
            </td>
            <td
                style="width:35pt;border-top-style:solid;border-top-width:1pt;border-top-color:#9E9E9E;border-bottom-style:solid;border-bottom-width:1pt;border-bottom-color:#9E9E9E">
                <p class="s5" style="padding-top: 1pt;text-indent: 0pt;text-align: left;">Of Supply</p>
            </td>
            <td
                style="width:18pt;border-top-style:solid;border-top-width:1pt;border-top-color:#9E9E9E;border-bottom-style:solid;border-bottom-width:1pt;border-bottom-color:#9E9E9E">
                <p style="text-indent: 0pt;text-align: left;"><br /></p>
            </td>
            <td
                style="width:184pt;border-top-style:solid;border-top-width:1pt;border-top-color:#9E9E9E;border-bottom-style:solid;border-bottom-width:1pt;border-bottom-color:#9E9E9E;border-right-style:solid;border-right-width:1pt;border-right-color:#9E9E9E">
                <p class="s6" style="padding-left: 52pt;text-indent: 0pt;text-align: left;">: Delhi (07)</p>
            </td>
        </tr>
        <tr style="height:11pt">
            <td style="width:263pt;border-top-style:solid;border-top-width:1pt;border-top-color:#9E9E9E;border-left-style:solid;border-left-width:1pt;border-left-color:#9E9E9E;border-bottom-style:solid;border-bottom-width:1pt;border-bottom-color:#9E9E9E;border-right-style:solid;border-right-width:1pt;border-right-color:#9E9E9E"
                colspan="2" bgcolor="#F2F2F3">
                <p class="s7" style="padding-left: 4pt;text-indent: 0pt;line-height: 9pt;text-align: left;">Bill To</p>
            </td>
            <td style="width:263pt;border-top-style:solid;border-top-width:1pt;border-top-color:#9E9E9E;border-left-style:solid;border-left-width:1pt;border-left-color:#9E9E9E;border-bottom-style:solid;border-bottom-width:1pt;border-bottom-color:#9E9E9E;border-right-style:solid;border-right-width:1pt;border-right-color:#9E9E9E"
                colspan="4" bgcolor="#F2F2F3">
                <p class="s7" style="padding-left: 4pt;text-indent: 0pt;line-height: 9pt;text-align: left;">Ship To</p>
            </td>
        </tr>
        <tr style="height:16pt">
            <td style="width:263pt;border-top-style:solid;border-top-width:1pt;border-top-color:#9E9E9E;border-left-style:solid;border-left-width:1pt;border-left-color:#9E9E9E;border-right-style:solid;border-right-width:1pt;border-right-color:#9E9E9E"
                colspan="2">
                <p class="s8"
                    style="padding-top: 4pt;padding-left: 4pt;text-indent: 0pt;line-height: 10pt;text-align: left;">EV
                    DREAMZ PRIVATE LIMITED</p>
            </td>
            <td style="width:263pt;border-top-style:solid;border-top-width:1pt;border-top-color:#9E9E9E;border-left-style:solid;border-left-width:1pt;border-left-color:#9E9E9E;border-right-style:solid;border-right-width:1pt;border-right-color:#9E9E9E"
                colspan="4">
                <p class="s2" style="padding-top: 5pt;padding-left: 4pt;text-indent: 0pt;text-align: left;">EV DREAMZ
                    PRIVATE LIMITED</p>
            </td>
        </tr>
        <tr style="height:12pt">
            <td style="width:263pt;border-left-style:solid;border-left-width:1pt;border-left-color:#9E9E9E;border-right-style:solid;border-right-width:1pt;border-right-color:#9E9E9E"
                colspan="2">
                <p class="s2"
                    style="padding-top: 1pt;padding-left: 4pt;text-indent: 0pt;line-height: 9pt;text-align: left;">
                    E-44/3, Ground Floor, Okhla Industrial Area, Phase-2 New Delhi Delhi</p>
            </td>
            <td style="width:263pt;border-left-style:solid;border-left-width:1pt;border-left-color:#9E9E9E;border-right-style:solid;border-right-width:1pt;border-right-color:#9E9E9E"
                colspan="4">
                <p class="s2" style="padding-left: 4pt;text-indent: 0pt;text-align: left;">E-44/3, Ground Floor, Okhla
                    Industrial Area, Phase-2</p>
            </td>
        </tr>
        <tr style="height:12pt">
            <td style="width:263pt;border-left-style:solid;border-left-width:1pt;border-left-color:#9E9E9E;border-right-style:solid;border-right-width:1pt;border-right-color:#9E9E9E"
                colspan="2">
                <p class="s2"
                    style="padding-top: 1pt;padding-left: 4pt;text-indent: 0pt;line-height: 9pt;text-align: left;">India
                    110020</p>
            </td>
            <td style="width:263pt;border-left-style:solid;border-left-width:1pt;border-left-color:#9E9E9E;border-right-style:solid;border-right-width:1pt;border-right-color:#9E9E9E"
                colspan="4">
                <p class="s2" style="padding-top: 1pt;padding-left: 4pt;text-indent: 0pt;text-align: left;">New Delhi
                </p>
            </td>
        </tr>
        <tr style="height:12pt">
            <td style="width:263pt;border-left-style:solid;border-left-width:1pt;border-left-color:#9E9E9E;border-right-style:solid;border-right-width:1pt;border-right-color:#9E9E9E"
                colspan="2">
                <p class="s2"
                    style="padding-top: 1pt;padding-left: 4pt;text-indent: 0pt;line-height: 9pt;text-align: left;">GSTIN
                    07AAGCE7852F1ZI</p>
            </td>
            <td style="width:263pt;border-left-style:solid;border-left-width:1pt;border-left-color:#9E9E9E;border-right-style:solid;border-right-width:1pt;border-right-color:#9E9E9E"
                colspan="4">
                <p class="s2" style="padding-top: 1pt;padding-left: 4pt;text-indent: 0pt;text-align: left;">110020 Delhi
                </p>
            </td>
        </tr>
        <tr style="height:19pt">
            <td style="width:263pt;border-left-style:solid;border-left-width:1pt;border-left-color:#9E9E9E;border-bottom-style:solid;border-bottom-width:1pt;border-bottom-color:#9E9E9E;border-right-style:solid;border-right-width:1pt;border-right-color:#9E9E9E"
                colspan="2">
                <p class="s2" style="padding-top: 1pt;padding-left: 4pt;text-indent: 0pt;text-align: left;">
                    ashish@evdreamz.com 9650461101</p>
            </td>
            <td style="width:263pt;border-left-style:solid;border-left-width:1pt;border-left-color:#9E9E9E;border-bottom-style:solid;border-bottom-width:1pt;border-bottom-color:#9E9E9E;border-right-style:solid;border-right-width:1pt;border-right-color:#9E9E9E"
                colspan="4">
                <p class="s2" style="padding-top: 1pt;padding-left: 4pt;text-indent: 0pt;text-align: left;">India</p>
            </td>
        </tr>
        <tr style="height:15pt">
            <td style="width:27pt;border-top-style:solid;border-top-width:1pt;border-top-color:#9E9E9E;border-left-style:solid;border-left-width:1pt;border-left-color:#9E9E9E;border-bottom-style:solid;border-bottom-width:1pt;border-bottom-color:#9E9E9E;border-right-style:solid;border-right-width:1pt;border-right-color:#9E9E9E"
                bgcolor="#F2F2F3">
                <p class="s6" style="padding-top: 3pt;text-indent: 0pt;text-align: center;">#</p>
            </td>
            <td style="width:262pt;border-top-style:solid;border-top-width:1pt;border-top-color:#9E9E9E;border-left-style:solid;border-left-width:1pt;border-left-color:#9E9E9E;border-bottom-style:solid;border-bottom-width:1pt;border-bottom-color:#9E9E9E;border-right-style:solid;border-right-width:1pt;border-right-color:#9E9E9E"
                bgcolor="#F2F2F3">
                <p class="s6" style="padding-top: 3pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">Item &amp;
                    Description</p>
            </td>
            <td style="width:53pt;border-top-style:solid;border-top-width:1pt;border-top-color:#9E9E9E;border-left-style:solid;border-left-width:1pt;border-left-color:#9E9E9E;border-bottom-style:solid;border-bottom-width:1pt;border-bottom-color:#9E9E9E;border-right-style:solid;border-right-width:1pt;border-right-color:#9E9E9E"
                bgcolor="#F2F2F3">
                <p class="s6" style="padding-top: 3pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">HSN/SAC</p>
            </td>
            <td style="width:58pt;border-top-style:solid;border-top-width:1pt;border-top-color:#9E9E9E;border-left-style:solid;border-left-width:1pt;border-left-color:#9E9E9E;border-bottom-style:solid;border-bottom-width:1pt;border-bottom-color:#9E9E9E;border-right-style:solid;border-right-width:1pt;border-right-color:#9E9E9E"
                bgcolor="#F2F2F3">
                <p class="s6" style="padding-top: 3pt;padding-right: 4pt;text-indent: 0pt;text-align: right;">Qty</p>
            </td>
            <td style="width:57pt;border-top-style:solid;border-top-width:1pt;border-top-color:#9E9E9E;border-left-style:solid;border-left-width:1pt;border-left-color:#9E9E9E;border-bottom-style:solid;border-bottom-width:1pt;border-bottom-color:#9E9E9E;border-right-style:solid;border-right-width:1pt;border-right-color:#9E9E9E"
                bgcolor="#F2F2F3">
                <p class="s6" style="padding-top: 3pt;padding-right: 4pt;text-indent: 0pt;text-align: right;">Rate</p>
            </td>
            <td style="width:69pt;border-top-style:solid;border-top-width:1pt;border-top-color:#9E9E9E;border-left-style:solid;border-left-width:1pt;border-left-color:#9E9E9E;border-bottom-style:solid;border-bottom-width:1pt;border-bottom-color:#9E9E9E;border-right-style:solid;border-right-width:1pt;border-right-color:#9E9E9E"
                bgcolor="#F2F2F3">
                <p class="s6" style="padding-top: 3pt;padding-right: 4pt;text-indent: 0pt;text-align: right;">Amount</p>
            </td>
        </tr>
        <tr style="height:20pt">
            <td
                style="width:27pt;border-top-style:solid;border-top-width:1pt;border-top-color:#9E9E9E;border-left-style:solid;border-left-width:1pt;border-left-color:#9E9E9E;border-bottom-style:solid;border-bottom-width:1pt;border-bottom-color:#9E9E9E;border-right-style:solid;border-right-width:1pt;border-right-color:#9E9E9E">
                <p class="s2" style="padding-top: 1pt;text-indent: 0pt;text-align: center;">1</p>
            </td>
            <td
                style="width:262pt;border-top-style:solid;border-top-width:1pt;border-top-color:#9E9E9E;border-left-style:solid;border-left-width:1pt;border-left-color:#9E9E9E;border-bottom-style:solid;border-bottom-width:1pt;border-bottom-color:#9E9E9E;border-right-style:solid;border-right-width:1pt;border-right-color:#9E9E9E">
                <p class="s2"
                    style="padding-left: 4pt;padding-right: 138pt;text-indent: 0pt;line-height: 9pt;text-align: left;">
                    Search Engine Optimization <span style=" color: #333;">50% advance payment invoice</span></p>
            </td>
            <td
                style="width:53pt;border-top-style:solid;border-top-width:1pt;border-top-color:#9E9E9E;border-left-style:solid;border-left-width:1pt;border-left-color:#9E9E9E;border-bottom-style:solid;border-bottom-width:1pt;border-bottom-color:#9E9E9E;border-right-style:solid;border-right-width:1pt;border-right-color:#9E9E9E">
                <p class="s2" style="padding-top: 1pt;padding-left: 4pt;text-indent: 0pt;text-align: left;">998313</p>
            </td>
            <td
                style="width:58pt;border-top-style:solid;border-top-width:1pt;border-top-color:#9E9E9E;border-left-style:solid;border-left-width:1pt;border-left-color:#9E9E9E;border-bottom-style:solid;border-bottom-width:1pt;border-bottom-color:#9E9E9E;border-right-style:solid;border-right-width:1pt;border-right-color:#9E9E9E">
                <p class="s2" style="padding-top: 1pt;padding-right: 3pt;text-indent: 0pt;text-align: right;">1.00</p>
            </td>
            <td
                style="width:57pt;border-top-style:solid;border-top-width:1pt;border-top-color:#9E9E9E;border-left-style:solid;border-left-width:1pt;border-left-color:#9E9E9E;border-bottom-style:solid;border-bottom-width:1pt;border-bottom-color:#9E9E9E;border-right-style:solid;border-right-width:1pt;border-right-color:#9E9E9E">
                <p class="s2" style="padding-top: 1pt;padding-right: 3pt;text-indent: 0pt;text-align: right;">2,500.00
                </p>
            </td>
            <td
                style="width:69pt;border-top-style:solid;border-top-width:1pt;border-top-color:#9E9E9E;border-left-style:solid;border-left-width:1pt;border-left-color:#9E9E9E;border-bottom-style:solid;border-bottom-width:1pt;border-bottom-color:#9E9E9E;border-right-style:solid;border-right-width:1pt;border-right-color:#9E9E9E">
                <p class="s2" style="padding-top: 1pt;padding-right: 3pt;text-indent: 0pt;text-align: right;">2,500.00
                </p>
            </td>
        </tr>
        <tr style="height:39pt">
            <td style="width:297pt;border-top-style:solid;border-top-width:1pt;border-top-color:#9E9E9E;border-left-style:solid;border-left-width:1pt;border-left-color:#9E9E9E;border-right-style:solid;border-right-width:1pt;border-right-color:#9E9E9E"
                colspan="3">
                <p style="text-indent: 0pt;text-align: left;"><br /></p>
                <p class="s2" style="padding-left: 5pt;text-indent: 0pt;text-align: left;">Total In Words</p>
                <p class="s9" style="padding-left: 5pt;text-indent: 0pt;text-align: left;">Indian Rupee Two Thousand
                    Nine Hundred Fifty Only</p>
            </td>
            <td
                style="width:45pt;border-top-style:solid;border-top-width:1pt;border-top-color:#9E9E9E;border-left-style:solid;border-left-width:1pt;border-left-color:#9E9E9E">
                <p style="text-indent: 0pt;text-align: left;"><br /></p>
            </td>
            <td style="width:115pt;border-top-style:solid;border-top-width:1pt;border-top-color:#9E9E9E">
                <p class="s2"
                    style="padding-top: 3pt;padding-left: 44pt;padding-right: 28pt;text-indent: 7pt;line-height: 135%;text-align: left;">
                    Sub Total CGST9 (9%)</p>
                <p class="s2" style="padding-left: 44pt;text-indent: 0pt;text-align: left;">SGST9 (9%)</p>
            </td>
            <td
                style="width:69pt;border-top-style:solid;border-top-width:1pt;border-top-color:#9E9E9E;border-right-style:solid;border-right-width:1pt;border-right-color:#9E9E9E">
                <p class="s2" style="padding-top: 3pt;padding-right: 4pt;text-indent: 0pt;text-align: right;">2,500.00
                </p>
                <p class="s2" style="padding-top: 3pt;padding-right: 4pt;text-indent: 0pt;text-align: right;">225.00</p>
                <p class="s2" style="padding-top: 3pt;padding-right: 4pt;text-indent: 0pt;text-align: right;">225.00</p>
            </td>
        </tr>
        <tr style="height:15pt">
            <td style="width:297pt;border-left-style:solid;border-left-width:1pt;border-left-color:#9E9E9E;border-right-style:solid;border-right-width:1pt;border-right-color:#9E9E9E"
                colspan="3" rowspan="2">
                <p style="text-indent: 0pt;text-align: left;"><br /></p>
                <p class="s2" style="padding-left: 5pt;text-indent: 0pt;text-align: left;">Thanks for your business.</p>
            </td>
            <td
                style="width:45pt;border-left-style:solid;border-left-width:1pt;border-left-color:#9E9E9E;border-bottom-style:solid;border-bottom-width:1pt;border-bottom-color:#9E9E9E">
                <p style="text-indent: 0pt;text-align: left;"><br /></p>
            </td>
            <td style="width:115pt;border-bottom-style:solid;border-bottom-width:1pt;border-bottom-color:#9E9E9E">
                <p class="s8" style="padding-top: 1pt;padding-left: 63pt;text-indent: 0pt;text-align: left;">Total</p>
            </td>
            <td
                style="width:69pt;border-bottom-style:solid;border-bottom-width:1pt;border-bottom-color:#9E9E9E;border-right-style:solid;border-right-width:1pt;border-right-color:#9E9E9E">
                <p class="s8" style="padding-top: 1pt;padding-right: 4pt;text-indent: 0pt;text-align: right;">₹2,950.00
                </p>
            </td>
        </tr>
        <tr style="height:13pt">
            <td style="width:229pt;border-top-style:solid;border-top-width:1pt;border-top-color:#9E9E9E;border-left-style:solid;border-left-width:1pt;border-left-color:#9E9E9E;border-right-style:solid;border-right-width:1pt;border-right-color:#9E9E9E"
                colspan="3">
                <p style="text-indent: 0pt;text-align: left;"><br /></p>
            </td>
        </tr>
        <tr style="height:72pt">
            <td style="width:297pt;border-left-style:solid;border-left-width:1pt;border-left-color:#9E9E9E;border-right-style:solid;border-right-width:1pt;border-right-color:#9E9E9E"
                colspan="3">
                <p class="s2"
                    style="padding-top: 7pt;padding-left: 5pt;padding-right: 25pt;text-indent: 0pt;text-align: left;">
                    Account Holders Name: Brandmonkey Communications Technology Private Limited</p>
                <p class="s2" style="padding-left: 5pt;padding-right: 164pt;text-indent: 0pt;text-align: left;">Account
                    Number: 2345208516 IFSC Code: KKBK0005042</p>
                <p class="s2" style="padding-left: 5pt;padding-right: 183pt;text-indent: 0pt;text-align: left;">Swift
                    Code: KKBKINBB Branch Name: Noida - India</p>
                <p style="padding-left: 5pt;text-indent: 0pt;line-height: 8pt;text-align: left;"><a
                        href="mailto:sajan@brandmonkey.in" class="s3" target="_blank">PayPal Id:
                        sajan@brandmonkey.in</a></p>
            </td>
            <td style="width:229pt;border-left-style:solid;border-left-width:1pt;border-left-color:#9E9E9E;border-bottom-style:solid;border-bottom-width:1pt;border-bottom-color:#9E9E9E;border-right-style:solid;border-right-width:1pt;border-right-color:#9E9E9E"
                colspan="3">
                <p style="text-indent: 0pt;text-align: left;"><br /></p>
                <p style="padding-left: 44pt;text-indent: 0pt;text-align: left;"><span>
                        
                    </span></p>
                <p style="text-indent: 0pt;text-align: left;"><br /></p>
                <p class="s2" style="padding-left: 76pt;text-indent: 0pt;line-height: 8pt;text-align: left;">Authorized
                    Signature</p>
            </td>
        </tr>
        <tr style="height:388pt">
            <td style="width:526pt;border-left-style:solid;border-left-width:1pt;border-left-color:#9E9E9E;border-bottom-style:solid;border-bottom-width:1pt;border-bottom-color:#9E9E9E;border-right-style:solid;border-right-width:1pt;border-right-color:#9E9E9E"
                colspan="6">
                <p style="text-indent: 0pt;text-align: left;"><br /></p>
            </td>
        </tr>
    </table>
    <p style="text-indent: 0pt;text-align: left;"><br /></p>
    <p style="text-indent: 0pt;text-align: left;"><span>
            
        </span></p>
    <p style="padding-top: 5pt;text-indent: 0pt;text-align: right;">1</p>