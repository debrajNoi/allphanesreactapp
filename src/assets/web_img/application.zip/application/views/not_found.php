<section class="scrt-slider" style="padding-bottom: 60px;">
    <div class="container-fluid brand-sec">        
        <div class="row">
            <div class="col-md-4 offset-md-4 text-center">
                <img src="<?php echo base_url('images/404_image_.png');?>" alt="404_image" class="img-fluid" style="margin: 80px 0px 10px 0px; width:40%">
            	<h2>Whoops! :(</h2>
            	<p style="text-align: center; margin:20px 0">We can’t seem to find the page that you’re looking for</p>
                <a class="btn btn-3 mb-4 btn_main" style="border-radius: 25px;padding: 10px 40px;" href='<?= base_url(); ?>' >Back to Homepage</a>
        	   
        	</div>
        </div>
    </div>
</section>
