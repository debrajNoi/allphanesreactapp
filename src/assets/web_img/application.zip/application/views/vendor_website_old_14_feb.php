    <!--<pre>-->
        <?php 
        // print_r($vendor); 
        // print_r($city); 
        // print_r($state); 
        // print_r($products); 
        // print_r($vendor_web); 
        ?>
    <!--</pre>-->
    <style>
        .add-icon{
            min-width: 30px;
        }
        .cover-img{
            border-radius: 5px; 
            height: 400px; 
            background: #dbdbdb;
            padding: 0;
            overflow-x: scroll;
            -ms-overflow-style: none;  
            scrollbar-width: none;  /* Firefox */
        }
        .cover-img::-webkit-scrollbar {
            display: none;
        }
        .cover-img img{
            height: 100%;
            width: 100%;
            min-width: 1200px;
            
        }
        .item_centers{
            display: flex; 
            flex-direction: row;
            justify-content: center; 
            flex-wrap: wrap;
        }
        
        .com-img, .com-img img{
            height: 192px !important;
            width: 100%;
        }
        @media only screen and (max-width: 768px) {
            .ft-s{
                font-size: 13px;
            }
            .item_centers{
                flex-direction: column;
            }
            .com-img, .com-img img{
                height: 225px !important;
                /*width: 100%;*/
            }
        }
    </style>

    <link rel="stylesheet" type="text/css" href="<?=base_url('/css/vendor.css')?>" />
    



    <!-- product section  -->
    <section id="products">
        <div class="container-fluid brand-sec">
            <div class="row" style="margin-top: 30px;">
                <?php if($vendor[0]['cover_photo']==''){ ?>
                    <div class="col-lg-12 cover-img">
                        <!-- <img src="#<?//=base_url('/uploads/profile/'.$vendor[0]['cover_photo'])?>" style="background-color: #dcdbdb;" alt="Cover image not found." /> -->
                        <!--<img src="<?=($vendor[0]['cover_photo']==''?base_url("/images/murat-demircan-oKDJz4jYCh8-unsplash.jpg"):base_url('/uploads/profile/'.$vendor[0]['cover_photo']))?>" alt="alt img not found"  > -->
                    </div>
                <?php } else { ?>
                    <div class="col-lg-12 cover-img">
                        <!-- <img src="<?=($vendor[0]['cover_photo']==''?base_url('/images/default-ev-icon.jpg'):base_url('/uploads/profile/'.$vendor[0]['cover_photo']))?>" alt="alt img not found"> -->
                        <img src="<?=base_url('/uploads/profile/'.$vendor[0]['cover_photo'])?>" alt="Vendor cover image">
                    </div>
                <?php } ?>
            </div>

            <!-- visible only to vendor -->
            <?php
            if($this->session->userdata('user_type') == "customer"){?>
            
            <?php }else{ 
                if($this->session->userdata('user_type') == ''){
                    echo '';
                }
                else{
                
                if($vendor[0]['cover_photo'] == '' || $vendor[0]['image'] == '' || $vendor_web[0]->about_us == ''){ ?>
            <div class="row mt-5 text-danger text-center">
                <p class="text-center" style="font-size: 18px; width: 100%;">Please upload your Cover Photo, Logo/Profile photo and complete About Us section to get more bookings, more sales</p>
            </div>
            <?php }}} ?>


            <!-- seller con  -->
            <div class="row mb-5 mt-5">
                
                <div class="col-lg-3 d-center mt-3">
                    <?php if($vendor[0]['image']==''){ ?>
                    <div class="sell-logo" style=" border-radius: 50%; 
                          background-size: contain; 
                          width: 150px;  
                          height: 150px; 
                          background: #dbdbdb"
                          >

                        <!-- <img class="profile-pic" src="<?=($vendor[0]['image']==''?'':base_url('/uploads/profile/'.$vendor[0]['image']))?>" <?=($vendor[0]['image']==''?'style="background-color: #dcdbdb;"':'')?> alt="alt img not found"> -->
                    </div>
                    <?php }else{ ?>
                    <div class="sell-logo">
                        <img src="<?=($vendor[0]['cover_photo']==''?base_url('/images/default-ev-icon.jpg'):base_url('/uploads/profile/'.$vendor[0]['cover_photo']))?>" alt="alt img not found">
                    </div>
                    <?php } ?>
                </div>


                <div class="col-lg-5 col-md-7 mt-3 mt-md-4">
                    <h2 class="sell-head">
                        <?=$vendor[0]['company_name']==''?'':$vendor[0]['company_name'];?> 
                        <span style="margin-left: 10px;"><img src="<?=base_url('assets/img/pricing/check.png')?>" width="5%" /></span>
                        <!-- <span><i class="fa fa-check-circle" aria-hidden="true"></i></span> -->
                    </h2>
                    <div class="s-add">
                        <div class="add mt-3">
                            <div class="add-icon" style="padding-left: 3px !important;"><i class="fa fa-map-marker" aria-hidden="true"></i></div>
                            <div class="add-con"><?=$vendor[0]['neighborhood']==''?'':$vendor[0]['neighborhood'];?> </div>
                        </div>
                        <div class="add mt-2">
                            <div class="add-icon"><i class="fa fa-home" aria-hidden="true"></i></div>
                            <div class="add-con">City: <?=($city[0]['city']==''?'':$city[0]['city'])?></div>
                        </div>
                        <div class="add mt-2">
                            <div class="add-icon"></div>
                            <div class="add-con star-mark">

                                <pre><?php //print_r($ratings);  ?></pre>

                                <!-- This will be avarage of total ratings earned by that vendor -->
                                <?php if($ratings[0]->count_it > 0){ 
                                    $rates = ceil($ratings[0]->rate_it/$ratings[0]->count_it);
                                    for($i=0; $i<$rates; $i++){ ?>
                                <i class="fa fa-star" aria-hidden="true"></i>
                                <?php }
                                } else {?>
                                    <span>No, reviews</span>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="col-lg-4 col-md-5 mt-3 mt-md-4">
                    <div class="show-alt btn_main" id="c1" class="ctn_shr" <?php 
                                        // if(isset($_SESSION['admin_id'])){
                                           if($vendor[0]['is_website_activated'] != 1){
                                                echo 'style="pointer-events: none;"';
                                            } 
                                        // } 
                                        ?> onclick="BookRequest(this)">Contact Showroom</div>

                    <?php

                    if( $this->session->flashdata('success1')){?>

                    <div class="alert alert-success" id="c1_msg_success" style="margin-top: 20px !important;"><?php echo $this->session->flashdata('success1');?></div>

                    <?php }?>

                    <?php

                    if( $this->session->flashdata('error1')){?>

                    <div class="alert alert-danger" id="c1_msg_error" style="margin-top: 20px !important;"><?php echo $this->session->flashdata('error1');?></div>

                    <?php }?>

                    <!-- <button class="btn btn-blu-2 mb-4" c>Buy/Book Now</button> -->
                    <div class="s-add">
                        <div class="add mt-4">
                            <div class="add-icon"><i class="fa fa-shopping-bag" aria-hidden="true"></i></div>
                            <div class="add-con"><?=$vendor[0]['name']==''?'':$vendor[0]['name'];?> </div>
                        </div>

                        <div class="add mt-1" >
                            <div class="add-icon" ><i class="fas fa-at"></i></div>
                            <div class="add-con"><?=$vendor[0]['email']==''?'':$vendor[0]['email'];?> </div>
                        </div>

                        <div class="add mt-1">
                            <div class="add-icon"><i class="fa fa-phone" aria-hidden="true"></i></div>
                            <div class="add-con">
                                <?=$vendor[0]['mobile']==''?'':'<a style="color: #000; '.($vendor[0]['is_website_activated'] == 1?'':'pointer-events: none;').'" href="tel:'.$vendor[0]['mobile'].'">'.$vendor[0]['mobile'].'</a>';?>
                            </div>
                        </div>
                        <!-- 
                        <div class="add mt-1">
                            <div class="add-icon"><i class="fa fa-globe" aria-hidden="true"></i></div>
                            <div class="add-con"><?=$vendor[0]['website']==''?'':$vendor[0]['website'];?> </div>
                        </div> -->

                        <div class="add mt-3 d-flex">
                            <div class="text-right">Share this website </div>
                            <div class="add-con text-left" style="margin-left: 10px !important; margin-right: 2px !important;">
                                <p class="share-save">

                                    <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo base_url($this->uri->segment(1))?>" 
                                        <?php 
                                        // if(isset($_SESSION['admin_id'])){
                                           if($vendor[0]['is_website_activated'] != 1){
                                                echo 'style="pointer-events: none;"';
                                            } 
                                        // } 
                                        ?>
                                        target="_blank"  
                                        class="disabled-link">
                                        <i class="fa fa-facebook" style="color: #4958C5; font-size: 25px;"></i>
                                    </a>

                                    &nbsp;  
                                    <a href="https://wa.me/?text=<?php echo base_url($this->uri->segment(1))?>" 
                                        <?php 
                                        // if(isset($_SESSION['admin_id'])){
                                           if($vendor[0]['is_website_activated'] != 1){
                                                echo 'style="pointer-events: none;"';
                                            } 
                                        // } 
                                        ?>
                                        target="_blank">
                                        <i class="fa fa-whatsapp" style="color:#4DC85A; font-size: 25px;"></i>
                                    </a>

                                    <!--&nbsp;  <a href="https://www.instagram.com/?url=<?php echo base_url('product-details?id='.$this->input->get('id'))?>" target="_blank"><i  class="fa fa-instagram fa-2x" style="color:#EA476C; aria-hidden="true"></i></a>-->

                                    &nbsp;  
                                    <a href="https://twitter.com/intent/tweet?url=<?php echo base_url($this->uri->segment(1))?>" 
                                        <?php 
                                        // if(isset($_SESSION['admin_id'])){
                                           if($vendor[0]['is_website_activated'] != 1){
                                                echo 'style="pointer-events: none;"';
                                            } 
                                        // } 
                                        ?> 
                                        target="_blank">
                                        <i  class="fa fa-twitter" style="color:#0fb2e7; font-size: 25px;" aria-hidden="true"></i>
                                    </a>

                                </p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            <script type="text/javascript">



                function BookRequest(el){

                    var text = '';
                    console.log('aa : '+el.id);
                    // console.log($(this).html());

                    $('#btn_id').val(el.id);

                    $('#CustomerModal').modal('show');
                }

            </script>


            <!-- <pre><?php print_r($_SESSION)?></pre> -->

            <?php 
            if(isset($_SESSION['admin_id'])){
                if($vendor[0]['is_website_activated'] != 1){ ?>
            <div id="trial_message" class="" style="color: #fb4949; font-size: 24px; text-align: center; margin: 40px 10px; display: block;">
                <!-- Please click on "Start Free Trial" to activate your website  -->
                <div class="col-md-12">
                    To show your website link on your product pages<br/>please click on "Start Free Trial" below to activate this website 
                </div>
                <div class="col-md-12 text-center mt-3">
                    <!-- <button class="show-alt ml-4 btn btn_main" id="activate_trial">Start Free Trial</button> -->
                    <a href="<?=site_url("vendor/activate_trial/".$vendor[0]['slug'])?>" class="show-alt ml-4 btn btn_main" id="activate_trial">Start Free Trial</a>
                </div>
            </div>  
            <?php } else { 
                $date=date_create($vendor[0]['trial_start_date']);
                date_add($date,date_interval_create_from_date_string("30 days"));
            ?>
            <div style="color: #fb4949; font-size: 24px; text-align: center; margin: 40px 10px;">
                <!-- <span class="text-success" id="message">Your 1 month Free Trial has started successfully</span> -->
                <span class="text-success" id="message">Your 1 month Free Trial has started successfully and will end on <b><?=date_format($date,"d F Y")?></b></span>
            </div>
            <?php } }?>






            <!-- D -->
            <div class="row">
                <!-- compare body  -->

                <pre><?php //print_r($products); ?></pre>

                <?php foreach($products as $key => $val){ ?>
                <div class="col-lg-3 col-md-6 mt-4">
                    <?php if($val['front_view'] == ""){ ?>
                    <div class="com-img">
                        <img src="<?=base_url('/uploads/products/'.$val['front_view'])?>" class="img" alt="alt img not found">
                    </div>
                    <?php }else{ ?>
                    <div class="com-img">
                        <img src="<?=base_url('/uploads/products/'.$val['front_view'])?>" alt="alt img not found">
                    </div>
                    <?php } ?>
                    <div class="comp-pricing">
                        <div class="name-price"><span><?=$val['model']?></span> | <span><?=$val['price']?></span>  </div>

                        <div class="viewmore">
                            <?php //if($this->session->userdata('admin_id')!=''){ ?>
                            <a href="<?=base_url('product-details?id='.base64_encode($val['id']))?>"
                                <?php 
                                // if(isset($_SESSION['admin_id'])){
                                   if($vendor[0]['is_website_activated'] != 1){
                                        echo 'style="pointer-events: none;"';
                                    } 
                                // } 
                                ?> 
                                >view more</a>
                            <?php //} ?>
                        </div>
                    </div>
                </div>
                <?php } ?>


                <!-- end comp body  -->
            </div>
            <!-- end D  -->

            <div class="col-lg-12 mt-5 px-5">
                <div class="spacer"></div>
            </div>

        <!-- <pre><?php print_r($vendor_web); ?></pre> -->

            <div class="row text-center justify-content-center">
                <div class="col-lg-8">
                    <h1 class="m-5 text-center" style="font-weight: 400;">About Us</h1>

                    <p class="text-center" style="font-weight: 400; font-size: 18px; line-height: 35px;"><?php if(count($vendor_web) > 0){echo $res_about = $vendor_web[0]->about_us == ''? 'Please Enter your content from the "Setup Website" form': $vendor_web[0]->about_us;}else{echo 'NA';} ?></p>

                    <!--<a href="#" class="btn m-5 pl-5 pr-5 pt-2 pb-2 bg-danger text-white" style="width: 200px; border-radius: 30px;" onclick="BookRequest()">
                        Contact Us
                    </a>-->

                    <div style="width: 100%; display: flex; justify-content: center;" >
                        <div class="btn_main ctn_shr py-2" 
                            id="c2" 
                            style="width: 300px; 
                                    border-radius: 24px !important;
                            <?=($vendor[0]['is_website_activated'] != 1?'pointer-events: none;':'')?>" 
                            onclick="BookRequest(this)">Contact Us</div>
                    </div>


                    <?php

                        if( $this->session->flashdata('success2')){?>

                    <div class="alert alert-success" id="c2_msg_success" style="margin-top: 0px !important;"><?php echo $this->session->flashdata('success2');?></div>

                    <?php }?>

                    <?php

                    if( $this->session->flashdata('error2')){?>

                    <div class="alert alert-danger" id="c2_msg_error" style="margin-top: 20px !important;"><?php echo $this->session->flashdata('error2');?></div>

                    <?php }?>



                    <p class="mt-5" style="font-size: 18px;">
                        Showroom Timing : 
                        <?php if(count($vendor_web) > 0){
                            echo $res_timing = $vendor_web[0]->timing==''?'NA':$vendor_web[0]->timing;
                        }else{
                            echo 'NA';
                        } ?>
                    </p>

                    <div class="text-center item_centers" style="font-size: 19px;">
                        <div class="m-3">
                            <i class="fas fa-user"></i>
                            <b><?=$vendor[0]['name']==''?'':$vendor[0]['name'];?></b>
                        </div>
                        <div class="m-3">
                            <i class="fas fa-at"></i>
                            <b><?php 
                            if(count($vendor_web) > 0){ echo $res_email = $vendor_web[0]->email == ''? $vendor[0]['email']: $vendor_web[0]->email;}else{echo $vendor[0]['email'];} ?></b>
                        </div>
                        <div class="m-3">
                            <i class="fa fa-phone"></i>
                            <span>
                                <?php if(count($vendor_web) > 0){
                                    echo $res_phone = $vendor_web[0]->phone == ''? '<a style="color: #000; '.($vendor[0]['is_website_activated'] == 1?'':'pointer-events: none;').'" href="tel:'.$vendor[0]['mobile'].'">'.$vendor[0]['mobile'].'</a>' : str_replace(',','<br/>','<a style="color: #000; '.($vendor[0]['is_website_activated'] == 1?'':'pointer-events: none;').'" href="tel:'.$vendor_web[0]->phone.'">'.$vendor_web[0]->phone.'</a>');
                                }else{
                                    echo '<a style="color: #000; '.($vendor[0]['is_website_activated'] == 1?'':'pointer-events: none;').'" href="tel:'.$vendor[0]['mobile'].'">'.$vendor[0]['mobile'].'</a>';
                                } ?>
                            </span>
                        </div>
                    </div>
                </div>
            </div>


            <div class="col-lg-12 my-5 px-5">
                <div class="spacer"></div>
            </div>

            <div class="text-center ft-s">
                <p style="color: #7c7c7c;">All Right Reserved | <a href="<?=base_url('terms')?>" style="color: #7c7c7c !important;">Terms of Use</a></p>
                <p style="color: #7c7c7c;">Developed and Managed by EV Dreamz Pvt Ltd</p>
            </div>

        </div>

        


    </section>
    <!-- end product section  -->	


    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous">
    </script>


    <!-- Customer model -->
    <div class="modal fade" id="CustomerModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">

        <form method="post" action="<?php echo base_url('User/ProductBookingVendorWebsite');?>">

            <div class="modal-dialog" role="document">

                <div class="modal-content">

                    <div class="modal-header">

                        <h5 class="modal-title" id="exampleModalLabel">Booking Request</h5>

                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">

                        <span aria-hidden="true">&times;</span>

                        </button>

                    </div>

                    <input type="hidden" name="btn_id" id="btn_id" value="" />

                    <input type="hidden" name="vendor_id" id="vendor_id" value="<?=$vendor[0]['id']?>" />

                    <div class="modal-body">

                        <div class="row">

                            <div class="form-group col-md-6">

                                <label for="recipient-name" class="col-form-label">Name:</label>

                                <input type="hidden" name="product_id" value="<?php echo $this->input->get('id');?>" />

                                <input type="text" class="form-control" name="customer_name" id="customer_name" required>

                            </div>

                            <div class="form-group col-md-6">

                                <label for="message-text" class="col-form-label">Email:</label>

                                <input type="email" class="form-control" name="customer_email" name="customer_email" required />

                            </div>

                        </div>

                        <div class="row">

                            <div class="form-group col-md-6">

                                <label for="message-text" class="col-form-label">Mobile:</label>

                                <input type="text" class="form-control" maxlength="10" name="customer_mobile" name="customer_mobile" required />

                            </div>

                            <div class="form-group col-md-6">

                                <label for="message-text" class="col-form-label">Location:</label>

                                <input type="text" class="form-control"  name="customer_location" name="customer_location" required />

                            </div>

                        </div>

                        <div class="form-group">

                            <label for="message-text" class="col-form-label">Query:</label>

                            <textarea name="query" style="width:100%;" required></textarea>

                        </div>

                    </div>

                    <div class="modal-footer">

                        <button type="submit" class="btn btn_main" style="width: 130px; font-size: 23px; background-color: #01a86d; color: #fff;">Submit</button>

                    </div>

                </div>

            </div>

        </form>

    </div>




    <!-- <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script> -->

    <script type="text/javascript">

        $(document).ready(function(){
            <?php if($vendor[0]['is_website_activated'] == 1){ ?>
            $('#trial_message').show();
            $('#activate_trial').show();
            <?php }else{ ?>
            $('#message').hide();
            <?php } ?>
        });


        $('#activate_trial').on('click', function(){
            var slug = "<?=$vendor[0]['slug']?>";
            console.log('slug : '+slug)


            $.ajax({
              url:'<?=site_url("vendor/activate_trial/")?>'+slug,
              method:"GET",
              async: false,
              success:function(data)
              {
                // console.log(data);
                if(data == 'yes'){
                    location.reload(true);
                    console.log('Activated ');
                    // $('#trial_message').hide();
                    // $('#activate_trial').hide();
                    // $('#message').show();
                    $('#message').css('display', 'block');
                }
                else{
                    console.log('Not activated');
                    // $('#activate_trial').show();
                    $('#message').css('display', 'none');
                }
              }

            });

        });
    </script>