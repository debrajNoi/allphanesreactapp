<?php
    $pg = $this->uri->segment(1);
    $controller = $this->router->fetch_class();
    $method = $this->router->fetch_method();
    
    /* meta keywords Dynamic */
    $title = '';
    $description = '';
    $keyword = '';
    
    if($pg == '' || $pg == 'customer' || $pg == 'products'){
        $title = 'Most Affordable and Cheapest Electric Scooter in India | Under 1 Lakh | EV Dreamz';
        $description = 'EV Dreamz has the most affordable and cheapest electric scooter in India under 1 Lakh. It does not need much maintenance and is environmentally friendly as they do not use any fossil fuels.';
        $keyword = 'Most Affordable electric scooter , Cheapest electric scooter , E-scooter under 1 Lakh';
    }elseif($pg == 'vendor' || $this->uri->segment(2) == 'registration'){
        if($this->uri->segment(2) == 'regisration'){
            $title = "Register at India's 1st EV Marketplace Community | EV Dreamz";
            $description = 'Register with EV Dreamz, and list your Electrical Scooters to increase your profit. Get more visibility, more leads, more customers, more sales. Ready to start with EV Dreamz?';
            $keyword = 'EV Marketplace community in India, Electric scooter markeplace';
        }
    }elseif($pg == 'product-details' ){
        $title = $this->uri->segment(2);
        $description = 'EV Dreamz has the most affordable and cheapest electric scooter in India under 1 Lakh. It does not need much maintenance and is environmentally friendly as they do not use any fossil fuels.';
        $keyword = 'Most Affordable electric scooter , Cheapest electric scooter , E-scooter under 1 Lakh ';
    }elseif($controller != 'front' && $method == 'index'){
        $title = 'Most Affordable and Cheapest Electric Scooter in India | Under 1 Lakh | EV Dreamz';
        $description = 'EV Dreamz has the most affordable and cheapest electric scooter in India under 1 Lakh. It does not need much maintenance and is environmentally friendly as they do not use any fossil fuels.';
        $keyword = 'Most Affordable electric scooter , Cheapest electric scooter , E-scooter under 1 Lakh ';
    }elseif($controller == 'front' && $method == 'not_found'){
        $title = 'Most Affordable and Cheapest Electric Scooter in India | Under 1 Lakh | EV Dreamz';
        $description = 'EV Dreamz has the most affordable and cheapest electric scooter in India under 1 Lakh. It does not need much maintenance and is environmentally friendly as they do not use any fossil fuels.';
        $keyword = 'Most Affordable electric scooter , Cheapest electric scooter , E-scooter under 1 Lakh ';
    }else{
        $res = get_meta_details($pg);
        $title = ($res[0]->meta_title)? $res[0]->meta_title : 'Most Affordable and Cheapest Electric Scooter in India | Under 1 Lakh | EV Dreamz' ;
        $description = ($res[0]->meta_description)? $res[0]->meta_description : 'EV Dreamz has the most affordable and cheapest electric scooter in India under 1 Lakh. It does not need much maintenance and is environmentally friendly as they do not use any fossil fuels.';
        $keyword = ($res[0]->meta_keyword) ? $res[0]->meta_keyword : 'Most Affordable electric scooter , Cheapest electric scooter , E-scooter under 1 Lakh'; 
    }
    
    /* end meta keyword */
    
?>
<!DOCTYPE html>

<html lang="en">

  <head>

<meta charset="utf-8">

<meta http-equiv="X-UA-Compatible" content="IE=edge">

<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

<title><?php echo $title;?></title>

<meta name="description" content="<?php echo $description;?>">

<meta name="keywords" content="<?php echo $keyword;?>">

<link rel="icon" href="<?php echo base_url('images/Favicon.png');?>" type="image/png" sizes="16x16">

<meta charset="utf-8">

<link rel="preconnect" href="https://fonts.googleapis.com">

<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@100;200;300;400;500;600;700;800&display=swap" rel="stylesheet">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">



<link rel="stylesheet" href="<?php echo base_url('css/owlcarousel/owl.carousel.min.css');?>">

<link rel="stylesheet" href="<?php echo base_url('css/owlcarousel/owl.theme.default.min.css');?>">

<link type="text/css" rel="stylesheet" href="<?php echo base_url('css/fonts.css');?>" media="all">

<link type="text/css" rel="stylesheet" href="<?php echo base_url('css/bootstrap.min.css');?>" media="all">

<link type="text/css" rel="stylesheet" href="<?php echo base_url('css/style.css');?>" media="all">

<link type="text/css" rel="stylesheet" href="<?php echo base_url('css/price1.css')?>" media="all">

<link type="text/css" rel="stylesheet" href="<?php echo base_url('css/fix.css')?>" media="all">

<script async src="https://www.googletagmanager.com/gtag/js?id=G-8SVMLNF5VT"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-8SVMLNF5VT');
</script>

<!-- font awsome  -->
<script src="https://kit.fontawesome.com/83ce503d6d.js" crossorigin="anonymous"></script>
<!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '447244402297043');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=447244402297043&ev=PageView&noscript=1"
/></noscript>

</head>

  

<?php


?>

<body>
    <div>
        <?php
        // echo '||'.$controller.'||';
        // echo '||'.$method.'||';
        //echo '||' .$pg . '||';?>
    </div>

   <nav class="navbar navbar-expand-lg navbar-dark nav-sty">

        <div class="container-fluid ">

            <a class="navbar-brand" href="<?php echo base_url();?>"> 
                <img class="logo" src="<?php echo base_url('images/LOGGO.png');?>" alt="logo">
            </a>

            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar1" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbar1">

                <ul class="navbar-nav ml-auto"> 

                    <li class="nav-item <?php if($method=='index'){?> active<?php }?>">
                        <a class="nav-link" href="<?php echo base_url();?>">Buy EV</a>
                    </li>

                    <li class="nav-item <?php if($method=='sell'){?> active<?php }?>">
                        <a class="nav-link" href="<?php echo base_url();?>sell"> Sell Used EV  </a>
                    </li>

                    <!--<li class="nav-item"><a class="nav-link" href="html-components.html"> Charge EV </a></li>

                    <li class="nav-item"><a class="nav-link" href="html-components.html">Service EV</a></li>-->

                    <li class="nav-item <?php if($method=='pricing'){?> active<?php }?>">
                        <a class="nav-link" href="<?php echo base_url('pricing');?>">Pricing</a>
                    </li>

                    <li class="nav-item <?php if($method=='partner_with_us'){?> active<?php }?>">
                        <a class="nav-link" href="<?php echo base_url('partner-with-us');?>">Partner With Us</a>
                    </li>
                    
                    <!--<li class="nav-item <?php if($method=='coming_soon'){?> active<?php }?>">-->
                    <!--    <a class="nav-link" href="<?php echo base_url('coming-soon');?>">Coming Soon</a>-->
                    <!--</li>-->

                    <li class="nav-item <?php if($method=='vendor_regisration'){?> active<?php }?>">
                        <a class="nav-link" href="<?php echo base_url('vendor/regisration');?>">
                            <span class="partner-wth">List Your EV </span>
                        </a>
                    </li>

                    
                    <?php if($this->session->userdata('admin_id') == ''){ ?>
                    <li class="nav-item vendor-box" id="vendBox">
                        <ul class="navbar-nav pull-right"> 
                            <li class="nav-item">
                                <!--<a class="nav-link" href="<?php //echo base_url('vendor');?>"> -->
                                <!--    <img src="<?php //echo base_url('images/my_account.png');?>" class="admin-img"> -->
                                <!--</a>-->
                                <div class="nav-link desk">
                                    <img src="<?php echo base_url('images/my_account.png');?>" alt="my_account" class="admin-img mt-2">
                                </div>
                                <div class="nav-link mob" id="vendBtn">
                                    <img src="<?php echo base_url('images/my_account.png');?>" alt="my_account" class="admin-img">
                                    <i class="fa fa-plus" aria-hidden="true"></i>
                                </div>
                                <div class="vendor-sub bg-white" id="vendSub">
                                    <div> <a href="<?php echo base_url('user/login');?>" class="nav-link fs-link">I am a User</a> </div>
                                    <div> <a href="<?php echo base_url('vendor/login');?>" class="nav-link">I am a Vendor</a></div>
                                </div>
                            </li>
                        </ul>
                    </li>
                    <?php 
                    } else { 
                        
                    ?>
                    <!-- User Menu-->
                    <li class="dropdown" style="margin-top: 15px;">
                        <?php $user_info = $this->session->userdata('admin_name'); ?>
                        <a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Open Profile Menu" style="color: #212529;font-size: 20px;">
                            <?php echo @$user_info;?>&nbsp;
                            <img src="https://creationanddevelopment.com/ecar/images/my_account.png" alt="HTML tutorial" style="width:31px;height:28px;">
                        </a>
                        <ul class="dropdown-menu settings-menu dropdown-menu-right">
                            <?php 
                            if($this->session->userdata('user_type') == 'Vendor'){
                            ?>
                            <li><a class="dropdown-item" href="<?=base_url("vendor/profile")?>"> Profile</a></li>
                            <li><a class="dropdown-item" href="<?=base_url("vendor/change_password")?>"> Change Password</a></li>
                            <li><a class="dropdown-item" href="<?=base_url("vendor/logout")?>"> Logout</a></li>
                            <?php
                            }elseif($this->session->userdata('user_type') == 'admin'){
                            ?>
                            <li><a class="dropdown-item" href="<?=base_url("admin/profile")?>"> Profile</a></li>
                            <li><a class="dropdown-item" href="<?=base_url("admin/change_password")?>"> Change Password</a></li>
                            <li><a class="dropdown-item" href="<?=base_url("admin/logout")?>"> Logout</a></li>
                            <?php
                            }else{
                            ?>
                            <li><a class="dropdown-item" href="<?=base_url("customer/profile")?>"> Profile</a></li>
                            <li><a class="dropdown-item" href="<?=base_url("customer/change_password")?>"> Change Password</a></li>
                            <li><a class="dropdown-item" href="<?=base_url("customer/logout")?>"> Logout</a></li>
                            
                            <?php
                            }
                            ?>
                        </ul>
                    </li>
                    <?php } ?>

                </ul>

<style>
    .desk{
        display: block !important;
    }
    .vendor-sub{
        z-index: 999;
    }
    .mob{
        display: none !important;
    }
    
    .btn_main{
        background-color: #fb4949 !important;
        color: #ffffff !important;
        border: none !important;
        font-size: 20px !important;
    }
    
    .btn_main_alt{
        background-color: #ffffff !important;
        color: #fb4949 !important;
        border: none !important;
        font-size: 20px !important;
    }
    .btn_main:hover{
        color: #ffffff !important;
    }
    

    @media only screen and (max-width: 990px) {
        .desk{
            display: none !important;
        }
        .mob{
            display: flex !important;
            justify-content: space-between;
        }
    }
</style>

                








            </div>

        </div>

    </nav>



    <style>

        .navbar-dark .navbar-nav .nav-link {

            font-family: 'Outfit', Sans-Serif;

            font-weight: 500;

            font-size: 18px;

        }

        .navbar-dark .navbar-nav .nav-link {

            font-family: 'Outfit', Sans-Serif;

            font-weight: 500;

            font-size: 18px;

        }

        .admin-img {

            width: 14%;

        }

        .partner-wth {

            font-family: 'Outfit', Sans-Serif;

            font-weight: 500;

            font-size: 18px;

        }

        .logo {

            width: 56%;

            margin-bottom: 9px;

        }

        .navbar-dark .navbar-nav .nav-link:focus, .navbar-dark .navbar-nav .nav-link:hover {

            color: rgb(75 168 110);

        }

    </style>