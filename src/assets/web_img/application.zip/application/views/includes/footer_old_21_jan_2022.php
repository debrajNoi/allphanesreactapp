  <div class="footer">
        <div class="container">
            <div class="row ">
               

                <!-- footer-about -->

                <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-6 ">

                    <div class="footer-widget ">

                        <div class="footer-title">About</div>

                        <ul class="list-unstyled">

                            <li><a href="<?php echo base_url('about-us');?>">About EV Dreamz</a></li>

                            <li><a href="https://medium.com/">Blog</a></li>

                            <li><a href="<?php echo base_url('coming-soon');?>">Coming Soon</a></li>

                        </ul>

                    </div>

                </div>

                <!-- /.footer-about -->

                <!-- footer-links -->

                <div class="col-xl-2 col-lg-2 col-md-4 col-sm-6 col-6 ">

                    <div class="footer-widget ">

                        <div class="footer-title">Partnerships</div>

                        <ul class="list-unstyled">

                            <li><a href="<?php echo base_url('partner-with-us');?>">Partner with us</a></li>

                            <li><a href="<?php echo base_url('vendor/regisration');?>">List your EV</a></li>

                            <li><a href="<?php echo base_url('sell');?>">Sell used EV</a></li>

                        </ul>

                    </div>

                </div>

                <!-- /.footer-links -->

                <!-- footer-links -->
                <div class="col-xl-2 col-lg-2 col-md-12 col-sm-6 col-6 ">
                    <div class="footer-widget ">

                        <div class="footer-title">Legal</div>

                        <ul class="list-unstyled">

                            <li><a href="<?php echo base_url('terms');?>">Terms</a></li>

                            <li><a href="<?php echo base_url('privacy');?>">Privacy</a></li>

                            <li><a href="<?php echo base_url('cancellation');?>">Cancellation</a></li>

                        </ul>

                    </div>
                </div>
                <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-6 ">

                    <div class="footer-widget ">

                        <div class="footer-title">Support</div>

                        <ul class="list-unstyled">

                            <li><a href="<?php echo base_url('contact-us');?>">Contact us</a></li>

                            <li>support@evdreamz.com</a></li>

                            <li><a href="tel:+9650461101">Call:+91-96504-61101</a></li>

                            

                        </ul>

                    </div>

                </div>
                
                

                <!-- /.footer-links -->

                <!-- footer-links -->

                <div class="col-xl-2 col-lg-2 col-md-12 col-sm-6 col-6 ">

                    <div class="footer-widget ">

                     <ul class="list-unstyled1">

                            <li><a href="https://www.facebook.com/" class="social"><i class="fa fa-facebook social-icon" aria-hidden="true"></i></a></li>

                            <li><a href="https://www.twitter.com/" class="social"><i class="fa fa-twitter social-icon" aria-hidden="true"></i></a></li>

                            <li><a href="https://www.instagram.com/" class="social"><i class="fa fa-instagram social-icon" aria-hidden="true"></i></a></li>

                            

                        </ul>   

                        

                    </div>



                </div>

                <!-- /.footer-links -->

              <div class="col-xl-2 col-lg-2 col-md-12 col-sm-6 col-6 "></div>

            </div>

              

                <div class="footer-bottom">
                    <center>
                      <ul>
                        <li>
                            <center>
                                <a style="/*margin: 0 0 0 140px;*/">
                                    Copyright © 2022 &nbsp;  EV Dreamz Pvt. Ltd. &nbsp;&nbsp; All rights reserved &nbsp;&nbsp;    &nbsp; Made with 
                                    <i  class="fa fa-heart" style="color:#EA476C; aria-hidden="true"></i> and passion 
                                </a>
                            </center>
                        </li>
                        <!--<li><a href="<?php echo base_url('terms');?>">Terms</a></li>
                        <li><a href="<?php echo base_url('privacy');?>">Privacy</a> </li>
                        <img src="<?php echo base_url('assets/img/whatsapp/whatsapp-logo-png-2261.png');?>" alt="Whatsapp"> -->
                       </ul>
                    </center>
                     <!-- <p>
                        <div class="whatsapp" style="margin-right:-70px;">
                            <a href="https://api.whatsapp.com/send?phone=+919871455790" target="_blank">
                                <i class="fa fa-whatsapp fa-5x" style="color: #00a76d;" aria-hidden="true"></i>
                            </a>
                        </div>
                    </p>    -->                

                </div>

                <div class="clearfix">

        </div>

    </div>

</div>



<style type="text/css">

    @media only screen and (max-width: 600px) {
      div.whatsapp {
        position: relative !important;
        left: 0px !important;
      }
      .whatsapp{
        right: 0px !important;
        margin-top: -45px !important;
        float: none !important;
      }

    }

</style>
<div class="whatsapp text-center">
    <a href="https://api.whatsapp.com/send?phone=+919871455790" target="_blank">
        <i class="fa fa-whatsapp fa-5x" style="color: #00a76d;" aria-hidden="true"></i>
    </a>
</div>


</body>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script src="<?php echo base_url('js/bootstrap.min.js');?>"></script>



<style>

    .footer-title {

    color: #00A76D !important;

    font-weight: 400;

}

.footer {

    background-color: #fff;

}

.footer-widget ul li a {

    text-transform: capitalize;

    font-size: 16px;

    color: #505456;

    display: block;

    font-weight: 400;

}

.footer-bottom ul li a {

    font-size: 16px;

    color: #5f5d5d;

}

.footer-bottom ul li a {

    border-right: 0px solid #5f5f5f;

    

}

.footer-widget ul li a:hover {

    color: #00A76D;

    text-decoration: none;

}



a:hover {

    text-decoration: none;

}



.whatsapp {
    position: relative;
    right: 0px;
    float: right;
    margin-top: -100px;
}
.whatsapp h5 {
    color: white;
    background: #20b20f;
    padding: 12px;
    border-radius: 10px;
}

.social{
    font-size:30px;
    padding: 0 1px;
}

.social-icon{
    font-size:28px;
}




</style>



</html>