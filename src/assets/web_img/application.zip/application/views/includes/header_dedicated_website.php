<!DOCTYPE html>

<html lang="en">

  <head>

<meta charset="utf-8">

<meta http-equiv="X-UA-Compatible" content="IE=edge">

<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

<title>EV Dreamz</title>

<link rel="icon" href="<?php echo base_url('images/Favicon.png');?>" type="image/png" sizes="16x16">

<meta charset="utf-8">

<link rel="preconnect" href="https://fonts.googleapis.com">

<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@100;200;300;400;500;600;700;800&display=swap" rel="stylesheet">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">



<link rel="stylesheet" href="<?php echo base_url('css/owlcarousel/owl.carousel.min.css');?>">

<link rel="stylesheet" href="<?php echo base_url('css/owlcarousel/owl.theme.default.min.css');?>">

<link type="text/css" rel="stylesheet" href="<?php echo base_url('css/fonts.css');?>" media="all">

<link type="text/css" rel="stylesheet" href="<?php echo base_url('css/bootstrap.min.css');?>" media="all">

<link type="text/css" rel="stylesheet" href="<?php echo base_url('css/style.css');?>" media="all">

<link type="text/css" rel="stylesheet" href="<?php echo base_url('css/price1.css')?>" media="all">

<link type="text/css" rel="stylesheet" href="<?php echo base_url('css/fix.css')?>" media="all">

<!-- font awsome  -->
<script src="https://kit.fontawesome.com/83ce503d6d.js" crossorigin="anonymous"></script>

</head>

  

<?php

$controller = $this->router->fetch_class();



$method = $this->router->fetch_method();

?>

<body>
    
    <div class="container-fluid brand-sec" style="padding: 0; padding-top: 25px;">
        <a href="<?=site_url();?>" style="font-size: 20px !important; font-weight: 500; color: #000000;">EV Dreamz Home</a>
    </div>

   <!--<nav class="navbar navbar-expand-lg navbar-dark nav-sty">

        <div class="container-fluid ">

            <a class="navbar-brand" href="<?php echo base_url();?>"> 
                <img class="logo" src="<?php echo base_url('images/LOGGO.png');?>">
            </a>

            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar1" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbar1">

                <ul class="navbar-nav ml-auto"> 

                    <li class="nav-item <?php if($method=='index'){?> active<?php }?>">
                        <a class="nav-link" href="<?php echo base_url();?>">Buy EV</a>
                    </li>

                    <li class="nav-item <?php if($method=='sell'){?> active<?php }?>">
                        <a class="nav-link" href="<?php echo base_url();?>sell"> Sell Used EV  </a>
                    </li>

                    

                    <li class="nav-item <?php if($method=='pricing'){?> active<?php }?>">
                        <a class="nav-link" href="<?php echo base_url('pricing');?>">Pricing</a>
                    </li>

                    <li class="nav-item <?php if($method=='coming_soon'){?> active<?php }?>">
                        <a class="nav-link" href="<?php echo base_url('coming-soon');?>">Coming Soon</a>
                    </li>

                    <li class="nav-item <?php if($method=='vendor_regisration'){?> active<?php }?>">
                        <a class="nav-link" href="<?php echo base_url('vendor/regisration');?>">
                            <span class="partner-wth">List Your EV </span>
                        </a>
                    </li>

                    
                    <?php if($this->session->userdata('admin_id') == ''){ ?>
                    <li class="nav-item vendor-box" id="vendBox">
                        <ul class="navbar-nav pull-right"> 
                            <li class="nav-item">
                                
                                <div class="nav-link desk">
                                    <img src="<?php echo base_url('images/my_account.png');?>" class="admin-img mt-2">
                                </div>
                                <div class="nav-link mob" id="vendBtn">
                                    <img src="<?php echo base_url('images/my_account.png');?>" class="admin-img">
                                    <i class="fa fa-plus" aria-hidden="true"></i>
                                </div>
                                <div class="vendor-sub bg-white" id="vendSub">
                                    <div> <a href="<?php echo base_url('user/login');?>" class="nav-link fs-link">I am a User</a> </div>
                                    <div> <a href="<?php echo base_url('vendor/login');?>" class="nav-link">I am a Vendor</a></div>
                                </div>
                            </li>
                        </ul>
                    </li>
                    <?php } else { ?>
                    
                    <li class="dropdown" style="margin-top: 15px;">
                        <?php $user_info = $this->session->userdata('admin_name'); ?>
                        <a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Open Profile Menu" style="color: #212529;font-size: 20px;">
                            <?php echo @$user_info;?>&nbsp;
                            <img src="https://creationanddevelopment.com/ecar/images/my_account.png" alt="HTML tutorial" style="width:31px;height:28px;">
                        </a>
                        <ul class="dropdown-menu settings-menu dropdown-menu-right">
                            <li><a class="dropdown-item" href="<?=base_url("customer/profile")?>"> Profile</a></li>
                            <li><a class="dropdown-item" href="<?=base_url("customer/change_password")?>"> Change Password</a></li>
                            <li><a class="dropdown-item" href="<?=base_url("customer/logout")?>"> Logout</a></li>
                        </ul>
                    </li>
                    <?php } ?>

                </ul>

            </div>

        </div>

    </nav>-->


<style>
    .desk{
        display: block !important;
    }
    .vendor-sub{
        z-index: 999;
    }
    .mob{
        display: none !important;
    }
    
    .btn_main{
        background-color: #fb4949 !important;
        color: #ffffff !important;
        border: none !important;
        font-size: 20px !important;
    }
    
    .btn_main_alt{
        background-color: #ffffff !important;
        color: #fb4949 !important;
        border: none !important;
        font-size: 20px !important;
    }
    .btn_main:hover{
        color: #ffffff !important;
    }
    

    @media only screen and (max-width: 990px) {
        .desk{
            display: none !important;
        }
        .mob{
            display: flex !important;
            justify-content: space-between;
        }
    }
</style>

    <style>

        .navbar-dark .navbar-nav .nav-link {

            font-family: 'Outfit', Sans-Serif;

            font-weight: 500;

            font-size: 18px;

        }

        .navbar-dark .navbar-nav .nav-link {

            font-family: 'Outfit', Sans-Serif;

            font-weight: 500;

            font-size: 18px;

        }

        .admin-img {

            width: 14%;

        }

        .partner-wth {

            font-family: 'Outfit', Sans-Serif;

            font-weight: 500;

            font-size: 18px;

        }

        .logo {

            width: 56%;

            margin-bottom: 9px;

        }

        .navbar-dark .navbar-nav .nav-link:focus, .navbar-dark .navbar-nav .nav-link:hover {

            color: rgb(75 168 110);

        }

    </style>