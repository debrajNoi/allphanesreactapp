<!DOCTYPE html>

<html lang="en">

  <head>

<meta charset="utf-8">

<meta http-equiv="X-UA-Compatible" content="IE=edge">

<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

<title>EV Dreamz</title>

<link rel="icon" href="<?php echo base_url('images/Favicon.png');?>" type="image/png" sizes="16x16">

<meta charset="utf-8">

<link rel="preconnect" href="https://fonts.googleapis.com">

<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@100;200;300;400;500;600;700;800&display=swap" rel="stylesheet">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">



<link rel="stylesheet" href="<?php echo base_url('css/owlcarousel/owl.carousel.min.css');?>">

<link rel="stylesheet" href="<?php echo base_url('css/owlcarousel/owl.theme.default.min.css');?>">

<link type="text/css" rel="stylesheet" href="<?php echo base_url('css/fonts.css');?>" media="all">

<link type="text/css" rel="stylesheet" href="<?php echo base_url('css/bootstrap.min.css');?>" media="all">

<link type="text/css" rel="stylesheet" href="<?php echo base_url('css/style.css');?>" media="all">

<link type="text/css" rel="stylesheet" href="<?php echo base_url('css/price1.css')?>" media="all">

<!-- font awsome  -->
<script src="https://kit.fontawesome.com/83ce503d6d.js" crossorigin="anonymous"></script>

</head>

  

<?php

$controller = $this->router->fetch_class();



$method = $this->router->fetch_method();

?>

<body>

   <nav class="navbar navbar-expand-lg navbar-dark nav-sty">

        <div class="container-fluid ">

            <a class="navbar-brand" href="<?php echo base_url();?>"> 
                <img class="logo" src="<?php echo base_url('images/LOGGO.png');?>">
            </a>

            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar1" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbar1">

                <ul class="navbar-nav ml-auto"> 

                    <li class="nav-item <?php if($method=='index'){?> active<?php }?>">
                        <a class="nav-link" href="<?php echo base_url();?>">Buy EV</a>
                    </li>

                    <li class="nav-item <?php if($method=='sell'){?> active<?php }?>">
                        <a class="nav-link" href="<?php echo base_url();?>sell"> Sell Used EV  </a>
                    </li>

                    <!--<li class="nav-item"><a class="nav-link" href="html-components.html"> Charge EV </a></li>

                    <li class="nav-item"><a class="nav-link" href="html-components.html">Service EV</a></li>-->

                    <li class="nav-item <?php if($method=='pricing'){?> active<?php }?>">
                        <a class="nav-link" href="<?php echo base_url('pricing');?>">Pricing</a>
                    </li>

                    <li class="nav-item <?php if($method=='coming_soon'){?> active<?php }?>">
                        <a class="nav-link" href="<?php echo base_url('coming-soon');?>">Coming Soon</a>
                    </li>

                    <li class="nav-item <?php if($method=='vendor_regisration'){?> active<?php }?>">
                        <a class="nav-link" href="<?php echo base_url('vendor/regisration');?>">
                            <span class="partner-wth">List Your EV </span>
                        </a>
                    </li>

                </ul>


                <ul class="navbar-nav pull-right"> 

                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo base_url('vendor');?>"> 
                            <img src="<?php echo base_url('images/my_account.png');?>" class="admin-img"> 
                        </a>
                    </li>

                </ul>

            </div>

        </div>

    </nav>



    <style>

        .navbar-dark .navbar-nav .nav-link {

            font-family: 'Outfit', Sans-Serif;

            font-weight: 500;

            font-size: 18px;

        }

        .navbar-dark .navbar-nav .nav-link {

            font-family: 'Outfit', Sans-Serif;

            font-weight: 500;

            font-size: 18px;

        }

        .admin-img {

            width: 14%;

        }

        .partner-wth {

            font-family: 'Outfit', Sans-Serif;

            font-weight: 500;

            font-size: 18px;

        }

        .logo {

            width: 56%;

            margin-bottom: 9px;

        }

        .navbar-dark .navbar-nav .nav-link:focus, .navbar-dark .navbar-nav .nav-link:hover {

            color: rgb(75 168 110);

        }

    </style>