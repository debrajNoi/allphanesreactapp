<div class="conten-left pull-left">
        <div class="item clearfix">
          <div class="item-block clearfix">
            <div class="image" style="text-align:center;"> <a href="#" target="_self">
		<?php
		$user=$this->session->userdata('userdata');
		 $sql_user=$this->db->query('SELECT * FROM users WHERE user_id="'.$user['user_id'].'"');
		 $profile=$sql_user->result();
		?>	
			<img class="blah" src="<?php echo base_url('uploads/users/'.$profile[0]->image);?>" style="border-radius:50%; height:100px;width:100px;" /> </a> </div>
            <div class="item-content" style="text-align:center;">
              <h3><a href="#"><?php echo $profile[0]->first_name.' '.$profile[0]->last_name;?></a></h3>
              <!--<div class="des">Premium User</div>-->
            </div>
          </div>
          <ul class="check clearfix">
            <li>
              <label style="font-size: 16px; font-weight: 700; line-height: 42px;"><a href="<?php echo base_url('dashboard');?>">My Profile</a></label>
            </li>
       <li>
		<label style="font-size: 16px; font-weight: 700; line-height: 42px;"><a href="<?php echo base_url('courses');?>">Course</a></label>
								</li>
								
            <li>
              <label style="font-size: 16px; font-weight: 700; line-height: 42px;"><a href="<?php echo base_url('logout');?>">Logout</a></label>
            </li>
          </ul>
        </div>
      </div>