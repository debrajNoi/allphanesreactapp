<?php 
    $method1 = $this->router->fetch_method();
?>
<style>
    .footer-widget ul li a.active{
        color: #00A76D;
    }
    .wha{
        color: #00a76d;
        /*before font-size: 40px; was there*/
        font-size: 80px; 
        display: none;

    }
    .des-what{
        text-decoration: none;
        color: #00a76d;
        font-size: 80px; 
        position: absolute; 
        bottom: 10px; 
        right: 70px;
        display: block;
    }
    .des-what:hover{
        color: #00a76d;
    }
    @media only screen and (max-width: 600px) {
        .wha{
            display: block;
           /*font-size: 55px;  old code*/
            font-size: 70px;
            margin-right: -15px;
        }
        .des-what{
            display: none;
        }
    }

    .social-icon{
        color: #00a76d;
    }
    .desk-social{
        position: absolute;
        right: 70px;
        width: 150px;
        display: flex;
        justify-content: space-between;
        /* display: block; */
    }
    .mob-soc{
        display: none;
    }
    @media only screen and (max-width: 1085px) {
        
        .desk-social{
            display: none;
        }
        .mob-soc{
            display: flex;
        }
    }
</style>
<div class="footer" style="position: relative;">
    <div class="container">
        <div class="row justify-content-between">


            <!-- footer-about -->

            <!-- <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-6 "> -->
            <div class="col-xl-2 col-lg-2 col-md-3 col-sm-6 col-6 ">

                <div class="footer-widget ">

                    <div class="footer-title">About</div>

                    <ul class="list-unstyled">

                        <li><a href="<?php echo base_url('about-us');?>" class="<?if($method1 == 'about_us') { echo 'active';}?>">About EV Dreamz</a></li>

                        <li><a href="https://medium.com/@EV_Dreamz">Blog</a></li>
                        

                        <!--<li><a href="<?php echo base_url('coming-soon');?>">Coming Soon</a></li>-->

                    </ul>

                </div>

            </div>

            <!-- /.footer-about -->

            <!-- footer-links -->

            <!-- <div class="col-xl-2 col-lg-2 col-md-4 col-sm-6 col-6 "> -->
            <div class="col-xl-2 col-lg-2 col-md-3 col-sm-6 col-6 ">

                <div class="footer-widget ">

                    <div class="footer-title">Partnerships</div>

                    <ul class="list-unstyled">

                        <li><a href="<?php echo base_url('partner-with-us');?>" class="<?if($method1 == 'partner_with_us') { echo 'active';}?>">Partner with us</a></li>

                        <li><a href="<?php echo base_url('vendor/regisration');?>" class="<?if($method1 == 'vendor_regisration') { echo 'active';}?>">List your EV</a></li>

                        <li><a href="<?php echo base_url('sell');?>" class="<?if($method1 == 'sell') { echo 'active';}?>">Sell used EV</a></li>

                    </ul>

                </div>

            </div>

            <!-- /.footer-links -->

            <!-- footer-links -->
            <!-- <div class="col-xl-2 col-lg-2 col-md-4 col-sm-6 col-6 "> -->
            <div class="col-xl-2 col-lg-2 col-md-3 col-sm-6 col-6 ">
                <div class="footer-widget ">

                    <div class="footer-title">Legal</div>

                    <ul class="list-unstyled">

                        <li><a href="<?php echo base_url('terms');?>" class="<?if($method1 == 'terms') { echo 'active';}?>">Terms</a></li>

                        <li><a href="<?php echo base_url('privacy');?>" class="<?if($method1 == 'privacy') { echo 'active';}?>">Privacy</a></li>

                        <li><a href="<?php echo base_url('cancellation');?>" class="<?if($method1 == 'cancellation') { echo 'active';}?>">Cancellation</a></li>
                        
                        <li><a href="<?php echo base_url('sitemap');?>" class="<?if($method1 == 'sitemap') { echo 'active';}?>">Sitemap</a></li>

                    </ul>

                </div>
            </div>

            <!-- <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-6 "> -->
            <div class="col-xl-2 col-lg-2 col-md-3 col-sm-6 col-6 ">

                <div class="footer-widget ">

                    <div class="footer-title">Support</div>

                    <ul class="list-unstyled">

                        <li><a href="<?php echo base_url('contact-us');?>" class="<?if($method1 == 'contact_us') { echo 'active';}?>">Contact us</a></li>

                        <li class="mf-15"><a href="mailto:support@evdreamz.com">support@evdreamz.com</a></li>

                        <li><a href="tel:9650461101">Call: +91 96504 61101</a></li>

                    </ul>

                </div>

            </div>



            <div class="col-xl-2 col-lg-2 col-md-3 col-8">

                <div class="footer-widget s_wid">

                    <ul class="list-unstyled f-flex mt-2 mob-soc">

                        <li><a href="https://www.facebook.com/EVDreamz/" class="social"><i class="fa fa-facebook social-icon"
                                    aria-hidden="true"></i></a></li>

                        <li><a href="https://twitter.com/ev_dreamz/" class="social"><i class="fa fa-twitter social-icon"
                                    aria-hidden="true"></i></a></li>

                        <li><a href="https://www.instagram.com/ev.dreamz/" class="social"><i class="fa fa-instagram social-icon"
                                    aria-hidden="true"></i></a></li>
                        <li><a href="https://www.linkedin.com/company/ev-dreamz" class="social"><i class="fa fa-linkedin social-icon"
                                    aria-hidden="true"></i></a></li>


                    </ul>
                    <div class="wh-center">
                        <a href="https://api.whatsapp.com/send?phone=+919871455790" target="_blank">
                            <i class="fa fa-whatsapp wha" aria-hidden="true"></i>
                        </a>
                    </div>

                </div>



            </div>
            
            <ul class="list-unstyled mt-2 desk-social">

                <li><a href="https://www.facebook.com/EVDreamz/" class="social"><i class="fa fa-facebook social-icon"
                            aria-hidden="true"></i></a></li>

                <li><a href="https://twitter.com/ev_dreamz/" class="social"><i class="fa fa-twitter social-icon"
                            aria-hidden="true"></i></a></li>

                <li><a href="https://www.instagram.com/ev.dreamz/" class="social"><i class="fa fa-instagram social-icon"
                            aria-hidden="true"></i></a></li>
                <li><a href="https://www.linkedin.com/company/ev-dreamz" class="social"><i class="fa fa-linkedin social-icon"
                                    aria-hidden="true"></i></a></li>


            </ul>
            
            <a href="https://api.whatsapp.com/send?phone=+919871455790" target="_blank" class="des-what">
                <i class="fa fa-whatsapp" aria-hidden="true"></i>
            </a>

            <!-- /.footer-links -->

        </div>



        <div class="footer-bottom text-center">
            <div style="font-size: 16px !important;">
                Copyright © 2022 &nbsp; EV Dreamz Pvt. Ltd. &nbsp;&nbsp; All rights reserved &nbsp;&nbsp; &nbsp;
                Made with
                <i class="fa fa-heart" style="color:#EA476C;" aria-hidden="true"></i> and passion
            </div>

        </div>

    </div>

</div>


</body>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script src="<?php echo base_url('js/bootstrap.min.js');?>"></script>


<script>
    const vendBtn = document.getElementById('vendBtn')
    const vendBox = document.getElementById('vendBox')

    const vendToggle = vendBtn.addEventListener('click', () => {
        vendBox.classList.toggle('active')
    })
</script>


</html>