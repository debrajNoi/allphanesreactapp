

<section class="comingsoon-set-1">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
         <p class="btn comingsoon-btn">Coming Soon!</p>
         <h4 class="hed-text-w">Install a home charge point for ultimate EV charging convenience</h4>
         <p class="hed-text-paragrap">Installing a home charge point gives you ultimate convenience when it comes to charging.
Simply enter your EV socket type and choose from a wide range of home chargers.</p>
      </div>
      <div class="col-md-6 text-center mt-5">
         <img src="<?php echo base_url('images/04.png');?>" alt="" class="img-fluid">
      </div>
    </div>
  </div>
</section>

<section class="comingsoon-set-2">
  <div class="container">
    <div class="row">
      <div class="col-md-5 text-center mt-5">
         <img src="<?php echo base_url('images/05.png');?>" alt="" class="img-fluid">
      </div>
      <div class="col-md-1"></div>
      <div class="col-md-6">
         <p class="btn comingsoon-btn">Coming Soon!</p>
         <h4 class="hed-text-b">Charge your EV anytime, anywhere with the biggest
EV Charging Network</h4>
         <p class="hed-text-paragrap">Join the biggest Roaming EV Charging Network. Get access to the largest numbers of EV charge points in the country from a single easy to use platform. </p>
      </div>
    </div>
  </div>
</section>

<section class="comingsoon-set-3">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
         <p class="btn comingsoon-btn">Coming Soon!</p>
         <h4 class="hed-text-b">Locate the nearest EV Service Centre around you </h4>
         <p class="hed-text-paragrap">Keeping your electric 2 wheeler in shape will ensure your vehicle is safe, reliable and in good order. This will help with its residual value when it is time to sell. <br>
<br>
Enter your pincode to find a service centre.</p>
      </div>
      <div class="col-md-1"></div>
      <div class="col-md-3 text-center mt-5">
         <img src="<?php echo base_url('images/06.png');?>" alt="" class="img-fluid">
      </div>
      <div class="col-md-2"></div>
    </div>
  </div>
</section>

<section class="comingsoon-set-1">
  <div class="container">
    <div class="row">
      <div class="col-md-5 text-center mt-for-disk">
         <img src="<?php echo base_url('images/07.png');?>" alt="" class="img-fluid">
      </div>
      <div class="col-md-1"></div>
      <div class="col-md-6">
         <p class="btn comingsoon-btn">Coming Soon!</p>
         <h4 class="hed-text-b">The cool and easy way
to browse, book, buy and sell electric cars. </h4>
         
      </div>
    </div>
  </div>
</section>

<section class="comingsoon-set-3">
  <div class="container">
    <div class="row">
      <div class="col-md-5">
         <p class="btn comingsoon-btn">Coming Soon!</p>
         <h4 class="hed-text-b">Drive your dream electric car or 2 wheeler with Instant Loan </h4>
         <p class="hed-text-paragrap">In order to boost up the EV adoption in India, we are soon going to offer the EV loan facility right from our easy to use platform. Join hands with us and let us build the largest EV ecosystem.</p>
      </div>
      <div class="col-md-1"></div>
      <div class="col-md-6 text-center mt-5">
         <img src="<?php echo base_url('images/08.png');?>" alt="" class="img-fluid" style="max-width: 95% !important;">
      </div>
    </div>
  </div>
</section>

