<style>
    .btn_main:hover{
        color: #fff !important;
    }
</style>

<?php
    // echo base64_decode($sell[0]->content);
?>

<section class="sell-landi-set-1">
  <div class="container">
    <div class="row">
      <div class="col-md-1"></div>
      <div class="col-md-10 text-center">
          <?php 
            $header = get_page_section($sell[0]->id, 'header');
            
          ?>
          
        <h3><?php echo base64_decode($header[0]->content); ?></h3>
        <!--<h3>Sell your used electric 2 wheeler in <br/>3 simple steps</h3>-->
        <div class="my-3 subheader" style="font-size: 20px;">
            <?php
                $subheader = get_page_section($sell[0]->id, 'subheader');
                echo base64_decode($subheader[0]->content);
            ?>
            
        </div>
        <div class="sell-steps">
           <ul>
            <?php 
                $steps = get_page_section($sell[0]->id, 'step');
                
                foreach($steps as $step){
                    
                
            ?>
             <li>
               <div class="icon-box"><img src="<?php echo base_url('images/').$step->image;?>" alt="<?php echo $step->img_alt;?>"></div>
               <?php echo base64_decode($step->content); ?>
               <!--<p>List your EV with a fair price tag and all required details</p>-->
             </li>
             <?php } ?>
             
             
           </ul>
           <div class="arrow-la-1"><img src="<?php echo base_url('images/arrow-la.png');?>" alt="sell-arrow"></div>
           <div class="arrow-la-2"><img src="<?php echo base_url('images/arrow-la.png');?>" alt="sell-arrow"></div>
        </div>
          
        
         
        <div class="clearfix"></div> 
        <?php 
            $other = get_page_section($sell[0]->id, 'other');
            
          ?>
       
        <img src="<?php echo base_url('uploads/cms/').$other[0]->image;?>" alt="<?php echo $other[0]->img_alt;?>" class="sell-landi-car">
        <?php 
            //echo base64_decode($other[0]->content);
        ?>
        <h4><?php echo base64_decode($other[0]->content);?></h4>
        <!--<h4>Contribute to our mission to achieve 100% green transportation by end of 2030 </h4>-->
      </div>
      <div class="col-md-1"></div>
      <div class="col-md-12 mb-5 text-center">
            <a class="btn btn-green btn_main" href="<?php echo base_url('vendor/regisration');?>">Start Selling your EV</a>
       </div>
    </div>
  </div>
</section>
