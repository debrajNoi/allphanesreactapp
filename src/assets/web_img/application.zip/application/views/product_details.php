<?php

    $sql_vendor=$this->db->query('SELECT * FROM users WHERE id="'.$product->vendor_id.'"');

    $vendor=$sql_vendor->row();
    
    $sql_markasfavorite1 = $this->db->query('SELECT id,status FROM tbl_favorite WHERE user_id="'.$this->session->userdata('admin_id').'" AND product_id = "'.$product->id.'"');
    
    $markasfavorite1 = $sql_markasfavorite1->row();
    
    //user details
    $user_id = $this->session->userdata('admin_id');
    $sql_vendor=$this->db->query('SELECT users.*, cities.city FROM users JOIN cities ON users.city = cities.id WHERE users.id="'.$user_id.'" ');
    $user=$sql_vendor->row();
    // echo "<pre>";
    // print_r($user);
    // echo "</pre>";

?>
<!-- CSS for mark as favorite -->
<style>
    .des-sec {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .fav {
        display: flex;
        align-items: center;
        color: #b6b5aa;
        font-size: 19px;
    }

    .fav i {
        color: #ada6a6;
        font-size: 33px;
    }
    #claim_btn{
        padding-right: 0 !important;
        padding-left: 0 !important;
    }
    .btn-3{
        color: #fff;
        font-size: 18px;
        padding: 8px 15px;
        background-color: #00A765;
        border-radius: 25px;
        font-family: 'Outfit', Sans-Serif;
        text-align: center;
        width: 100%;
        font-weight: 400;
    }
    .btn-3:hover{
        color: #fff;
    }
</style>
<!-- CSS for right side -->
<style>
    @media only screen and (max-width: 998px) {
        .own-show-card {
            padding: 25px;
        }

        .details-box {
            padding: 25px !important;
        }

        .details-box-green {
            padding: 25px !important;
        }
    }
</style>
<!--  -->

<link rel="stylesheet" href="<?=base_url('assets/css/demo.css')?>">

<section class="product-deta">

    <div class="container">

        <div class="row">

            <div class="col-md-7">

                <p><a href="javascript:history.go(-1)" class="back-search">Back to search results</a></p>

                <div class="owl-product-deta owl-carousel owl-theme">

                    <?php

                        if($product->front_view!=''){?> 

                    <div>

                        <div class="skt-slid-box">

                            <div class="skut-img-box2 dtls_pro_img_box"><img src="<?php echo base_url('uploads/products/'.$product->front_view);?>" alt="<?php echo $product->slug;?>"></div>

                        </div>

                    </div>

                    <?php }?>

                    <?php

                        if($product->side_view1!=''){?> 

                    <div>

                        <div class="skt-slid-box">

                            <div class="skut-img-box2 dtls_pro_img_box"><img src="<?php echo base_url('uploads/products/'.$product->side_view1);?>" alt="<?php echo $product->slug;?>"></div>

                        </div>

                    </div>

                    <?php }?>

                    <?php

                        if($product->side_view2!=''){?> 

                    <div>

                        <div class="skt-slid-box">

                            <div class="skut-img-box2 dtls_pro_img_box"><img src="<?php echo base_url('uploads/products/'.$product->side_view2);?>" alt="<?php echo $product->slug;?>"></div>

                        </div>

                    </div>

                    <?php }?> 

                    <?php

                        if($product->rear_view!=''){?> 

                    <div>

                        <div class="skt-slid-box">

                            <div class="skut-img-box2 dtls_pro_img_box"><img src="<?php echo base_url('uploads/products/'.$product->rear_view);?>" alt="<?php echo $product->slug;?>"></div>

                        </div>

                    </div>

                    <?php }?> 

                    <?php

                        if($product->close_up1!=''){?>

                    <div>

                        <div class="skt-slid-box">

                            <div class="skut-img-box2 dtls_pro_img_box"><img src="<?php echo base_url('uploads/products/'.$product->close_up1);?>" alt="<?php echo $product->slug;?>"></div>

                        </div>

                    </div>

                    <?php }?>

                    <?php

                        if($product->close_up2!=''){?>

                    <div>

                        <div class="skt-slid-box">

                            <div class="skut-img-box2 dtls_pro_img_box"><img src="<?php echo base_url('uploads/products/'.$product->close_up2);?>" alt="<?php echo $product->slug;?>"></div>

                        </div>

                    </div>

                    <?php }?>       

                </div>

                
                
                <div class="des-sec mt-5">
                    <div class="btn btn btn-description">Description</div>
                    <div class="fav">
                        <div>Mark as favorite</div>
                        <?php
                            if($this->session-> userdata('admin_id')){
                                if($markasfavorite1){
                                    if($markasfavorite1->status == 1){
                                       echo '<i class="fas fa-heart p-2" onClick="mark_as_favorite()" style="cursor: pointer; color:#FB4949" id="markFavorite"></i>';
                                    } else {
                                       echo '<i class="fas fa-heart p-2" onClick="mark_as_favorite()" style="cursor: pointer"></i>';
                                    }
                                } else {
                                    echo '<i class="fas fa-heart p-2" onClick="mark_as_favorite()" style="cursor: pointer"></i>';
                                }
                            }
                            else { ?>
                            <a href="<?=base_url('user/login')?>"><i class="far fa-heart p-2" style="cursor: pointer"></i></a>
                        <?php } ?>
                    </div>
                </div>
                
                
                

                <div class="short-desc fix_text_flow">

                    <?php echo base64_decode ($product->description);?>

                </div>

                <p class="btn btn-description mt-5">Specification</p>

                <div class="feturs">

                    <div class="row">

                        <div class="col-md-4 col-sm-6">

                            <table>

                                <tr>

                                    <td>

                                        <p><img src="<?php echo base_url('images/brand_name.png');?>" alt="brand_name"></p>

                                    </td>

                                    <td>

                                        <p><?php echo $product->brand;?></p>

                                    </td>

                                </tr>

                            </table>

                        </div>

                        <div class="col-md-4 col-sm-6">

                            <table>

                                <tr>

                                    <td>

                                        <p><img src="<?php echo base_url('images/speed.png');?>" alt="top_speed"></p>

                                    </td>

                                    <td>

                                        <p><?php echo $product->top_speed;?></p>

                                    </td>

                                </tr>

                            </table>

                        </div>

                        <div class="col-md-4 col-sm-6">

                            <table>

                                <tr>

                                    <td>

                                        <p><img src="<?php echo base_url('images/range.png');?>" alt="product_range"></p>

                                    </td>

                                    <td>

                                        <p><?php echo $product->product_range;?></p>

                                    </td>

                                </tr>

                            </table>

                        </div>

                    </div>

                    <div class="row">

                        <div class="col-md-4 col-sm-6">

                            <table>

                                <tr>

                                    <td>

                                        <p><img src="<?php echo base_url('images/charge.png');?>" alt="charging_time"></p>

                                    </td>

                                    <td>

                                        <p><?php echo $product->charging_time;?></p>

                                    </td>

                                </tr>

                            </table>

                        </div>

                        <div class="col-md-4 col-sm-6">

                            <table>

                                <tr>

                                    <td>

                                        <p><img src="<?php echo base_url('images/motor.png');?>" alt="motor power"></p>

                                    </td>

                                    <td>

                                        <p><?php echo $product->motor_power;?></p>

                                    </td>

                                </tr>

                            </table>

                        </div>

                        <div class="col-md-4 col-sm-6">

                            <table>

                                <tr>

                                    <td>

                                        <p><img src="<?php echo base_url('images/Registration.png');?>" alt="registration_required" ></p>

                                    </td>

                                    <td>

                                        <p><?php echo $product->registration_required;?></p>

                                    </td>

                                </tr>

                            </table>

                        </div>

                    </div>

                    <div class="row">

                        <div class="col-md-4 col-sm-6">

                            <table>

                                <tr>

                                    <td>

                                        <p><img src="<?php echo base_url('images/wheel.png');?>" alt="tyres"></p>

                                    </td>

                                    <td>

                                        <p><?php echo $product->tyres;?></p>

                                    </td>

                                </tr>

                            </table>

                        </div>

                        <div class="col-md-4 col-sm-6">

                            <table>

                                <tr>

                                    <td>

                                        <p><img src="<?php echo base_url('images/battery.png');?>" alt="battery_capacity" ></p>

                                    </td>

                                    <td>

                                        <p><?php echo $product->battery_capacity;?></p>

                                    </td>

                                </tr>

                            </table>

                        </div>

                        <div class="col-md-4 col-sm-6">

                            <table>

                                <tr>

                                    <td>

                                        <p><img src="<?php echo base_url('images/year.png');?>" alt="year" ></p>

                                    </td>

                                    <td>

                                        <p><?php echo $product->year;?></p>

                                    </td>

                                </tr>

                            </table>

                        </div>

                    </div>

                    <div class="row">

                        <div class="col-md-4 col-sm-6">

                            <table>

                                <tr>

                                    <td>

                                        <p><img src="<?php echo base_url('images/model.png');?>" alt="model name"></p>

                                    </td>

                                    <td>

                                        <p><?php echo $product->model;?></p>

                                    </td>

                                </tr>

                            </table>

                        </div>

                        <div class="col-md-4 col-sm-6">

                            <table>

                                <tr>

                                    <td>

                                        <p><img src="<?php echo base_url('images/color.png');?>" alt="color"></p>

                                    </td>

                                    <td>

                                        <p><?php echo $product->color;?></p>

                                    </td>

                                </tr>

                            </table>

                        </div>

                        <div class="col-md-4 col-sm-6">

                            <table>

                                <tr>

                                    <td>

                                        <p><img src="<?php echo base_url('images/connectivity.png');?>" alt="connectivity"></p>

                                    </td>

                                    <td>

                                        <p><?php echo $product->connectivity;?></p>

                                    </td>

                                </tr>

                            </table>

                        </div>

                    </div>

                    <div class="row">

                        <div class="col-md-4 col-sm-6">

                            <table>

                                <tr>

                                    <td>

                                        <p><img src="<?php echo base_url('images/safety.png');?>" alt="safety_features"></p>

                                    </td>

                                    <td>

                                        <p><?php echo $product->safety_features;?></p>

                                    </td>

                                </tr>

                            </table>

                        </div>

                        <div class="col-md-4 col-sm-6">

                            <table>

                                <tr>

                                    <td>

                                        <p><img src="<?php echo base_url('images/display.png');?>" alt="display"></p>

                                    </td>

                                    <td>

                                        <p><?php echo $product->display;?></p>

                                    </td>

                                </tr>

                            </table>

                        </div>

                        <div class="col-md-4 col-sm-6">

                            <table>

                                <tr>

                                    <td>

                                        <p><img src="<?php echo base_url('images/brake.png');?>" alt="break_type"></p>

                                    </td>

                                    <td>

                                        <p><?php echo $product->break_type;?></p>

                                    </td>

                                </tr>

                            </table>

                        </div>

                    </div>

                    <div class="row">

                        <div class="col-md-4 col-sm-6">

                            <table>

                                <tr>

                                    <td>

                                        <p><img src="<?php echo base_url('images/warranty.png');?>" alt="warranty"></p>

                                    </td>

                                    <td>

                                        <p><?php echo $product->warranty;?></p>

                                    </td>

                                </tr>

                            </table>

                        </div>

                        <div class="col-md-4 col-sm-6">

                            <table>

                                <tr>

                                    <td>

                                        <p><img src="<?php echo base_url('images/location.png');?>" alt="location"></p>

                                    </td>

                                    <td>

                                        <p><?php echo $product->location;?></p>

                                    </td>

                                </tr>

                            </table>

                        </div>

                        <div class="col-md-4 col-sm-6">

                            <table>

                                <tr>

                                    <td>

                                        <p><img src="<?php echo base_url('images/pincode.png');?>" alt="pincode" style="height: 28px;width: 20px;"></p>

                                    </td>

                                    <td>

                                        <p><?php echo $product->pincode;?></p>

                                    </td>

                                </tr>

                            </table>

                        </div>

                    </div>

                </div>

                <div class=" clearfix"></div>

                <div class="bor-bot-1"></div>

                <form class="review-form">

                    <p>Every effort has been made to ensure the accuracy of the information above, however, errors may occur. Do not rely entirely on this information but check with the retailer about items which may affect your decision to purchase.</p>

                </form>


                <form class="review-form">
                    <label class="mt-5" style="font-size: 21px;">Write a review of this product</label>
                    <textarea class="col-md-12 form-control" cols="30" rows="6" name="review" id="review"></textarea>

                    <div class="rate">
                        <input type="radio" id="star5" name="rate" value="5" />
                        <label for="star5" title="text">5 stars</label>
                        <input type="radio" id="star4" name="rate" value="4" />
                        <label for="star4" title="text">4 stars</label>
                        <input type="radio" id="star3" name="rate" value="3" />
                        <label for="star3" title="text">3 stars</label>
                        <input type="radio" id="star2" name="rate" value="2" />
                        <label for="star2" title="text">2 stars</label>
                        <input type="radio" id="star1" name="rate" value="1" />
                        <label for="star1" title="text">1 star</label>
                    </div>

                    <div class="text-right" style="margin-top: 20px;">
                        <button class="btn btn-3 sbmt_otp btn_main" type="button" style="" onclick="submit_ratings()">Submit</button>
                    </div>

                    <p class="mb-5" id="review_result"></p>

                    <b class="mt-5">Reviews</b>

                    <?php foreach($review_list as $key => $val){ ?>
                    <div class="rate-result-views mb-3">
                        <?=$val->rate?> <?php for($i=0; $i<$val->rate; $i++){?><i class="fa fa-star text-warning" aria-hidden="true"></i><?php } ?>
                        <p class="mt-0"><?=$val->content?></p>
                        <p class="text-right mt-0"><?=date('d-M-Y', strtotime($val->created_at))?></p>
                    </div>
                    <?php } ?>


<!--                     <div class="container">
                      <span id="rateMe2"  class="empty-stars"></span>
                    </div> -->

                    <!-- rating.js file -->
                    <!-- <script src="js/addons/rating.js"></script> -->

                    <script type="text/javascript">
                        // Rating Initialization
                            // $(document).ready(function() {
                            //   $('#rateMe2').mdbRate();
                            // });
                    </script>
                </form>

            </div>

            <div class="col-md-5">

                <div class="details-box">

                    <h4><?php echo $product->brand;?></h4>

                    <h5><?php echo $product->model;?>
                        <?php if($product->is_verified == 1){ ?>
                        <div class="p-icon common-green-color" style="margin-left: 5px; display: inline-grid;">
                            <i class="fa fa-check" aria-hidden="true"></i>
                        </div>
                        <?php } ?>
                    </h5>

                    <h4 class="mb-5">INR <?php echo $product->price;?></h4>

                    <!--<p><span><img src="<?php echo base_url('images/met-i.png');?>" alt=""></span> <?php echo $product->product_range;?> Kms</p>

                        <p><span><img src="<?php echo base_url('images/plag-i.png');?>" alt=""></span> <?php echo $product->charging_time;?> Hrs</p>-->

                    <!-- <p class="showroom"><span><b></span> <?php echo $vendor->company_name;?></b></p> -->
                    <h5 style="font-size: 17px; color: #212529 !important; font-weight: 700;"><?php echo $vendor->company_name;?>
                        <?php if($vendor->mobile_verified == 1){ ?>
                        <div class="p-icon common-green-color" style="margin-left: 5px; display: inline-grid;">
                            <i class="fa fa-check" aria-hidden="true"></i>
                        </div>
                        <?php } ?>
                    </h5>

                    <p><?php echo $vendor->neighborhood;?></p>

                    <p><span><img src="<?php echo base_url('images/i-16.png');?>" alt="location"></span> <?php echo $product->location;?></p>

                    <!-- <?php //if($vendor->email_verification == 1 && $vendor->mobile_verified == 1){ ?> -->
                    <!-- <p><a href="<?=site_url('front/vendor_details/'.$vendor->id.'?id='.$this->input->get('id'))?>" class="text-primary">View Profile</a></p>  -->

                        <!-- <pre><?php print_r($vendor)?></pre> -->
                        <?php if($vendor->is_website_activated == 0){ ?>
                        <p><a href="<?=$vendor->website?>" class="text-primary"><?=$vendor->website?></a></p>
                        <?php }else{ ?>
                        <p>
                            <a href="<?=site_url($vendor->slug)?>" class="text-primary">
                                View Website
                            </a>
                        </p>
                        <?php } ?>

                    <?php //} ?>

                    <p><label style="width: 27px; font-size: 18px;"><i class="fas fa-at"></i></label> <?=$vendor->email?></p>
                    <p><label style="width: 27px; font-size: 20px;"><i class="fa fa-mobile"></i></label> <a style="color: #000;" href="tel:<?=$vendor->mobile?>"><?=$vendor->mobile?></a></p>

                    <?php if($product->plan_id == 3){?>
                    <p><label style="width: 27px; font-size: 18px;"><i class="fas fa-window-maximize"></i></label>  <?=$vendor->website?></p>
                    <?php } ?>

                    <div class="mt-5 mb-5">

                        <?php

                            if( $this->session->flashdata('success')){?>

                        <div class="alert alert-success"><?php echo $this->session->flashdata('success');?></div>

                        <?php }?>

                        <?php

                            if( $this->session->flashdata('error')){?>

                        <div class="alert alert-danger"><?php echo $this->session->flashdata('error');?></div>

                        <?php }?>

                        <!--<button class="btn btn-3 mb-4 btn_main" onclick="BookRequest1()">Buy Now</button>-->
                        <!--<button class="btn btn-3 mb-4 btn_main" onclick="BookRequest()">Book a test ride</button>-->
                        
                        <?php 
                            if($user->user_role == 1 || $user->user_role == 2){
                        ?>
                                <button class="btn btn-3 mb-4 btn_main" onclick="BookRequest()">Buy/Book Now</button>
                        <?php
                            } else{
                        ?>
                                <button class="btn btn-3 mb-4 btn_main" onClick = "BookRequestReject()">Buy/Book Now</button>
                        <?php
                            }
                        ?>
                        

                        <?php /*<button class="btn btn-blu-2" onclick="ShowOwner()">Contact Showroom Owner </button> */ ?>

                    </div>

                    <p class="share-save">

                        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo base_url('product-details/'.$product->slug)?>" target="_blank"><i class="fa fa-facebook fa-2x" style="color: #4958C5;"></i></a>

                        &nbsp;  <a href="https://wa.me/?text=<?php echo base_url('product-details/'.$product->slug)?>" target="_blank"><i class="fa fa-whatsapp fa-2x" style="color:#4DC85A;"></i></a>

                        <!--&nbsp;  <a href="https://www.instagram.com/?url=<?php echo base_url('product-details/'.$product->slug)?>" target="_blank"><i  class="fa fa-instagram fa-2x" style="color:#EA476C; aria-hidden="true"></i></a>-->

                        &nbsp;  <a href="https://twitter.com/intent/tweet?url=<?php echo base_url('product-details/'.$product->slug)?>" target="_blank"><i  class="fa fa-twitter fa-2x" style="color:#0fb2e7;" aria-hidden="true"></i></a>

                    </p>

                </div>

                <?php 
                if($product->is_claimed==0){
                ?>
                
                <div class="details-box mt-3">

                    <!-- A card -->
                    <div class="own-show-cad">
                        <div class="own-1">Own this showroom <br>or work in this showroom ?</div>
                        <h3 class="my-4">
                            Claim this listing to own this listing
                        </h3>
                        <button type="button" id="claim_btn" onclick="open_otp();">Claim this listing</button>


                        <div style="display: none;" class="mt-3" id="otp_form">
                            <input type="hidden" class="form-control" name="otp_product_id" id="otp_product_id" value="<?php echo $product->id; ?>" />
                            <input type="text" class="form-control" name="otp_data" id="otp_data" value="" placeholder="OTP" />

                            <input type="button" class="btn btn-xs btn-3 mt-3 btn_main" id="sbmt_otp" name="sbmt_otp" onclick="check_otp()" value="Submit" />
                            <br/>
                            <span class="text-danger" id="show_error"></span>
                        </div>
                    </div>
                    <!-- end A card  -->                    
                </div>
                <?php } ?>

                <div class="details-box-green">

                    <h5>Buy with trust and transparency</h5>

                    <table>

                        <tr>

                            <td><img src="<?php echo base_url('images/right-i.png');?>" alt="check_icon"></td>

                            <td style="font-weight: 500;">All electric 2 wheelers listed on EV Dreamz have been vetted and  are being sold by an approved dealer in India, giving you peace of mind. You are dealing with a certified professional expert retailer.</td>

                        </tr>

                    </table>

                </div>

            </div>

        </div>

    </div>

    <div class="">
            
        <section class="scrt-slider">

          <div class="container-fluid brand-sec">

              <div class="col-md-12 text-left">

                <h4>Compare with similar products</h4>

              </div>

            <div class="row populars">

              <?php

              foreach($popular_list as $popular){?>

                 <div class="col-lg-3 col-md-4 col-md-3 col-sm-6 col-xs-12 mb-5 popular">

                <div class="full-sec-brand">

                  <div class="image-brand-sec"> <img src="<?php echo base_url('uploads/products/'.$popular->front_view);?>" alt="<?php echo $popular->slug;?>"></div>

                </div>

                <table class="cont-table2">
                    <tr>
                        <td>
                            <p class="pe-taxt-2-c" style="font-size: 14px;">
                                <span><?php echo $popular->company_name;?></span> &nbsp; | &nbsp; 
                                <span>INR <?php echo $popular->price;?></span> &nbsp;
                            </p>
                        </td>
                        <td>
                            <a href="<?php echo base_url('product-details/'.$popular->slug); ?>"><button class="btn btn-view-more2" style="margin: 4px -8px 8px 0px;">View More</button></a>
                        </td>
                    </tr>
                </table>

              </div>

              <?php }?>

              <!--<a href="" class="load">Load More</a>-->

              <!-- <div class="col-md-12 text-center mt-5">  <button class="btn btn-view-more-gray showMore1 buttonToogle1 btn_main"><a href="javascript:;" class="showMore1">View More</button></a></div> -->

          </div>

          </div>

        </section>

    </div>

    <div class="modal fade" id="CustomerModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">

        <form method="post" action="<?php echo base_url('User/ProductBooking');?>">

            <div class="modal-dialog" role="document">

                <div class="modal-content">

                    <div class="modal-header">

                        <h5 class="modal-title" id="exampleModalLabel">Booking Request</h5>

                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">

                        <span aria-hidden="true">&times;</span>

                        </button>

                    </div>

                    <div class="modal-body">

                        <div class="row">
                            <div class="form-group col-md-6">
                                <label for="recipient-name" class="col-form-label">Name</label><br>
                                <input type="hidden" name="slug" value="<?php echo $this->uri->segment(2);?>" />
                                <input type="hidden" name="cus_id" value="<?php echo $user->id;?>?>" />
                                <input type="hidden" name="customer_location" value="<?php echo $user->city;?>" />
                                <!--if($user->role-->
                                <?php echo $user->name;?>
                            </div>
                            
                            <div class="form-group col-md-6">
                                <label for="message-text" class="col-form-label">Mobile</label>
                                <br><?php echo $user->mobile;?>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="message-text" class="col-form-label">Email</label>
                            <br><?php echo $user->email;?>
                        </div>

                        <div class="form-group">
                                <label for="message-text" class="col-form-label">Location</label>
                                <br><?php echo $user->city;?>
                        </div>
                        
                        <div class="form-group">
                            <label for="when_to_buy" class="col-form-label">How soon do you want to buy?</label> <br>
                            <input type="radio" class="ml-2" name="when_to_buy" value="Within 7 days" required> Within 7 days <br>
                            <input type="radio" class="ml-2 mt-2" name="when_to_buy" value="Within 15 days" required> Within 15 days <br>
                            <input type="radio" class="ml-2 mt-2" name="when_to_buy" value="Within 1 month" required> Within 1 month <br>
                        </div>

                        <div class="form-group">
                            <label for="message-text" class="col-form-label">Query</label>
                            <textarea name="query" style="width:100%;" required></textarea>
                        </div>

                    </div>

                    <div class="modal-footer">

                        <button type="submit" class="btn btn_main">Submit</button>

                    </div>

                </div>

            </div>

        </form>

    </div>
    
    <!-- non customer-->
    <div class="modal fade" style="margin-top: 150px" id="guestuser" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12 text-right">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span class="text-danger">X</span>
                            </button>
                        </div>
                        <br/><br/><br/><br/>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-12 text-center">
                            <p style="font-size: 30px;" class="text-danger text-center">
                                Please Sign Up to<br>
                                send booking request
                            </p>
                        </div>
                    </div>

                    <div class="row">
                        <br/><br/><br/>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="OwnerModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">

        <div class="modal-dialog" role="document">

            <div class="modal-content">

                <div class="modal-header">

                    <h5 class="modal-title" id="exampleModalLabel">Contact Showroom Owner</h5>

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">

                    <span aria-hidden="true">&times;</span>

                    </button>

                </div>

                <div class="modal-body">

                    <div class="row">

                        <div class="form-group col-md-12 showroom-owner">

                            <table class="table" border="0" style="width:100%;">

                                <tr>

                                    <td class="td-sm"> Showroom</td>

                                    <td> <?php echo $vendor->company_name;?></td>

                                </tr>

                                <tr>

                                    <td class="td-sm">Email</td>

                                    <td> <?php echo $vendor->email;?></td>

                                </tr>

                                <tr>

                                    <td class="td-sm">Contact</td>

                                    <td> <?php echo $vendor->mobile;?></td>

                                </tr>

                                <tr>

                                    <td class="td-sm">City</td>

                                    <td> <?php echo $vendor_city->city;?></td>

                                </tr>

                            </table>

                        </div>

                    </div>
c
                </div>

            </div>

        </div>

    </div>

    <div class="modal fade" id="ShareModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">

        <div class="modal-dialog" role="document">

            <div class="modal-content">

                <div class="modal-header">

                    <h5 class="modal-title" id="exampleModalLabel">Contact Showroom Owner</h5>

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">

                    <span aria-hidden="true">&times;</span>

                    </button>

                </div>

                <div class="modal-body">

                    <div class="row">

                        <div class="form-group col-md-12">

                            <i class="fa fa-facebook fa-3x"></i>

                            <i class="fa fa-whatsapp fa-3x"></i>

                            <i class="fa fa-instagram fa-3x" aria-hidden="true"></i>

                            <i class="fa fa-twitter fa-3x" aria-hidden="true"></i>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

</section>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script src="<?php echo base_url('css/owlcarousel/owl.carousel.min.js');?>"></script>


<script type="text/javascript">
    
    function submit_ratings(){
        var review = $('#review').val();
        var selected_rate = $('input[name="rate"]:checked').val();

        $.ajax({
              url:'<?=site_url("front/submit_rating")?>',
              method:"POST",
              data:{
                vendor_id:<?=$vendor->id?>,
                prod_id:<?=$product->id?>,
                review:review,
                rate:selected_rate
              },
              async: false,
              success:function(data)
              {
                let jsonObj = JSON.parse(data);
                console.log(jsonObj);
                $('#review_result').addClass('text-success');
                $('#review_result').text(jsonObj.message);

                // Clear the form
                $('#review').val('');
                // $('select').find('option').prop("selected", false);
                $('input[name="rate"]').prop("checked", false);

                location.reload(true);
              }

          });   
    }
    
    
    function mark_as_favorite(){
        // var status = 1

        $.ajax({
              url:'<?=site_url("front/mark_as_favorite")?>',
              method:"POST",
              data:{
                user_id:<?=$this->session->userdata('admin_id')?>,
                product_id:<?=$product->id?>,
              },
              async: false,
              success:function(data)
              {
                  console.log(data)

                location.reload(true);
              }

          });   
    }
</script>

<script>
    function BookRequestReject(){
        $('#guestuser').modal('show');
    }
    function BookRequest(){

     $('#CustomerModal').modal('show');

    }    

      $('.owl-product-deta').owlCarousel({

        loop:true,

        margin:1,

        navText: ["<img src='<?php echo base_url('images/left-aro-b.png');?>' alt='left_arrow'>","<img src='<?php echo base_url('images/right-aro-b.png');?>' alt='right_arrow'>"],

        autoplay:true,

            autoplayTimeout:16000,

            autoplayHoverPause:true,

        responsiveClass:true,

        responsive:{

          0:{

            items:1,

            nav:true

          },

          600:{

            items:1,

            nav:true

          },

          1000:{

            items:1,

            nav:true,

            loop:true

          }

        }

      })

      

    function ShowOwner(){
        $('#OwnerModal').modal('show');
    } 

    setTimeout(function(){ $('.alert').css('display','none'); }, 8000);

    function TwitterShare(){
        window.open('https://twitter.com/intent/tweet?url=<?php echo $product->description;?>');
    }




    function open_otp(){

        var product_id = <?=$product->id?>;
        // console.log('Product id : '+product_id);

        $('#otp_form').css('display', 'block');


        $.ajax({
              url:'<?=site_url("front/send_otp/")?>'+product_id,
              method:"GET",
              async: false,
              success:function(data)
              {
                console.log(data);
              }
          });
    }


    function check_otp(){

        var product_id = $('#otp_product_id').val();
        var entered_otp = $('#otp_data').val();
        
        $.ajax({
              url:'<?=site_url("front/check_otp/")?>'+product_id+'/'+entered_otp,
              method:"GET",
              async: false,
              success:function(data)
              {
                let jsonObj = JSON.parse(data);
                console.log(data);

                if(jsonObj.r == 1){
                    $('#show_error').attr('class', jsonObj.result);
                    $('#show_error').html(jsonObj.message);
                    // window.location.href = "vendor/profile";
                    window.location.href = "<?=base_url('vendor/profile')?>";
                }
                else{
                    $('#show_error').attr('class', jsonObj.result);
                    $('#show_error').html(jsonObj.message);
                }

              }

          });

    }

</script>

<style>

    .short-desc {

    font-size: 15px;

    color: #404040;

    margin-top: 30px;

    font-family: 'Outfit',Sans-Serif;

    font-weight: 400;

    }

    .feturs ul li p {

    margin-bottom: 0;

    font-size: 16px;

    color: #404040;

    font-family: 'Outfit',Sans-Serif;

    font-weight: 400;

    }

    .skut-img-box2 {

    background-color: #a3a3a3;

    padding: 0px 0px;

    border-radius: 10px;

    }

    .skut-img-box2 {

    background-color: #ededed;

    padding: 0px 0px;

    border-radius: 10px;

    }

    .btn-description {

    background-color: #ededed;

    border-radius: 20px;

    padding: 5px 30px;

    font-size: 16px;

    color: #404040;

    }

    .review-form p {

    font-size: 14px;

    color: #565455;

    font-family: 'Outfit',Sans-Serif;

    margin-top: 30px;

    }

    .back-search {

    color: #4ba86e;

    font-size: 12px;

    }

    .skut-img-box {

    background-color: #ededed;

    padding: 0px 0pxpx;

    border-radius: 10px;

    overflow: hidden;

    }

    .skt-slid-box img{

    border-radius: 10px;

    overflow: hidden;

    }

    .image-brand-sec {

    padding: 0px;

    background: #ededed;

    border-radius: 10px;

    overflow: hidden;

    }

    .btn-primary {

    color: #fff;

    background-color: #00a76d;

    border-color: #00a76d; 

    font-family: 'Outfit',Sans-Serif;

    font-size: 22px;

    width: 130px;

    }

    .btn-blu-2:hover {

    color: #fff;

    background-color: #00a76d;

    border: 0px solid #00a76d;

    }

    .fa-2x {

    font-size: 1.6em;

    }

</style>
<style>
    .rate {
    float: left;
    height: 46px;
    padding: 0 10px;
}
.rate:not(:checked) > input {
    position:absolute;
    /*top:-9999px;*/
    display: none;
}
.rate:not(:checked) > label {
    float:right;
    width:1em;
    overflow:hidden;
    white-space:nowrap;
    cursor:pointer;
    font-size:27px;
    color:#ccc;
}
.rate:not(:checked) > label:before {
    content: '★ ';
}
.rate > input:checked ~ label {
    color: #ffc700;    
}
.rate:not(:checked) > label:hover,
.rate:not(:checked) > label:hover ~ label {
    color: #deb217;  
}
.rate > input:checked + label:hover,
.rate > input:checked + label:hover ~ label,
.rate > input:checked ~ label:hover,
.rate > input:checked ~ label:hover ~ label,
.rate > label:hover ~ input:checked ~ label {
    color: #c59b08;
}
</style>