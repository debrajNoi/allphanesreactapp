    <style type="text/css">
        .common-green-color{
            background-color: #00a76d;
            color: #ffffff;
        }
        .common-green-color-text{
            color: #00a76d;
        }
        /*.custom-control-input:checked ~ .custom-control-label::before{
            background-color: #00a76d !important;
            border: #00a76d !important;
        }*/
        .custom-control-label::before{
            background-color: green !important;
        }
        .custom-switch .custom-control-label::after{
            background-color: white !important;
        }

        .card-des{
            /*background-color: #01A86D;*/
            /*color: #01A86D;*/
        }
        .p-icon{
            /*background-color: #01A86D;*/
            /*color: #01A86D;*/
        }
        .fa-check{
            background-color: #01A86D;
            /*color: #01A86D;*/
        }
        .p-icon{
            background-color: #01a86d !important;
        }
        .visibility-box{
            background-color: #eacc1a;
            border: 0px !important;
        }
        .btn-view-demo {
            color: #000;
            font-size: 20px;
            padding: 8px 25px;
            background-color: #00a66d;
            border: 1px solid #00a66d;
            border-radius: 25px;
            font-family: 'Outfit', Sans-Serif;
            text-align: center;
            min-width: 180px;
        }
    </style>

    <link rel="stylesheet" type="text/css" href="<?=base_url('/css/new_pricing.css');?>" />

    <!-- <pre><?php //print_r($free); print_r($featured); print_r($hot); ?></pre> -->

    <!-- pricing section  -->
    <section id="pricing">
        <div class="p-content">
            <!-- <h1 class="text-center cl-2">logo</h1> -->
            <img src="<?=base_url('/assets/img/pricing/top-person.jpg')?>" alt="logo" width="15%" >
        </div>
        <div class="container mt-2">
            <div class="row justify-content-center">
                <div class="col-lg-12">
                    <h3 class="text-center common-green-color-text cl-2 mt-3">
                        We're building the biggest EV Marketplace Community in India
                    </h3>
                    <h1 class="text-center mt-4">Ready to start with EV Dreamz?</h1>
                    <p style="text-align:center;color: #0009;font-size: 20px; margin-top: 15px;">Choose the package that suits you</p>
                    <p style="text-align:center; color: #fb4949 !important;font-size: 26px; font-weight: 600; margin-top: 25px;">
                        50% OFF Introductory Offer valid till March 15, 2022<br/>
                        List your products with Premium Plans today to enjoy today’s price forever
                    </p>
                </div>
                
                <div class="billing-div my-4">
                    <div class="d-flex">
                        <div class="kk text-right cl-3 mr-2">Monthly</div>
                        <div class="switch kk">
                            <!-- <div class="sw-wid bg-2">
                                <div class="sw-btn"></div>
                            </div> -->
                            <div class="custom-control custom-switch">
                              <input type="checkbox" class="custom-control-input" id="customSwitch1" checked>
                              <label class="custom-control-label" for="customSwitch1"></label>
                            </div>
                        </div>
                        <div class="cl-3 d-flex kk">
                            Yearly
                            <div class="yell"> 20% Discount</div>
                        </div>
                    </div>
                    
                </div>
                <!-- <div class="col-lg-12 justify-content-center">
                    <div class="d-flex">
                        <div>Monthly Billing</div>
                        <div class="switch mx-4">
                            <div class="sw-wid">
                                <div class="sw-btn"></div>
                            </div>
                        </div>
                        <div class="cl-3">Yearly</div>
                    </div>
                    <div class="yell"> 20% Discount</div>
                </div> -->
            </div>


            <!-- cards  -->
            <div class="row">
                <?php
                //print_r($pricing);die;
                foreach($pricing as $price){
                    //print_r($price);
                ?>
                
                <div class="col-lg-4 col-md-6 mt-2">
                    <div class="cardx">
                        <div class="card-head">
                            <div class="card-title">
                                
                                <h3><?=$price->title?></h3>
                                
                                <p class="cl-3"><?=$price->short_desc?></p>
                            </div>
                        </div>
                        <div class="card-bod">

                            <?=html_entity_decode(base64_decode($price->long_desc))?>

                        </div>
                        <div class="c-foot">
                            <!-- <h3 class="card-price cl-b">Free</h3> -->
                            <h3 class="card-price cl-b" id="free_amount">
                                <?=($price->amount == 0?"":"INR ")?>
                                <label id="price<?=$price->id?>"><?=($price->amount == 0?"Free":($price->amount * 0.8))?></label>
                                <?=($price->amount == 0?"":"/month")?>
                            </h3>
                            <!-- <button class="btn btn-success mt-3 mb-4">Add Plan</button> -->

                            <div class="form-group">
                                <?php if($price->id > 1){ ?>
                                <button type="button" class="btn common-green-color btn_main mt-3" id="reg_rzp_button-<?=$price->id?>" onclick="reg_razorpaySubmit(this);">Create Listing</button>
                                <?php }else{ ?>
                                <button type="button" class="btn common-green-color btn_main mt-3" id="reg_rzp_button-<?=$price->id?>" onclick="reg_razorpayFreeSubmit(<?=$price->id?>, <?=$this->session->userdata('product_id')?>);">Create Listing</button>
                                <?php } ?>
                            </div>

                        </div>
                    </div>
                </div>
                <?php } ?>


                <?php
                    $reg_description        = "Plan Amount";
                    $reg_txnid              = date("YmdHis");
                    $reg_key_id             = "rzp_live_eK02ucWsWY4MQO"; // LIVE
                    // $reg_key_id             = "rzp_test_paDUpSny9sdjU3"; // TEST
                    $reg_currency_code      = $currency_code;            
                    $reg_total              = (1 * 100); // 100 = 1 indian rupees 1250
                    $reg_amount             = 1;
                    $reg_merchant_order_id  = "EVD-".date("YmdHis");
                    $reg_name               = "EVdreamz";
                ?>

                <form name="reg_razorpay-form" id="reg_razorpay-form" method="POST" action="<?=$callback_url;?>">
                    <input type="hidden" name="reg_razorpay_payment_id" id="reg_razorpay_payment_id" />
                    <input type="hidden" name="plan_id" id="plan_id" value="" />
                    <input type="hidden" name="product_id" id="product_id" value="<?=($this->session->userdata('product_id') != ''?$this->session->userdata('product_id'):'')?>" />
                    <input type="hidden" name="reg_merchant_order_id" id="reg_merchant_order_id" value="<?php echo $reg_merchant_order_id; ?>"/>
                    <input type="hidden" name="reg_merchant_trans_id" id="reg_merchant_trans_id" value="<?php echo $reg_txnid; ?>"/>
                    <input type="hidden" name="reg_merchant_product_info_id" id="reg_merchant_product_info_id" value=""/>
                    <input type="hidden" name="reg_merchant_surl_id" id="reg_merchant_surl_id" value="<?php echo $surl; ?>"/>
                    <input type="hidden" name="reg_merchant_furl_id" id="reg_merchant_furl_id" value="<?php echo $furl; ?>"/>
                    <input type="hidden" name="reg_card_holder_name_id" id="reg_card_holder_name_id" value=""/>
                    <input type="hidden" name="reg_card_holder_email" id="reg_card_holder_email" value=""/>
                    <input type="hidden" name="reg_card_holder_phone" id="reg_card_holder_phone" value=""/>
                    <input type="hidden" name="reg_merchant_total" id="reg_merchant_total" value="<?php echo $reg_total; ?>"/>
                    <input type="hidden" name="reg_merchant_amount" id="reg_merchant_amount" value="<?php echo $reg_amount; ?>"/>
                </form>

                
            </div>
            <div class="row mt-5 bor-1"> 
                <div class="col-lg-3 cl-2 item-center">
                    <!-- <i class="fas fa-check-circle"></i> -->
                    <img src="<?=base_url('/assets/img/pricing/check.png')?>" width="60px" />
                </div>
                <div class="col-lg-8 last-con">
                    <h4 class="cl-2 common-green-color-text">Verify all products. Get more sales</h4>
                    <h6 class="mt-3">INR 750/Product <span class="fs-s">(One time) (For upto 5 products)</span></h6>
                    <h6 class="mt-3">INR 650/Product <span class="fs-s">(One time) (For 5+ products)</span></h6>
                    <p>Login to your account. Click on Manage Products > Product List to verify products</p>
                </div>
                <div class="col-lg-12">
                    <div class="spacer"></div>
                </div>
                <div class="col-lg-3 cl-2 item-center">
                    <!-- <i class="fas fa-filter"></i> -->
                    <img src="<?=base_url('/assets/img/pricing/filter.jpg')?>" width="60px" />
                </div>
                <div class="col-lg-8 last-con">
                    <h4 class="cl-2 common-green-color-text">Get Verified Leads. Pay for the leads you accept</h4>
                    <h6 class="mt-3">INR 500/accepted lead</h6>
                    <p>You will be invoiced on 7th, 14th, 21st and 28th of every month for your accepted leads</p>
                </div>
            </div>


            <!-- Part for sakib started -->
            <div class="row mt-5 p-5 bor-1 visibility-box"> 
                <div class="col-lg-10 offset-md-1 text-center mb-3">
                    <h4 class="bg-white col-md-10 offset-md-1 pt-2 pb-2" style="border-radius: 5px; font-weight: 400;">
                        Get more visibility, more leads, more customers, more sales
                    </h4>
                </div>
                <div class="col-lg-12 text-center">
                    <h3 class="">
                        Get your own E-commerce website with us 
                    </h3>
                    <h3 class="">
                        @ Only INR 3000/month
                    </h3>
                </div>
                <div class="col-lg-12 text-center">
                    <!--<p class="mt-3 mb-0" style="font-size: 20px;">Your website URL: www.evdreamz.com/yourcompanyname</p>-->
                    <!--<p class="mt-0">For custom domain name please contact us.</p>-->
                </div>
                   
                <div class="col-lg-9  mt-3 offset-md-1 row">
                  <div class="col-md-5 mt-3 pl-5 text-right">
                    <a class="btn btn-view-demo btn_main_alt" href="<?php echo $website_demo; ?>">View demo</a>
                  </div>
                  <div class="col-md-7 mt-3 text-left">
                    <!-- <a class="btn btn-green btn_main" href="#<?php //echo $website; ?>">Get my website</a> -->
                    <a class="btn btn-green btn_main" href="#<?php //echo $website; ?>">Start your 1 month Free Trial</a>
                  </div>
                </div>
                    
                <!-- <div class="col-lg-12 mt-4 text-center">
                    <p class="mt-3 mb-0" style="font-size: 20px;">Start your 1 month Free Trial today</p>
                </div>
                    
                <div class="col-lg-12 mb-4 text-center">
                  <div class="col-md-12 mt-3 pl-4 text-center">
                    <a class="btn btn-view-demo btn_main_alt" href="<?php echo base_url('admin'); //$website_demo; ?>">Start Free Trial</a>
                  </div>
                </div> -->
                  
                <!-- <div class="col-lg-12 d-flex text-center">
                    <div class="col-md-5 text-right">
                        <a href="#" class="btn btn-white bg-white text-danger" style="border-radius: 30px; width: 200px;">View demo</a>
                    </div>
                    <div class="col-md-7 text-left">
                        <a href="#" class="btn btn-danger text-white pl-5 pr-5" style="border-radius: 30px; width: 400px;">Get my website</a>
                    </div>
                </div> -->
            </div>
            <!-- Part for sakib ended -->
        </div>
        
    </section>
    <!-- end pricing section  -->



    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <!--<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"-->
    <!--    integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous">-->
    <!--</script>-->
    <script>
    $('#customSwitch1').click(function(){
        if($('#customSwitch1').is(":checked")){
            console.log('cccc');
            var price2=$('#price2').html();
            price2=price2*.8;
            $('#price2').html(price2);
            var price3=$('#price3').html();
            price3=price3*.8;
            $('#price3').html(price3);
        }else{
            console.log('uncccc');
            var price2=$('#price2').html();
            price2=(price2*100)/80;
            $('#price2').html(price2);
            var price3=$('#price3').html();
            price3=(price3*100)/80;
            $('#price3').html(price3);
        }
    });
        
    </script>
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    

    <script type="text/javascript">


        var options2 = {
          key:            "<?php echo $reg_key_id; ?>",
          amount:         "<?php echo $reg_total; ?>",
          name:           $('#reg_card_holder_name_id').val(),
          description:    "Order # <?php echo $reg_merchant_order_id; ?>",
          netbanking:     true,
          currency:       "<?php echo $currency_code; ?>", // INR
          prefill: {
              name:       $('#reg_card_holder_name_id').val(),
              email:      $('#reg_card_holder_email').val(),
              contact:    $('#reg_card_holder_phone').val()
          },
          notes: {
              soolegal_order_id: "<?php echo $reg_merchant_order_id; ?>",
          },
          handler: function (transaction) {
              //console.log(transaction);
              document.getElementById('reg_razorpay_payment_id').value = transaction.razorpay_payment_id;
              document.getElementById('reg_razorpay-form').submit();
          },
          "modal": {
              "ondismiss": function(){
                  // location.reload()
              }
          }
        }; 


        // This function is for payment of 1250rs.
        var razorpay_pay_btn2, instance2;
        function reg_razorpaySubmit(el) {
            
            var type = "<?=$this->session->userdata('user_type')?>";
            console.log('type : '+type);

            if(type != 'Vendor'){
                // alert("Please Sign Up as a vendor to create listings.");
                // $pt = 'style="pointer-events: none;"';
                $('#ShareModal').modal('show');
            }
            else{
                var btn=el.id;
                var plan_selected=btn.split('-')[1];
                console.log(plan_selected);
                var price = $('#price'+plan_selected).html();
                var total_price=0;
                if($('#customSwitch1').is(":checked")){
                    total_price = price*12; 
                }else{
                    total_price = price*1;
                }
                
                $('#reg_merchant_total').val(total_price*100);
                $('#reg_merchant_amount').val(total_price);
                $('#plan_id').val(plan_selected);
                options2.amount = total_price*100;
              // el.preventDefault();
              if(typeof Razorpay == 'undefined') {
                  console.log('nnn');
                  setTimeout(reg_razorpaySubmit, 200);
                  if(!razorpay_pay_btn2 && el) {
                      razorpay_pay_btn2    = el;
                      el.disabled         = true;
                      el.value            = 'Please wait...';  
                  }
              } else {
                  if(!instance2) {
                      instance2 = new Razorpay(options2);
                      if(razorpay_pay_btn2) {
                          razorpay_pay_btn2.disabled   = false;
                          razorpay_pay_btn2.value      = "Pay Now";
                      }
                  }else{
                      instance2 = new Razorpay(options2);
                      if(razorpay_pay_btn2) {
                          razorpay_pay_btn2.disabled   = false;
                          razorpay_pay_btn2.value      = "Pay Now";
                      }
                  }
                  instance2.open();
              }
              
            }
        }






        function reg_razorpayFreeSubmit(plan_id, product_id) {
            var type = "<?=$this->session->userdata('user_type')?>";
            console.log('type : '+type);

            if(type != 'Vendor'){
                $('#ShareModal').modal('show');
            }
            else{
                // console.log(plan_id);
                // console.log(product_id);
                $.ajax({
                  url:'<?=site_url("Checkout/free_payment/")?>'+plan_id+'/'+product_id,
                  method:"GET",
                  async: false,
                  success:function(data)
                  {
                    console.log(data);
                  }
    
                });
            }

        }  
    </script>
    
    
    
    
    <div class="modal fade" id="ShareModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12 text-right">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span class="text-danger">X</span>
                            </button>
                        </div>
                        <br/><br/><br/><br/>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-12 text-center">
                            <p style="font-size: 30px;" class="text-danger text-center">Please Sign Up as a vendor to create listings</p>
                        </div>
                    </div>

                    <div class="row">
                        <br/><br/><br/>
                    </div>
                </div>
            </div>
        </div>
    </div>