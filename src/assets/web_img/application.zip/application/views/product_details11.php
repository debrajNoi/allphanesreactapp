<?php
$sql_vendor=$this->db->query('SELECT * FROM users WHERE id="'.$product->vendor_id.'"');
$vendor=$sql_vendor->row();?>

<section class="product-deta">
  <div class="container">
    <div class="row">
      <div class="col-md-7"> 
        <p><a href="javascript:history.go(-1)" class="back-search">Back to search results</a></p>
		
        <div class="owl-product-deta owl-carousel owl-theme">
           <div>
              <div class="skt-slid-box">
                 <div class="skut-img-box2"><img src="<?php echo base_url('uploads/products/'.$product->front_view);?>" alt="" style="height:400px;"></div>
              </div>
           </div>
           <div>
              <div class="skt-slid-box">
                 <div class="skut-img-box2"><img src="<?php echo base_url('uploads/products/'.$product->side_view1);?>" alt="" style="height:400px;"></div>
              </div>
			  
           </div>
		   
		   <div>
              <div class="skt-slid-box">
                 <div class="skut-img-box2"><img src="<?php echo base_url('uploads/products/'.$product->side_view2);?>" alt="" style="height:400px;"></div>
              </div>
			  
           </div>
		   
		   <div>
              <div class="skt-slid-box">
                 <div class="skut-img-box2"><img src="<?php echo base_url('uploads/products/'.$product->rear_view);?>" alt="" style="height:400px;"></div>
              </div>
			  
           </div>
		   
		   <div>
              <div class="skt-slid-box">
                 <div class="skut-img-box2"><img src="<?php echo base_url('uploads/products/'.$product->close_up1);?>" alt="" style="height:400px;"></div>
              </div>
			  
           </div>
		   
		   <div>
              <div class="skt-slid-box">
                 <div class="skut-img-box2"><img src="<?php echo base_url('uploads/products/'.$product->close_up2);?>" alt="" style="height:400px;"></div>
              </div>
			  
           </div>
         </div>
         
         <button class="btn btn-description mt-5">Description</button>
         <p class="short-desc">
          <?php echo $product->description;?>
         </p>
         <button class="btn btn-description mt-5">Specification</button>
         <div class="feturs">
          
           
           <ul>
             <li>
               <table>
                <tr>
                  <td><p><img src="<?php echo base_url('images/brand_name.png');?>" alt=""></p></td>
                  <td><p><?php echo $product->brand;?></p></td>
                </tr>
              </table>
             </li>
            <li>
             <table>
                <tr>
                  <td><p><img src="<?php echo base_url('images/speed.png');?>" alt=""></p></td>
                  <td><p><?php echo $product->top_speed;?></p></td>
                </tr>
              </table>
            </li>
             <li>
               <table>
                <tr>
                  <td><p><img src="<?php echo base_url('images/range.png');?>" alt=""></p></td>
                  <td><p><?php echo $product->product_range;?></p></td>
                </tr>
              </table>
             </li>
             <li>
               <table>
                <tr>
                  <td><p><img src="<?php echo base_url('images/charge.png');?>" alt=""></p></td>
                  <td><p><?php echo $product->charging_time;?></p></td>
                </tr>
              </table>
             </li>
             <li>
               <table>
                <tr>
                  <td><p><img src="<?php echo base_url('images/motor.png');?>" alt=""></p></td>
                  <td><p><?php echo $product->connectivity;?></p></td>
                </tr>
              </table>
             </li>
            <li>
              <table>
                <tr>
                  <td><p><img src="<?php echo base_url('images/Registration.png');?>" alt="" style="width: 25px;"></p></td>
                  <td><p><?php echo $product->registration_required;?></p></td>
                </tr>
              </table>
            </li>
             <li>
             <table>
                <tr>
                  <td><p><img src="<?php echo base_url('images/wheel.png');?>" alt=""></p></td>
                  <td><p><?php echo $product->tyres;?></p></td>
                </tr>
              </table>
             </li>
             <li>
              <table>
                <tr>
                  <td><p><img src="<?php echo base_url('images/battery.png');?>" alt="" style="width: 25px;"></p></td>
                  <td><p><?php echo $product->battery_capacity;?></p></td>
                </tr>
              </table>
             </li>
             <li>
               <table>
                <tr>
                  <td><p><img src="<?php echo base_url('images/year.png');?>" alt="" style="width: 25px;"></p></td>
                  <td><p><?php echo $product->year;?></p></td>
                </tr>
              </table>
             </li>
             <li>
              <table>
                <tr>
                  <td><p><img src="<?php echo base_url('images/model.png');?>" alt=""></p></td>
                  <td><p><?php echo $product->model;?></p></td>
                </tr>
              </table>
             </li>
             <li>
               <table>
                <tr>
                  <td><p><img src="<?php echo base_url('images/socket.png');?>" alt=""></p></td>
                  <td><p><?php echo $product->color;?></p></td>
                </tr>
              </table>
             </li>
             <li>
              <table>
                <tr>
                  <td><p><img src="<?php echo base_url('images/starting.png');?>" alt=""></p></td>
                  <td><p><?php echo $product->starting_type;?></p></td>
                </tr>
              </table>
             </li>
             <li>
              <table>
                <tr>
                  <td><p><img src="<?php echo base_url('images/safety.png');?>" alt=""></p></td>
                  <td><p><?php echo $product->safety_features;?></p></td>
                </tr>
              </table>
             </li>
             <li>
              <table>
                <tr>
                  <td><p><img src="<?php echo base_url('images/sensor.png');?>" alt=""></p></td>
                  <td><p><?php echo $product->display;?></p></td>
                </tr>
              </table>
             </li>
             <li>
               <table>
                <tr>
                  <td><p><img src="<?php echo base_url('images/brake.png');?>" alt=""></p></td>
                  <td><p><?php echo $product->break_type;?></p></td>
                </tr>
              </table>
             </li>
             <li>
               <table>
                <tr>
                  <td><p><img src="<?php echo base_url('images/warranty.png');?>" alt=""></p></td>
                  <td><p><?php echo $product->warranty;?></p></td>
                </tr>
              </table>
             </li>
             <li>
               <table>
                <tr>
                  <td><p><img src="<?php echo base_url('images/location.png');?>" alt=""></p></td>
                  <td><p><?php echo $product->location;?></p></td>
                </tr>
              </table>
             </li>
             <li>
              <table>
                <tr>
                  <td><p><img src="<?php echo base_url('images/pincode.png');?>" alt="" style="height: 28px;width: 20px;"></p></td>
                  <td><p><?php echo $product->pincode;?></p></td>
                </tr>
              </table>
             </li>
             <li>
               <table>
                <tr>
                  <td><p><img src="<?php echo base_url('images/price.png');?>" alt="" style="width: 20px;"></p></td>
                  <td><p><?php echo $product->price;?></p></td>
                </tr>
              </table>
             </li>
           </ul>
         </div>
          <div class=" clearfix"></div>
         <div class="bor-bot-1"></div>
         <form class="review-form">
          
           <p>Every effort has been made to ensure the accuracy of the information above, however, errors may occur. Do not rely entirely on this information but check with the retailer about items which may affect your decision to purchase.</p>
         </form>
      </div>
      <div class="col-md-5"> 
        <div class="details-box">
           <h4><?php echo $product->brand;?></h4>
           <h5><?php echo $product->model;?></h5>
           <h4 class="mb-5">INR <?php echo $product->price;?></h4>

          <!--<p><span><img src="<?php echo base_url('images/met-i.png');?>" alt=""></span> <?php echo $product->product_range;?> Kms</p>
	      <p><span><img src="<?php echo base_url('images/plag-i.png');?>" alt=""></span> <?php echo $product->charging_time;?> Hrs</p>-->
          <p class="showroom"><span><b></span> <?php echo $vendor->company_name;?></b></p>
          <p> <?php echo $vendor->neighborhood;?></p>
        <p><span><img src="<?php echo base_url('images/i-16.png');?>" alt=""></span> <?php echo $vendor->city;?></p>

          <div class="mt-5 mb-5">
		  <?php
		  if( $this->session->flashdata('success')){?>
		      <div class="alert alert-success"><?php echo $this->session->flashdata('success');?></div>
			<?php }?>
			
		<?php
		  if( $this->session->flashdata('error')){?>
		      <div class="alert alert-danger"><?php echo $this->session->flashdata('error');?></div>
			<?php }?>
            <button class="btn btn-blu-2 mb-4" onclick="BookRequest()">Buy/Book Now</button>
			
            <button class="btn btn-blu-2" onclick="ShowOwner()">Contact Showroom Owner </button>
          </div>
          <p class="share-save"> 
          <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo base_url('product-details?id='.$this->input->get('id'))?>" target="_blank"><i class="fa fa-facebook fa-2x" style="color: #4958C5;"></i></a>
		&nbsp;	<a href="https://wa.me/8825276765/?text=<?php echo base_url('product-details?id='.$this->input->get('id'))?>" target="_blank"><i class="fa fa-whatsapp fa-2x" style="color:#4DC85A;"></i></a>
			&nbsp;	<a href="https://www.instagram.com/?url=<?php echo base_url('product-details?id='.$this->input->get('id'))?>" target="_blank"><i  class="fa fa-instagram fa-2x" style="color:#EA476C; aria-hidden="true"></i></a>
			&nbsp;	<a href="https://twitter.com/intent/tweet?url=<?php echo base_url('product-details?id='.$this->input->get('id'))?>" target="_blank"><i  class="fa fa-twitter fa-2x" aria-hidden="true"></i></a>
          </p>
        </div>
        <div class="details-box-green">
          <h5>Buy with trust and transparency</h5>
          <table>
            <tr>
              <td><img src="<?php echo base_url('images/right-i.png');?>" alt=""></td>
              <td style="
    font-weight: 500;">All electric 2 wheelers listed on Evdreamz have been vetted and  are being sold by an approved dealer in India, giving you peace of mind, you are dealing with a certified professional expert retailer.</td>
            </tr>
          </table>
        </div>
      </div>
    </div>
  </div>
  
  
  <div class="modal fade" id="CustomerModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <form method="post" action="<?php echo base_url('User/ProductBooking');?>">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Booking Request</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       
		<div class="row">
          <div class="form-group col-md-6">
            <label for="recipient-name" class="col-form-label">Name:</label>
			<input type="hidden" name="product_id" value="<?php echo $this->input->get('id');?>" />
            <input type="text" class="form-control" name="customer_name" id="customer_name" required>
          </div>
          <div class="form-group col-md-6">
            <label for="message-text" class="col-form-label">Email:</label>
           <input type="email" class="form-control" name="customer_email" name="customer_email" required />
          </div>
		 </div>
		 
		 <div class="row">
		  <div class="form-group col-md-6">
            <label for="message-text" class="col-form-label">Mobile:</label>
           <input type="text" class="form-control" maxlength="10" name="customer_mobile" name="customer_mobile" required />
          </div>
		  
		  <div class="form-group col-md-6">
            <label for="message-text" class="col-form-label">Location:</label>
           <input type="text" class="form-control"  name="customer_location" name="customer_location" required />
          </div>
		  </div>
		  
		  <div class="form-group">
            <label for="message-text" class="col-form-label">Query:</label>
          <textarea name="query" style="width:100%;" required></textarea>
          </div>
        
      </div>
      <div class="modal-footer">
       
        <button type="submit" class="btn btn-primary">Submit</button>
      </div>
    </div>
  </div>
  </form>
</div>
  
  <div class="modal fade" id="OwnerModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
 
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Contact Showroom Owner</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       
		<div class="row">
          <div class="form-group col-md-12">
		  <table class="table" border="0" style="width:100%;">
		  <tr>
		  <td> Showroom</td>   <td> <?php echo $vendor->company_name;?></td>
		  </tr>
		  <tr>
			<td>Email</td><td> <?php echo $vendor->email;?></td>
			</tr>
			<tr>
			<td>Contact</td><td> <a href="tel:<?php echo $vendor->mobile;?>"><?php echo $vendor->mobile;?></a></td>
			</tr>
			<tr>
			<td>City</td><td> <?php echo $vendor_city->city;?></td>
			</tr>
			</table>
			
			
          </div>
          
		 </div>
		 
		 
		  
		  
        
      </div>
      
    </div>
  </div>
  
</div>



<div class="modal fade" id="ShareModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
 
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Contact Showroom Owner</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       
		<div class="row">
          <div class="form-group col-md-12">
		 
			<i class="fa fa-facebook fa-3x"></i>
			<i class="fa fa-whatsapp fa-3x"></i>
			<i class="fa fa-instagram fa-3x" aria-hidden="true"></i>
			<i class="fa fa-twitter fa-3x" aria-hidden="true"></i>
          </div>
          
		 </div>
		 
		 
		  
		  
        
      </div>
      
    </div>
  </div>
  
</div>
</section>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="<?php echo base_url('js/bootstrap.min.js');?>"></script>
<script src="<?php echo base_url('css/owlcarousel/owl.carousel.min.js');?>"></script>
<script>
function BookRequest(){
 $('#CustomerModal').modal('show');
}		 
	$('.owl-product-deta').owlCarousel({
		loop:true,
		margin:1,
		navText: ["<img src='<?php echo base_url('images/left-aro-b.png');?>'>","<img src='<?php echo base_url('images/right-aro-b.png');?>'>"],
		autoplay:true,
        autoplayTimeout:16000,
        autoplayHoverPause:true,
		responsiveClass:true,
		responsive:{
			0:{
				items:1,
				nav:true
			},
			600:{
				items:1,
				nav:true
			},
			1000:{
				items:1,
				nav:true,
				loop:true
			}
		}
	})
	
function ShowOwner(){
 $('#OwnerModal').modal('show');
}	
setTimeout(function(){ $('.alert').css('display','none'); }, 3000);

function TwitterShare(){
  
	
	  window.open('https://twitter.com/intent/tweet?url=<?php echo $product->description;?>');
	

}
</script>

<style>
    .short-desc {
    font-size: 17px;
    color: #404040;
    margin-top: 30px;
    font-family: 'Outfit',Sans-Serif;
    font-weight: 400;
}
.feturs ul li p {
    margin-bottom: 0;
    font-size: 16px;
    color: #404040;
    font-family: 'Outfit',Sans-Serif;
    font-weight: 400;
}
.skut-img-box2 {
    background-color: #a3a3a3;
    padding: 0px 0px;
    border-radius: 10px;
}
.skut-img-box2 {
    background-color: #ededed;
    padding: 0px 0px;
    border-radius: 10px;
}
.btn-blu-2 {
    color: #fff;
    font-size: 16px;
    padding: 8px 15px;
    background-color: #00a76d;
    border: 0px solid #023591;
    border-radius: 25px;
    font-family: 'Outfit', Sans-Serif;
    text-align: center;
    width: 287px;
}
.btn-description {
    background-color: #ededed;
    border-radius: 20px;
    padding: 5px 30px;
    font-size: 16px;
    color: #404040;
}
.review-form p {
    font-size: 14px;
    color: #565455;
    font-family: 'Outfit',Sans-Serif;
    margin-top: 30px;
}
.back-search {
    color: #4ba86e;
    font-size: 12px;
}
.skut-img-box {
    background-color: #ededed;
    padding: 0px 0pxpx;
    border-radius: 10px;
    overflow: hidden;
}
.skt-slid-box img{
   border-radius: 10px;
    overflow: hidden;
}
.image-brand-sec {
    padding: 0px;
    background: #ededed;
    border-radius: 10px;
    overflow: hidden;
}

.btn-primary {
    color: #fff;
    background-color: #00a76d;
    border-color: #00a76d; 
    font-family: 'Outfit',Sans-Serif;
    font-size: 22px;
    width: 130px;
}
.btn-blu-2:hover {
    color: #fff;
    background-color: #00a76d;
    border: 0px solid #00a76d;
}

.fa-2x {
    font-size: 1.6em;
}
</style>



 
