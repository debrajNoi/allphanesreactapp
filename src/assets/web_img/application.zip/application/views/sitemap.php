<?php header('Content-type: text/xml'); ?>
<?= '<?xml version="1.0" encoding="UTF-8" ?>' ?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <url>
        <loc><?php echo 'https://www.evdreamz.com/'; ?></loc>
        <priority>1.0</priority>
        <changefreq>daily</changefreq>
    </url>
    
     <?php foreach($pages as $page) { ?>
    <url>
        <loc><?php echo 'https://www.evdreamz.com/'.$page->page_name; ?></loc>
        <priority>0.5</priority>
        <changefreq>daily</changefreq>
    </url>
    <?php } ?>
    <url>
        <loc><?php echo 'https://www.evdreamz.com/sell'; ?></loc>
        <priority>0.5</priority>
        <changefreq>daily</changefreq>
    </url>
    <url>
        <loc><?php echo 'https://www.evdreamz.com/pricing'; ?></loc>
        <priority>0.5</priority>
        <changefreq>daily</changefreq>
    </url>
    <url>
        <loc><?php echo 'https://www.evdreamz.com/partner-with-us'; ?></loc>
        <priority>0.5</priority>
        <changefreq>daily</changefreq>
    </url>
    <url>
        <loc><?php echo 'https://www.evdreamz.com/vendor/regisration'; ?></loc>
        <priority>0.5</priority>
        <changefreq>daily</changefreq>
    </url>
    <url>
        <loc><?php echo 'https://www.evdreamz.com/vendor/login'; ?></loc>
        <priority>0.5</priority>
        <changefreq>daily</changefreq>
    </url>
    <url>
        <loc><?php echo 'https://www.evdreamz.com/user/regisration'; ?></loc>
        <priority>0.5</priority>
        <changefreq>daily</changefreq>
    </url>
    <url>
        <loc><?php echo 'https://www.evdreamz.com/user/login'; ?></loc>
        <priority>0.5</priority>
        <changefreq>daily</changefreq>
    </url>
    <!-- Sitemap -->
    <?php foreach($users as $user) { ?>
    <url>
        <loc><?php echo 'https://www.evdreamz.com/'.$user->slug; ?></loc>
        <priority>0.5</priority>
        <changefreq>daily</changefreq>
    </url>
    <?php } ?>
    
    <!-- Sitemap -->
    <?php foreach($products as $product) { ?>
    <url>
        <loc><?php echo 'https://www.evdreamz.com/'.'product-details/'.$product->slug; ?></loc>
        <priority>0.5</priority>
        <changefreq>daily</changefreq>
    </url>
    <?php } ?>


</urlset>