<section>
  <div class="registration-sec">
    <div class=" container-fluid">
    <div class="row">
      <div class="col-md-5 p-0"><img src="<?php echo base_url('images/registration-bg.jpg');?>" alt="" class="img-fluid"></div>
      <div class="col-md-5">
       <h1>Email Verification</h1>
       <div class="form-sec">
   
	             <?php
				
				if($this->session->flashdata('success')){?>
				<div class="alert alert-success"><?php echo $this->session->flashdata('success');?></div>
				<?php }?>


  </div>
       </div>
      <div class="col-md-2"></div>
    </div>
  </div>
  <div class="clearfix"></div>
  </div>
</section>
<script>
setTimeout(function(){ $('.alert').fadeOut(); $('#myform').each(function(){ 
    this.reset();
}); }, 3000);
function GetStateList(city_id){
   if(city_id!=''){
     $.get("<?php echo base_url('Front/GetStateByCity');?>",{city_id:city_id},function(data){
	 $('#state').html(data);
	 });
   }
}
</script>