<?php 
    $partner = get_page_section($cms[0]->id, '');
?>
<section class="sell-landi-set-1">

  <div class="container">

    <div class="row">

      <div class="col-md-1"></div>

      <div class="col-md-10 text-center">

        <!--<h3>Partner with us and put your electric scooter business at the forefront of EV adoption </h3>-->
        <h3><?php echo $partner[0]->title;?></h3>

        <!--<img src="<?php echo base_url('images/09.png');?>" alt="" class="part-landi-car">-->
        <img src="<?php echo base_url('uploads/cms/').$partner[0]->image;?>" alt="<?php echo $partner[0]->img_alt;?>" class="part-landi-car">

        <!--<h4 style="font-size: 20px;font-weight: 500;line-height: 30px;">-->
            
        <!--   Inviting electric scooter dealers, and electric scooter owners to partner with us to build the largest EV ecosystem. Soon we will be inviting EV manufacturers, EV charging station operators, EV charger manufacturers and dealers, and EV service centre owners to join us too.-->
        <!--</h4>-->
        <h4 style="font-size: 20px;font-weight: 500;line-height: 30px;">
           <?php echo base64_decode($partner[0]->content);?>
        </h4>
        

      </div>

      <div class="col-md-1"></div>

    </div>

  </div>

</section>





<section class="comingsoon-set-2">

  <div class="container">

    <div class="row">

    <div class="col-md-1"></div>

      <div class="col-md-4 text-center mt-5">
          <img src="<?php echo base_url('uploads/cms/').$partner[1]->image;?>" alt="<?php echo $partner[1]->img_alt;?>" class="img-fluid">

         <!--<img src="<?php echo base_url('images/010.png');?>" alt="" class="img-fluid">-->

      </div>

      <div class="col-md-1"></div>

      <div class="col-md-6">

         <!--<h4 class="hed-text-b">Why partner with us?</h4>-->

<!--         <p class="hed-text-paragrap">We are building an EV ecosystem that will boost EV adoption in our country significantly. Our goal is to make the transition to EV a smooth and easy one, by creating a platform that connects everyone to the same mission.<br><br>-->



<!--By partnering with us, you are going to be in front of the largest community of the most active EV adopters. People who are most likely to be your biggest customers.-->
<!--</p>-->
        <h4 class="hed-text-b"><?php echo $partner[1]->title;?></h4>
        <p class="hed-text-paragrap">
            <?php echo base64_decode($partner[1]->content);?>
        </p>

      </div>

    </div>

  </div>

</section>



<section class="partner-set-1">

  <div class="container">

    <div class="row">

      <div class="col-md-1"></div>

      <div class="col-md-10 text-center">

        <!--<h4>Let us start something promising together</h4>-->
        <h4><?php echo $partner[2]->title;?></h4>

        <br>

        <div class="row">

          <div class="col-md-6 mt-3 text-center">

            <!--<button class="btn btn-green"><a href="<?php //echo base_url('vendor/regisration');?>">I am an EV Dealer</button></a>-->

            <a class="btn btn-green btn_main" href="<?php echo base_url('vendor/regisration');?>">I am an EV Dealer</a>

          </div>

          <div class="col-md-6 mt-3 text-center">

            <!--<button class="btn btn-green"><a href="<?php //echo base_url('sell');?>">I am a Used EV seller</button></a>-->

            <a class="btn btn-green btn_main" href="<?php echo base_url('sell');?>">I am a Used EV seller</a>

          </div>

        </div>

       

      </div>

      <div class="col-md-1"></div>

    </div>

  </div>

</section>

<style>



a {

    color: #ffffff;

    text-decoration: none;

    background-color: transparent;

    font-family: 'Outfit', Sans-Serif;

}



a:hover {

    color: #ffffff;

}





</style>

