

<section class="home-banner">

<?php 
    $home = get_page_section($cms[0]->id, '');
?>
  <div class="container">

    <div class="row">

      <div class="col-md-7"> 

        <!--<h4>Buy your dream electric <br/>2 wheeler from the widest range of showrooms</h4>-->
        <h4><?php echo base64_decode($home[0]->content);?></h4>
        
        

        <div class="bann-btn">

          <!--<button class="btn btn-yelo">Brand New 2 Wheeler</button> &nbsp;  &nbsp;  &nbsp; 

          <button class="btn btn-whit-border">Used 2 Wheeler</button>-->

          <form class="banner-form" method="get" action="<?php echo base_url('products');?>">

		  

             <div class="form-box" style="height: 430px;">

                <div class="form-group foor-arrow">

                    <select class="form-control bor-b-1"  id="vehicle_type" name="vehicle_type" >

                      <option value="">Select 2 Wheeler Category</option>

                      <option value="New">Brand New 2 Wheeler</option>

                      <option value="Used">Used 2 Wheeler</option>

                    </select>

                    <!--<div class="select-side">

                     <i class="fa fa-angle-down"></i>

                    </div>-->

                </div>

               <div class="form-group foor-arrow">

                    <select class="form-control bor-b-1" id="budget" name="budget" >

                      <option value="Select Budget">Select Budget</option>

                      <option value="70000">Under  70000</option>

        					    <option value="100000">Under  100000</option>

        					    <option value="150000">Under  150000</option>

                     

                    </select>

                    <!--<div class="select-side">

                     <i class="fa fa-angle-down"></i>

                    </div>-->

                </div>

                <div class="form-group foor-arrow">

                    <select class="form-control bor-b-1" id="brand" name="brand" >

                      <option value="">Select Brand</option>

					  <?php foreach($brands as $brnd){?>

                      <option value="<?php echo $brnd->brand;?>"><?php echo $brnd->brand;?></option>

					  <?php }?>

                      

                    </select>

                    <!--<div class="select-side">

                     <i class="fa fa-angle-down"></i>

                    </div>-->

                </div>

                <div class="form-group foor-arrow">

                    <select class="form-control bor-b-1" id="location" name="location" >

                      <option value="">Select City</option>

					  <?php

					  foreach($clty_list as $city){?>

                      <option value="<?php echo $city->location;?>"><?php echo $city->location;?></option>

					  <?php }?>

                    

                    </select>

                    <!--<div class="select-side">

                     <i class="fa fa-angle-down"></i>

                    </div>-->

                 </div>

                 <div class="form-group foor-arrow">

                    <input type="text" max-length="6" class="form-control" id="pincode" name="pincode" placeholder="Enter Pin Code">

                  </div>
                  
                  <button class="btn btn-blu my-4 ml-3 btn_main">Let's go</button>

             </div>

             <!--<button class="btn btn-blu mt-5">Buy Now</button>-->

          </form>

        </div>

      </div>

      <div class="col-md-5"> 

        <img src="<?php echo base_url('uploads/cms/').$home[0]->image;?>" alt="<?php echo $home[0]->img_alt;?>" class="img-fluid bann-img">

      </div>

    </div>

  </div>

</section>

<?php

if(!empty($banner_list)){?>

<section class="scrt-slider" style="background-color:#e6e8ee;">

  <div class="container-fluid brand-sec">

    <div class="row justify-content-center">

      <div class="col-md-11 col-12 text-center" style="font-size: 21px;padding-bottom:90px;">

        <!--<p style="font-size: 21px; margin-top: 20px;">-->
        <!--EV Dreamz is India's 1st marketplace for buying and selling electric scooters in India. Find, and contact the best electric scooter dealers with just a few clicks. Search for “Electric scooter under 1 lakh” or 1.5 lakh or “Electric bike in India under 1 lakh” and so on. You can also search by your preferred brand, city, and even Pincode. EV Dreamz is the most convenient way to buy and sell electric 2 wheelers in India.</p>-->
        <!--<p style="font-size: 21px;">And we have plans to create the biggest Indian EV ecosystem.</p>-->
        <p style="font-size: 52px; margin-top: 20px;">
        <?php echo base64_decode($home[1]->content);?>
        </p>
      </div>
    
    </div>
  </div>
</section>

<section class="scrt-slider">

  <div class="container-fluid brand-sec">

    <div class="row mt-4">

      <div class="col-md-12 text-center mt-5">

        <h4>Hot & Happening showrooms</h4>
        <?php //echo base64_decode($home[2]->content);?>

      </div>

      

      <div class="col-md-12">

         <div class="owl-showrom owl-carousel owl-theme">

		 <?php

		 foreach($banner_list as $banner){

		   if($banner->front_view!=''){

		 ?>

           <div>

              <div class="skt-slid-box">

                 <div class="skut-img-box pro_img_box_lg"><img src="<?php echo base_url('uploads/products/'.$banner->front_view);?>" alt="<?php echo $banner->slug;?>"></div>

                 <table class="cont-table">

                   <tr>

                     <td>

                       <p class="pe-taxt-1"><?php echo $banner->company_name;?> &nbsp;| &nbsp;INR <?php echo $banner->price;?> &nbsp;|&nbsp; <span><?php echo $banner->location;?></span></p>

                     </td>

                     <td><a href="<?php echo base_url('product-details/'.$banner->slug)?>"><button class="btn btn-view-more">View More</button></a></td>

                   </tr>

                 </table>

                 

              </div>

           </div>

		   

		   <?php } }?>

           <div>

              

           </div>

           

           

         </div>

      </div>

      <div class="col-md-12 mt-5"><div class="border"></div></div>

    </div>

  </div>

</section>



<?php }

if(!empty($fearured_list)){?>

<section class="scrt-slider">

  <div class="container-fluid brand-sec ">

      <div class="col-md-12 text-center">

        <h4>Featured Premium showrooms</h4>
       
        
        

      </div>

    <div class="row items">

      

      

       

	  <?php

	  foreach($fearured_list as $featured){?>

     	 <div class="col-lg-4 col-md-6 mb-3 item">

              <div class="skt-slid-box">

                 <div class="skut-img-box pro_img_box"><img src="<?php echo base_url('uploads/products/'.$featured->front_view);?>" alt="<?php echo $featured->slug;?>" class="img-fluid img-thumbnail"></div>

                <table class="cont-table2">

                   <tr>
                         <td>
                           <!--<p class="pe-taxt-2-b"><span><?php echo $featured->brand;?></span> &nbsp; | &nbsp; <span>INR <?php echo $featured->price;?></span> &nbsp; | &nbsp; <span><?php echo $banner->location;?></span></p>-->
                            <p class="pe-taxt-2-b">
                                <span><?php echo $featured->company_name;?></span> &nbsp; | &nbsp; 
                                <span><?php echo $featured->location;?></span>
                            </p>
                         </td>
                         <td><a href="<?php echo base_url('product-details/'.$featured->slug)?>"><button class="btn btn-view-more">View More</button></a></td>
                   </tr>
                   <!--<tr>-->
                   <!--     <td>-->
                   <!--         <a href="<?php echo base_url('product-details/'.$featured->slug); ?>" style="color: #fb4949; padding-left: 10px">-->
                   <!--            View More-->
                   <!--         </a>-->
                   <!--     </td>-->
                   <!--</tr>-->

                </table>

                 

              </div>

      </div>

	   <?php }?>

      

    

       

      

      

      <div class="col-md-12 text-center mt-5">

          <button class="btn btn-view-more-gray showMore buttonToogle"><a href="javascript:;" class="showMore text-primary">View More</button></a></div>

      <div class="col-md-12 mt-5"><div class="border"></div></div>

    </div>

  </div>

</section>





<?php }

if(!empty($popular_list)){?>

<section class="scrt-slider">

  <div class="container-fluid brand-sec">

      <div class="col-md-12 text-center">

        <h4>Popular showrooms</h4>
        <?php //echo base64_decode($home[4]->content);?>

      </div>

    <div class="row populars">

      

	  <?php

	  foreach($popular_list as $popular){?>

     	 <div class="col-lg-3 col-md-4 col-md-3 col-sm-6 col-xs-12 mb-5 popular">

        <div class="full-sec-brand">

          <div class="image-brand-sec"> <img src="<?php echo base_url('uploads/products/'.$popular->front_view);?>" alt="<?php echo $popular->slug;?>"></div>

        </div>

       <table class="cont-table2">

                   <tr>

                     <td>

                       <p class="pe-taxt-2-c" style="font-size: 14px;"><span><?php echo $popular->company_name;?></span> &nbsp; | &nbsp; <span><?php echo $popular->location;?></span> &nbsp;</p>



                     </td>

                     

                   </tr>
                   <tr>
                       <td><a href="<?php echo base_url('product-details/'.$popular->slug); ?>"><button class="btn btn-view-more2">View More</button></a></td>
                   </tr>

                 </table>

      </div>

	  

	  <?php }?>

      

      

     

      

      

      <!--<a href="" class="load">Load More</a>-->

      <div class="col-md-12 text-center mt-5">  <button class="btn btn-view-more-gray showMore1 buttonToogle1"><a href="javascript:;" class="showMore1 text-primary">View More</button></a</div>

  </div>

  </div>

</section>

<?php }?>

<section class="partner-sty01 mt-5">

  <div class="container">

  <div class="row">

  <div class="col-md-12 text-center">
      <?php echo base64_decode($home[2]->content);?>

<!--    <p>Join the Green Transportation Global Movement.<br>-->

<!--Buy and encourage others to buy EV.  </p>-->

   </div>

  </div>

  </div>

</section>

<section class="partner-sty02">

  <div class="container">

      <div class="row justify-content-center">
    
            <div class="col-12 text-center">
                <?php echo base64_decode($home[3]->content);?>
                <!--<h4>Partner with us</h4>-->
                <!--<p>Put your business at the forefront of EV adoption</p>-->
           </div>
           <div class="col-12 text-center">
                <a class="btn btn-blu btn_main" href="<?php echo base_url('partner-with-us');?>">Know more</a>
           </div>
    
      </div>

  </div>

</section>



<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>



<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>

<script src="<?php echo base_url('css/owlcarousel/owl.carousel.min.js');?>"></script>

<!--<script src="<?php echo base_url('js/bootstrap.min.js');?>"></script>-->



<script>



	  $('.owl-showrom').owlCarousel({

		loop:true,

		margin:40,

		navText: ["<img src='images/left-aro.png' alt='home'>","<img src='images/right-aro.png' alt='home'>"],

		autoplay:true,

        autoplayTimeout:16000,

        autoplayHoverPause:true,

		responsiveClass:true,

		responsive:{

			0:{

				items:1,

				nav:true

			},

			600:{

				items:2,

				nav:true

			},

			1000:{

				items:2,

				nav:true,

				loop:true

			}

		}

	});



</script>



<style>

.mb-3, .my-3 {

    margin-bottom: 2rem!important;

}

.mb-5, .my-5 {

    margin-bottom: 1rem!important;

}

.btn.focus, .btn:focus {

    outline: 0;

    box-shadow: 0 0 0 0rem rgb(0 123 255 / 25%);

}





 



       

</style>



<script >

  $(function() {



  // items to show

  var increment = 6;



  var startFilter = 0;

  var endFilter = increment;



  // item selector

  var $this = $('.items');



  var elementLength = $this.find('div').length;

  $('.listLength').text(elementLength);



  // show/hide the Load More button

  if (elementLength > 2) {

    $('.buttonToogle').show();

  }



  $('.items .item').slice(startFilter, endFilter).addClass('shown');

  $('.shownLength').text(endFilter);

  $('.items .item').not('.shown').hide();

  $('.buttonToogle .showMore').on('click', function() {

      

    if (elementLength > endFilter) {

      startFilter += 3;

      endFilter += 3;

      $('.items .item').slice(startFilter, endFilter).not('.shown').addClass('shown').toggle(500);

      $('.shownLength').text((endFilter > elementLength) ? elementLength : endFilter);

      if (elementLength <= endFilter) {

          //$(this).remove();

      }

    }

  });



});

</script> 





<script >

  $(function() {



  // items to show

  var increment1 = 8;



  var startFilter1 = 0;

  var endFilter1 = increment1;



  // item selector

  var $this = $('.populars');



  var elementLength1 = $this.find('div').length;

  $('.listLength').text(elementLength1);



  // show/hide the Load More button

  if (elementLength1 > 2) {

    $('.buttonToogle1').show();

  }



  $('.populars .popular').slice(startFilter1, endFilter1).addClass('shown');

  $('.shownLength').text(endFilter1);

  $('.populars .popular').not('.shown').hide();

  $('.buttonToogle1 .showMore1').on('click', function() {

      

    if (elementLength1 > endFilter1) {

      startFilter1 += 4;

      endFilter1 += 4;

      $('.populars .popular').slice(startFilter1, endFilter1).not('.shown').addClass('shown').toggle(500);

      $('.shownLength').text((endFilter1 > elementLength1) ? elementLength1 : endFilter1);

      if (elementLength1 <= endFilter1) {

          //$(this).remove();

      }

    }

  });



});

</script> 

