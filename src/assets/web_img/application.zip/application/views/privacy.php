<style>
    .privacy-policy h4 {
    color: #00a66d;
    margin-top: 100px;
    font-size: 28px;
    font-weight: 700;
    margin-bottom: 20px;
}
    .privacy-policy a{
        color: #00A76D !important;
    }
    .privacy-policy a:hover{
        text-decoration: underline;
    }
</style>
<section class="privacy-policy">
  <div class="container">
       <h4><?php echo $cms->title;?></h4>
    <?php
		echo base64_decode($cms->content);?>
  </div>
</section>
