


<section class="about-set-1">

  <div class="container">

    <div class="row">

      <div class="col-md-1"></div>

      <div class="col-md-10 text-center">

	 <?php
	    $about = get_page_section($cms[0]->id, '');

// 	 $sql_content1 = $this->db->query('SELECT * FROM cms WHERE page_name="about_us" AND id=4');

// 	 $content1=$sql_content1->row();

	 

	 

// 	  $sql_content2 = $this->db->query('SELECT * FROM cms WHERE page_name="about_us" AND id=5');

// 	 $content2=$sql_content2->row();

	 

// 	   $sql_content3 = $this->db->query('SELECT * FROM cms WHERE page_name="about_us" AND id=6');

// 	 $content3=$sql_content3->row();

	 ?>

        <h3><?php echo $about[0]->title;?></h3>

        <img src="<?php echo base_url('uploads/about/'.$about[0]->image);?>" alt="<?php echo $about[0]->img_alt;?>" class="img-pars">

        <div><?php echo base64_decode($about[0]->content);?></div> 



      </div>

      <div class="col-md-1"></div>

    </div>

  </div>

</section>



<section class="about-set-2">

  <div class="container">

    <div class="row">

      <div class="col-md-6">

        <img src="<?php echo base_url('uploads/about/'.$about[1]->image);?>" alt="<?php echo $about[1]->img_alt;?>" class="img-fluid mt-5">

      </div>

      <div class="col-md-6">

        <h3><?php echo $about[1]->title;?></h3>



        <div><?php echo base64_decode($about[1]->content);?></div> 

      </div>

    </div>

  </div>

</section>



<section class="about-set-3">

  <div class="container">

    <div class="row">

      <div class="col-md-5">

        <h3><?php echo $about[2]->title;?></h3>



       <div><?php echo base64_decode($about[2]->content);?></div> 

      </div>

      <div class="col-md-2"></div>

      <div class="col-md-5">

        <img src="<?php echo base_url('uploads/about/'.$about[2]->image);?>" alt="<?php echo $about[2]->img_alt;?>" class="img-fluid">

      </div>

    </div>

  </div>

</section>



<section class="about-set-4">

  <div class="container">

    <div class="row">

      <div class="col-md-2"></div>

      <div class="col-md-8 text-center">

        <h3 class="text-dark"><?php echo $about[3]->title;?></h3>
        <div><?php echo base64_decode($about[3]->content);?></div>



        <!--<p class="text-dark">We understand that it is not our mission alone. Because with every EV adoption we move an inch closer to a cleaner, greener, safer and healthier city, state, country and world; which benefit us all now and in the long long time to come.</p>-->

        <!--<p class="text-dark">So, while we partner with EV Dealers, EV Owners, Charging Station Operators, Charger Manufacturers and Dealers, and EV Service Centres, we also encourage all citizens to adopt to EVs and contribute to the global mission of 100% EV adoption by 2030.-->
        <!--</p><br/>-->

 <div class="col-md-12 mb-5 text-center">

            <button class="btn btn-green btn_main"><a href="<?php echo base_url('partner-with-us');?>">Partner with us</button></a>

       </div>      </div>

      <div class="col-md-2"></div>

    </div>

  </div>

</section>

<style>

    

    .about-set-4 {

        /*background-color: #00A76D;*/
        background-color: #eacc1a;

    }

    .about-set-2 {

        padding: 71px 0px;

        background-color: #e6e8ee;

    }

    img.img-fluid.mt-5 {

        width: 486px !important;

        margin-top: 40px !important;

    }

    body {

        font-family: 'Outfit', Sans-Serif;

    }

    .about-set-2 h3 {

        color: #000000;

        font-size: 35px;

        font-weight: 500;

        margin-bottom: 20px;

    }

    .about-set-3 h3 {

        color: #000000;

        font-size: 35px;

        font-weight: 500;

        margin-bottom: 20px;

    }

    .about-set-4 h3 {

        color: #fff;

        font-size: 35px;

        font-weight: 500;

        margin-bottom: 20px;

    }

    .about-set-1 p {

        text-align: center;

        color: #000000;

        font-size: 20px;

        font-weight: 500;

        padding: 40px 50px;

    }

    .about-set-3 p {

        color: #000000;

        font-size: 17px;

        font-weight: 500;

    }

    .about-set-2 p {

        color: #000000;

        font-size: 17px;

        font-weight: 500;

    }

    img.img-fluid.mt-5 {

        width: 486px !important;

        margin-top: 90px !important;

    }

    .btn-green {

        color: #000;

        background-color: #ffffff;

        border: 1px solid #00a66d;

        font-family: 'Outfit', Sans-Serif;

    }

    .btn-green:hover {

        color: #000;

        background-color: #ffffff;

    }



    a {

        color: #ffffff;

        text-decoration: none;

        background-color: transparent;

    } 

    a:hover{
        color: #ffffff;
    }

</style>

