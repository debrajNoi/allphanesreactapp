<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Checkout extends CI_Controller {
    
    private $admin_phone = '';
    private $vendor_phone = '';
    
    public function __construct(){

        parent::__construct();
        
        //$this->load->helper('url');
        // $this->load->helper(array('url','html','form','url_helper','common_helper'));        
        $this->load->helper(array('url','html','form','url_helper'));        

        // Load form validation library
        $this->load->library('form_validation');    
        $this->load->library('session');           

        $this->load->database();

        //load registration model       
        //$this->load->model('registration_model');     
        
        $this->admin_phone = $this->db->get_where('admin_users', ['id'=>'1'])->row()->phone;
    }
    
    
    // Function to send message in callback 2
    public function send_msg_dy($input_data){
        // SMS Credentials
        $api_key = "SMVIHqlkBEqEbQbX6NHDDQ";
        $sender_id = "EVDRMZ";
        $channel_id = "Trans";
        $dcs = 0;
        $flash_msg = 0;
        $route_id = 5;

        // otp message send
        $cSession = curl_init(); 

        //step2
        curl_setopt($cSession,CURLOPT_URL,"http://cloud.smsindiahub.in/api/mt/SendSMS?APIKey=".$api_key."&senderid=".$sender_id."&channel=".$channel_id."&DCS=".$dcs."&flashsms=".$flash_msg."&number=".$input_data['phone']."&text=".$input_data['msg']."&route=".$route_id."##&PEId=##");
        curl_setopt($cSession,CURLOPT_RETURNTRANSFER,true);
        curl_setopt($cSession,CURLOPT_HEADER, false); 
        //step3
        $result=curl_exec($cSession);
        //step4
        curl_close($cSession);
        //step5
        // echo $result;
    }
    
    

    public function index() {
        $this->checkout();
    }

    public function checkout() {
        $data['title']              = 'Checkout payment | Noi Registration';  
        $data['callback_url']       = base_url().'callback';
        $data['surl']               = base_url().'success';;
        $data['furl']               = base_url().'failed';;
        $data['currency_code']      = 'INR';
        $this->load->view('razorpay/checkout', $data);
    }

    // initialized cURL Request
    private function curl_handler($payment_id, $amount)  {
        $url            = 'https://api.razorpay.com/v1/payments/'.$payment_id.'/capture';
        // LIVE 
        $key_id         = "rzp_live_eK02ucWsWY4MQO";
        $key_secret     = "6t06iiyuiHTwkYDLxuEKc03Y";
        
        // TEST
        // $key_id         = "rzp_test_paDUpSny9sdjU3";
        // $key_secret     = "B6G57dQoTGOi382MfJT4rA3p";
        
        $fields_string  = "amount=$amount";
        //cURL Request
        $ch = curl_init();
        //set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_USERPWD, $key_id.':'.$key_secret);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        return $ch;
    }   
        
    // callback method
    public function callback() {   

        $error = ''; 
        if (!empty($this->input->post('reg_razorpay_payment_id')) && !empty($this->input->post('reg_merchant_order_id'))) {
            $razorpay_payment_id = $this->input->post('reg_razorpay_payment_id');
            $merchant_order_id = $this->input->post('reg_merchant_order_id');
            $product_id = $this->input->post('product_id');
            $plan_id = $this->input->post('plan_id');
            
            $currency_code = 'INR';
            $amount = $this->input->post('reg_merchant_total');
            $success = false;
            $error = '';
            try {                
                $ch = $this->curl_handler($razorpay_payment_id, $amount);
                //execute post
                $result = curl_exec($ch);
                $http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                if ($result === false) {
                    $success = false;
                    $error = 'Curl error: '.curl_error($ch);
                } else {
                    $response_array = json_decode($result, true);

                    //Check success response
                    if ($http_status === 200 and isset($response_array['error']) === false) {
                        
                        $buydate = date('Y-m-d H:i:s');
                        
                        // Plan id will be updated with the respective product id
                        $upd_data = [
                                    'is_claimed'=>'1',
                                    'plan_id'=>$plan_id,
                                    'start_plan_date' => $buydate
                                ];
                        $this->db->where('id', $product_id);
                        if($this->db->update('products', $upd_data)){

                            // Insert the order details in tbl_payments 
                            $ins_pay_data = [
                                            "payment_id"=>$response_array['id'],
                                            "payment_for"=>"Payment for claiming a product from pricing page.",
                                            "payment_user"=>$this->session->userdata('admin_id'), //$response_array['id'],
                                            "payment_product_id"=>$product_id,
                                            "payment_amount"=>($response_array['amount']/100),
                                            "order_id"=>$response_array['notes']['soolegal_order_id']
                                        ];
                            $ins_pay_res = $this->db->insert('tbl_payments', $ins_pay_data);
                            if($ins_pay_res){
                                //$this->db->select('users.name as vname, concat(products.brand, " ", products.model) as pname, users.mobile as vphone');
                                $this->db->select('users.name as vname, tbl_plan.title as plan_name, concat(products.brand, " ", products.model) as pname, users.mobile as vphone');
                                $this->db->from('products');
                                $this->db->join('users', 'products.vendor_id=users.id');
                                $this->db->join('tbl_plan', 'products.plan_id = tbl_plan.id');
                            	$this->db->where('products.id', $product_id);
                            	$res = $this->db->get()->result();
                            	$vname = $res[0]->vname;
                            	$v_product_name = $res[0]->pname;
                            	$vendor_phone = $res[0]->vphone;
                            	$plan_name = $res[0]->plan_name;
                                
                                // Send sms for VENDOR TEMPLATE: MSG NOTIF
                                
                                // replaceing the space and - with unicode
                                $vname = str_replace('-', '%2d', str_replace(' ','%20', trim($vname)));
                                $v_product_name = str_replace('-', '%2d', str_replace(' ','%20', trim($v_product_name)));
                                $vendor_section = str_replace('-', '%2d', str_replace(' ','%20', trim($plan_name)));
                                
                                // ----- SMS Code initiated ------
                            	$api_key = "SMVIHqlkBEqEbQbX6NHDDQ";
                            	$sender_id = "EVDRMZ";
                            	$channel_id = "Trans";
                    			$dcs = 0;
                    			$flash_msg = 0;
                    			$route_id = 5;

                            	$msg = "Dear+".$vname."%2c+you+have+successfully+listed+your+product+".$v_product_name."+in+the+".$vendor_section."+section%2e+EV+Dreamz+Private+Limited%2e";
                                
                            	// otp message send
                            	$cSession = curl_init(); 
                    			
                    			//step2
                    			curl_setopt($cSession,CURLOPT_URL,"http://cloud.smsindiahub.in/api/mt/SendSMS?APIKey=".$api_key."&senderid=".$sender_id."&channel=".$channel_id."&DCS=".$dcs."&flashsms=".$flash_msg."&number=".$vendor_phone."&text=".$msg."&route=".$route_id."##&PEId=##");
                    			curl_setopt($cSession,CURLOPT_RETURNTRANSFER,true);
                    			curl_setopt($cSession,CURLOPT_HEADER, false); 
                    			//step3
                    			$result=curl_exec($cSession);
                    			//step4
                    			curl_close($cSession);
                    			//step5
                     			// echo $result;
                                // ----- SMS Code ended ------
                                
                                
                                
                                // ---SMS send to ADMIN . TEMPLATE : NOTIFA
                                
                                // replaceing the space and - with unicode
                                $aname = $vname;
                                $a_product_name = $v_product_name;
                                $admin_section = str_replace('-', '%2d', str_replace(' ','%20', trim($plan_name)));
                                
                                // ----- SMS Code initiated ------
                            	$api_key = "SMVIHqlkBEqEbQbX6NHDDQ";
                            	$sender_id = "EVDRMZ";
                            	$channel_id = "Trans";
                    			$dcs = 0;
                    			$flash_msg = 0;
                    			$route_id = 5;
                    			$phone = $this->db->get_where('admin_users', ['id'=>'1'])->row()->phone;

                            	$msg = $aname.'+has+successfully+listed+their+product+'.$a_product_name.'+in+the+'.$admin_section.'+section%2e+EV+Dreamz+Private+Limited%2e';

                            	// otp message send
                            	$cSession = curl_init(); 

                    			//step2
                    			curl_setopt($cSession,CURLOPT_URL,"http://cloud.smsindiahub.in/api/mt/SendSMS?APIKey=".$api_key."&senderid=".$sender_id."&channel=".$channel_id."&DCS=".$dcs."&flashsms=".$flash_msg."&number=".$phone."&text=".$msg."&route=".$route_id."##&PEId=##");
                    			curl_setopt($cSession,CURLOPT_RETURNTRANSFER,true);
                    			curl_setopt($cSession,CURLOPT_HEADER, false); 
                    			//step3
                    			$result=curl_exec($cSession);
                    			//step4
                    			curl_close($cSession);
                    			//step5
                     			// echo $result;
                                // ----- SMS Code ended ------

                                $success = true;
                                $this->session->unset_userdata('product_id');
                            }

                            // $success = true;
                            // $this->session->unset_userdata('product_id');
                        }


                    } else {
                        $success = false;
                        if (!empty($response_array['error']['code'])) {
                            $error = $response_array['error']['code'].':'.$response_array['error']['description'];
                        } else {
                            $error = 'RAZORPAY_ERROR:Invalid Response <br/>'.$result;
                        }
                    }
                }
                //close curl connection
                curl_close($ch);
            } catch (Exception $e) {
                $success = false;
                $error = 'Request to Razorpay Failed';
            }
            
            if ($success === true) {
                redirect($this->input->post('reg_merchant_surl_id'));
            } else {
                redirect($this->input->post('reg_merchant_furl_id'));
            }
        } else {
            echo 'An error occured. Contact site administrator, please!'.$error;
        }
    } 


    // callback method
    public function callback_2() {   
         
        $error = ''; 
        if (!empty($this->input->post('reg_razorpay_payment_id')) && !empty($this->input->post('reg_merchant_order_id'))) {
            $razorpay_payment_id = $this->input->post('reg_razorpay_payment_id');
            $merchant_order_id = $this->input->post('reg_merchant_order_id');
            $product_id = $this->input->post('product_id');
            $plan_id = $this->input->post('plan_id');
            
            $currency_code = 'INR';
            $amount = $this->input->post('reg_merchant_total');
            $success = false;
            $error = '';
            try {                
                $ch = $this->curl_handler($razorpay_payment_id, $amount);
                //execute post
                $result = curl_exec($ch);
                $http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                if ($result === false) {
                    $success = false;
                    $error = 'Curl error: '.curl_error($ch);
                } else {
                    $response_array = json_decode($result, true);

                    //Check success response
                    if ($http_status === 200 and isset($response_array['error']) === false) {
                        
                        // A loop will run for all the products to update is_verified = 1
                        $exp = explode(',', $product_id);

                        $this->db->select('users.name as vname, users.mobile as vphone');
                        $this->db->from('products');
                        $this->db->join('users', 'products.vendor_id=users.id');
                        $this->db->where('products.id', $exp[0]);
                        $res = $this->db->get()->result();
                        $vname = $res[0]->vname;
                        $this->vendor_phone = $res[0]->vphone;


                        foreach($exp as $pids){
                            // Plan id will be updated with the respective product id
                            $upd_data = [
                                        'is_verified'=>'1'
                                    ];
                            $this->db->where('id', $pids);
                            
                            if($this->db->update('products', $upd_data)){

                                // Insert the order details in tbl_payments 
                                $ins_pay_data = [
                                                "payment_id"=>$response_array['id'],
                                                "payment_for"=>"Payment for product verification from product list.",
                                                "payment_user"=>$this->session->userdata('admin_id'),//$response_array['id'],
                                                "payment_product_id"=>$pids,
                                                "payment_amount"=>$response_array['amount'],
                                                "order_id"=>$response_array['notes']['soolegal_order_id']
                                            ];
                                $ins_pay_res = $this->db->insert('tbl_payments', $ins_pay_data);
                                if($ins_pay_res){
                                    $success = true;
                                }
                            }
                        }

                        if($success){
                            $vname = str_replace('-', '%2d', str_replace(' ','%20', trim($vname)));
                            
                            // SEND sms to Vendor. TEMPLATE : NOTIFVRF
                            $msg = "Dear+".$vname."%2c+you+have+successfully+verified+your+product%2fs%2e+EV+Dreamz+Private+Limited%2e";  // NOTIFVRF 
                            $input_data = [
                                'phone'=>$this->vendor_phone,
                                'msg'=>$msg
                            ];
                            $this->send_msg_dy($input_data);
                            
                            
                            // Send sms to ADMIN.  TEMPLATE : NOTIFVRFA   (MESSAGE PENDING)
                            $admin_msg = $vname."+has+successfully+verified+their+product%2fs%2e+EV+Dreamz+Private+Limited%2e";  // NOTIFVRFA 
                            $input_data_admin = [
                                'phone'=>$this->admin_phone,
                                'msg'=>$admin_msg
                            ];
                            $this->send_msg_dy($input_data_admin);

                            $this->session->unset_userdata('product_id');
                        }
                            
                    } else {
                        $success = false;
                        if (!empty($response_array['error']['code'])) {
                            $error = $response_array['error']['code'].':'.$response_array['error']['description'];
                        } else {
                            $error = 'RAZORPAY_ERROR:Invalid Response <br/>'.$result;
                        }
                    }
                }
                //close curl connection
                curl_close($ch);
            } catch (Exception $e) {
                $success = false;
                $error = 'Request to Razorpay Failed';
            }
            
            if ($success === true) {
                redirect($this->input->post('reg_merchant_surl_id'));
            } else {
                redirect($this->input->post('reg_merchant_furl_id'));
            }
        } else {
            echo 'An error occured. Contact site administrator, please!'.$error;
        }
    }



    public function free_payment($plan_id, $product_id) {
        $buydate = date('Y-m-d H:i:s');

        $this->db->where('id', $product_id);
        $response = $this->db->update('products', ['is_claimed'=>1, 'plan_id'=>$plan_id, 'start_plan_date' => $buydate]);
        if($response){
            echo 1;
        }

    }



    public function success() {
        $this->session->set_flashdata('message', 'The payment was successful.');
        redirect('vendor/product_list');
    }  

    public function failed() {

        $this->session->set_flashdata('message', 'The payment was not successful.');
        redirect('vendor/product_list');
    }

}