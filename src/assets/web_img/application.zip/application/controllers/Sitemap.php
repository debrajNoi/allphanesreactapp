<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Sitemap extends CI_Controller {
    /**
     * Index Page for this controller.
     *
     */
    public function index()
    {
        $this->load->database();
        $this->db->select('*');    
        $this->db->from('users');
        $this->db->where('user_role',1);
        $query = $this->db->get();
        $data['users']= $query->result();
        
        $this->db->select('*');    
        $this->db->from('products');
        $this->db->where('status',1);
        $query2 = $this->db->get();
        $data['products']= $query2->result();
        
        $this->db->distinct();
        $this->db->select('page_name');
        $this->db->not_like('page_name','pricing','after');
        $data['pages'] = $this->db->get('cms')->result();
        
        $this->load->view('sitemap', $data);
    }
}
?>