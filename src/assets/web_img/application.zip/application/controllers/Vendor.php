<?php

defined('BASEPATH') OR exit('No direct script access allowed');

error_reporting(1);

class Vendor extends CI_Controller {

    public function __construct()

    {

        parent::__construct();

        $this->load->library('email');

         $config = array (

                  'mailtype' => 'html',

                  'charset'  => 'utf-8',

                  'priority' => '1'

                   );

        $this->email->initialize($config);

        $this->load->library('session');

      	$this->load->database(); 

        $this->load->helper('url');

    }



	/**

	 * Index Page for this controller.

	 *

	 * Maps to the following URL

	 * 		http://example.com/index.php/welcome

	 *	- or -

	 * 		http://example.com/index.php/welcome/index

	 *	- or -

	 * Since this controller is set as the default controller in

	 * config/routes.php, it's displayed at http://example.com/

	 *

	 * So any other public methods not prefixed with an underscore will

	 * map to /index.php/welcome/

<method_name>

* @see https://codeigniter.com/user_guide/general/urls.html

	 */

	public function index()

	{

	    if($this->input->post('email'))

		{

			$username = $this->input->post('email');

			$password = md5($this->input->post('password'));


			$login_query = $this->db->query('select * from users where email ="'.$username.'" and password ="'.$password.'" and user_type!="customer"');

			

			if($login_query->num_rows() > 0)

			{

				$user_row = $login_query->row();

				if($user_row->status==0){

				    $this->session->set_flashdata('error', 'This Account is Deactivated. Please Contact with evdeamz Admin.');

					$this->load->view('vendor/login');

				}else if($user_row->email_verification==0){

				    $this->session->set_flashdata('error', 'You are not verified via Email.');

					$this->load->view('vendor/login');

				}

			    else{

    		 		$this->session->set_userdata('admin_id', $user_row->id);
    
    				$this->session->set_userdata('admin_email', $user_row->email);
    
    				$this->session->set_userdata('admin_name', $user_row->name);
    
    		 		$this->session->set_userdata('user_type', $user_row->user_type);
    		 		
    		 		$this->session->set_userdata('claim_product', '0');
    
    		 		//$this->session->set_userdata('user_image', $user_row->image);
                    
            		
            		if($user_row->is_new == 0){
            		    $this->db->where('id',$user_row->id);
            			$this->db->update('users',array('is_new'=>1));
            		}
    		 
    
    		 		redirect(base_url('vendor/dashboard'));

			    }

		    }

			else

			{

				// unsuccessfull login

				 $this->session->set_flashdata('error', 'Incorrect login details.');

			}

		}

    	$this->load->view('vendor/login');

    

	}

	

	public function forgot_password()

	{

	    if($this->input->post('email'))

		{

		    

			$username = $this->input->post('email');

		

			

			$login_query = $this->db->query('select * from users where email ="'.$username.'" and user_type!="customer"');

			

			if($login_query->num_rows() > 0)

			{

				$user_row = $login_query->row();

				$FiveDigitRandomNumber = mt_rand(10000,99999);

				$pass=md5($FiveDigitRandomNumber);

				

					$this->email->set_newline("\r\n");

			$this->email->from('evdreamz@gmail.com', 'Reset Password');

      		$data['user_id']=$user_row->user_id;

      			$data['name']=$user_row->name;

      			$data['password']=$FiveDigitRandomNumber;

				$to=$user_row->email;

				$subject='Reset Password';

				$this->email->to($to);



				$this->email->subject($subject); // replace it with relevant subject 

				$body = $this->load->view('reset_password_template',$data,TRUE);

				$this->email->message($body);   

				$this->email->send();

				$this->db->query('UPDATE users SET password="'.$pass.'", is_new = 1 WHERE id="'.$user_row->id.'"');

				$this->session->set_flashdata('success', 'Your password has been reset and sent on your email.');

				redirect("vendor/forgot_password");

		     }

			else

			{

				// unsuccessfull login

				 $this->session->set_flashdata('error', 'Email id not registered.');

			     redirect("vendor/forgot_password");

			}

		}

    	$this->load->view('vendor/forgot_password');

    

	}

	

	

	public function logout()

	{

		$this->load->helper('url');
		
		$this->session->sess_destroy();

		redirect('vendor/login');

	}

	public function dashboard()

	{

	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == "")

		{

			redirect('vendor');

		}

		$data['trial_date'] = $this->db->select('is_website_activated, trial_start_date')->get_where('users', ['id'=>$admin_admin])->result();

	    $this->load->view('vendor/includes/header');

	    $this->load->view('vendor/includes/left', $data);

    	$this->load->view('vendor/home', $data);

    	$this->load->view('vendor/includes/footer');

	}

	

	







/*------------------------------------------------------------------------------------------------------------------------*/

public function profile(){

 $user_id = $this->session->userdata('admin_id');

 	if($user_id == "")
	{
		redirect('vendor');
	}


  	$where = array("id" =>$user_id);

		$get_user_details = $this->webservice_common_model->get_where_row("users",$where);

		$page_data['profile'] = $get_user_details;

	    $this->load->view('vendor/includes/header');

	    $this->load->view('vendor/includes/left');

    	$this->load->view('vendor/my_profile',$page_data);

    	$this->load->view('vendor/includes/footer');



 		if($this->input->post())

		{

		    $id = $user_id;

			$company_name = $this->input->post('company_name');
			
			$company_address = $this->input->post('neighborhood');

			$name = $this->input->post('name');

			$email = $this->input->post('email');

			$phone = $this->input->post('phone');

			$whatsapp = $this->input->post('whatsapp');

			$website = $this->input->post('website');


			if (isset($_FILES['cover_photo']['name']) && !empty($_FILES['cover_photo']['name'])) {
			    // do_upload
				// Here the file uploading condition will be uploaded.
				$image_info = getimagesize($_FILES['cover_photo']['tmp_name']);
				if($image_info[0] > 1110 && $image_info[0] > 315)
				{

					// File upload for cover photo
				   	if(is_uploaded_file($_FILES['cover_photo']['tmp_name']))
				   	{
						$cover_photo=rand(0,9999).$_FILES['cover_photo']['name'];
						move_uploaded_file($_FILES['cover_photo']['tmp_name'],'uploads/profile/'.$cover_photo);
						if(is_file('uploads/profile/'.$_REQUEST['old_image'])){
						 	unlink('uploads/profile/'.$_REQUEST['old_cover_photo']);
						}
				 	} else {
						$cover_photo=$_REQUEST['old_cover_photo'];
				   	}

				}else{
					// echo 'Please, upload an image bigger then 1110pixels X 315pixels.';
					$this->session->set_flashdata('err_msg', 'Please, upload an image bigger then 1110pixels X 315pixels.');
					redirect('vendor/profile');
					exit();
				}

			}
			else{
				$cover_photo=$_REQUEST['old_cover_photo'];
			}


			
			   	
		   	// File upload for logo image
		   	if(is_uploaded_file($_FILES['logo_img']['tmp_name']))
			{

  				$logo_img=rand(0,9999).$_FILES['logo_img']['name'];

  				// list($width, $height) = getimagesize($image);
				// if( $width < 500 && $height < 400 ) { // Check dimensions
				//     // do stuff
				// }
				move_uploaded_file($_FILES['logo_img']['tmp_name'],'uploads/profile/'.$logo_img);
				if(is_file('uploads/profile/'.$_REQUEST['old_image'])){ 
					unlink('uploads/profile/'.$_REQUEST['old_logo_img']);
				}

		 	}else{
				$logo_img=$_REQUEST['old_logo_img'];
		   	}

			

			$userdata = array(

			        'company_name'	=>	$company_name,
			        
			        'neighborhood'	=>	$company_address,

			        'name'			=>	$name,

					'email'			=>	$email,

					'mobile'		=>	$phone,

					'whatsapp'		=>	$whatsapp,

					'website'		=>	$website,

					'image'			=>	$logo_img,
					// 'image'			=>	$image,

					'cover_photo'	=>	$cover_photo,

					// 'logo_img'		=>	$logo_img,

					);

			$this->db->where('id',$id);

			$this->db->update('users',$userdata);

		   	$this->session->set_flashdata('success', 'Profile updated successfully.');

		  	if($this->session->userdata('claim_product') == '1'){
		  		redirect("vendor/product_list");
		  	}
		  	else{
			  	redirect("vendor/profile");
		  	}
			  

		}

}





	public function change_password(){

		$user_id = $this->session->userdata('admin_id');

		$where = array("id" =>$user_id);

		$get_user_details = $this->webservice_common_model->get_where_row("users",$where);

		$page_data['profile'] = $get_user_details;

	    $this->load->view('vendor/includes/header');

	    $this->load->view('vendor/includes/left');

		$this->load->view('vendor/change_password',$page_data);

		$this->load->view('vendor/includes/footer');



		if($this->input->post())
		{

		    $id = $user_id;
		    
		    if($get_user_details->is_new == 0){
		        
		        $new_password = $this->input->post('new_password');
    
    			$confirm_password = $this->input->post('confirm_password');
    			
    			if($new_password!=$confirm_password){
    
    			  	$this->session->set_flashdata('error', 'Confirm password does not match.');
    
    			}else{			
    
    				$userdata = array(
    					'password' => md5($confirm_password),
    					'is_new' =>1
    				);
    
    				$this->db->where('id',$id);
    
    				$this->db->update('users',$userdata);
    
    			   	$this->session->set_flashdata('success', 'Password has been changed successfully.');
    
    		 	}
		        
		    }else{

    			$old_password=md5($this->input->post('old_password'));
    
    			$new_password = $this->input->post('new_password');
    
    			$confirm_password = $this->input->post('confirm_password');
    
    
    			$chk = $this->db->query('SELECT * FROM users WHERE password="'.$old_password.'" AND id="'.$id.'"');
    
    			if($chk->num_rows()<=0){
    
    			    $this->session->set_flashdata('error', 'Your current password does not match.');
    
    			}else if($new_password!=$confirm_password){
    
    			  	$this->session->set_flashdata('error', 'Confirm password does not match.');
    
    			}else{			
    
    				$userdata = array(
    					'password' => md5($confirm_password)
    				);
    
    				$this->db->where('id',$id);
    
    				$this->db->update('users',$userdata);
    
    			   	$this->session->set_flashdata('success', 'Password has been changed successfully.');
    
    		 	}
		    }

		  	redirect("vendor/change_password");

		}

	}





/*--------------------------Upload Products---------------------------------------------*/

public function product_list()

	{

	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == ""){	redirect('vendor/login');}

		    $this->db->select('*');
			$this->db->from('products');
			$this->db->where('vendor_id',$admin_admin);
			$this->db->order_by('id','DESC');
			$query =$this->db->get();
			$products = $query->result();
			$data['product_list']=$products;
			
			$this->db->select('*');
			$this->db->from('tbl_plan');
// 			$this->db->where('id',$data['product_list']->plan_id);
			$query =$this->db->get();
			$plans = $query->result();
			$data['plans']=$plans;


		$data['trial_date'] = $this->db->select('is_website_activated, trial_start_date')->get_where('users', ['id'=>$admin_admin])->result();

	    $this->load->view('vendor/includes/header');

	    $this->load->view('vendor/includes/left', $data);

    	$this->load->view('vendor/products/list',$data);

    	$this->load->view('vendor/includes/footer');

	}

	



    public function product_add()
	{

		$renew_date = date("Y-m-d");
	    $vendor_id = $this->session->userdata('admin_id');
		
		if($vendor_id == ""){ redirect(base_url('vendor')); }
		
		if($this->input->post())
		{
			$vendor_id = $vendor_id;

			$this->db->select('*');

			$this->db->from('users');

			$this->db->where('id',$vendor_id);

			$query =$this->db->get();

			$row = $query->row();

            //product details 
			$vehicle_type = $this->input->post('vehicle_type');

			$brand = $this->input->post('brand_name');

			$top_speed = $this->input->post('top_speed');

			$range = $this->input->post('range');

			$charging_time = $this->input->post('charging_time');

			$motor_power = $this->input->post('motor_power');

			$registration_required = $this->input->post('registration_required');

			$wheel_size = $this->input->post('wheel_size');

			$battery_capacity = $this->input->post('battery_capacity');

			$year = $this->input->post('year');

			$model = $this->input->post('model');

			$display = $this->input->post('display');

			$connectivity = $this->input->post('connectivity');

			$safety_features = $this->input->post('safety_features');

			$color =$this->input->post('color');

			$break_type = $this->input->post('break_type');

			$warranty = $this->input->post('warranty');

			$price = $this->input->post('price');

			$plan_id = $this->input->post('plan');

			$description = base64_encode($this->input->post('description'));

			$location = $this->input->post('location');

			$pincode = $this->input->post('pincode');
			$slug = $model.'-'.$brand.'-'.$year.'-'.$vehicle_type.'-'.$row->company_name;
			$slug = preg_replace('/\s+/','-', strtolower($slug));
			$slug = preg_replace('/\-+/','-', $slug);


            if(is_uploaded_file($_FILES['front_view']['tmp_name'])){
                $front_view=time().rand(0,9999).$_FILES['front_view']['name'];
                @move_uploaded_file($_FILES['front_view']['tmp_name'],'uploads/products/'.$front_view);
            }else{
                $front_view="";
            }
            
            
            if(is_uploaded_file($_FILES['side_view1']['tmp_name'])){
                $side_view1=time().rand(0,9999).$_FILES['side_view1']['name'];
                @move_uploaded_file($_FILES['side_view1']['tmp_name'],'uploads/products/'.$side_view1);
            }else{
                $side_view1="";
            }

			if(is_uploaded_file($_FILES['side_view2']['tmp_name'])){
				$side_view2=time().rand(0,9999).$_FILES['side_view2']['name'];
				@move_uploaded_file($_FILES['side_view2']['tmp_name'],'uploads/products/'.$side_view2);
			}else{
				$side_view2="";
			}

			if(is_uploaded_file($_FILES['rear_view']['tmp_name'])){
				$rear_view=time().rand(0,9999).$_FILES['rear_view']['name'];
				@move_uploaded_file($_FILES['rear_view']['tmp_name'],'uploads/products/'.$rear_view);
			}else{
				$rear_view="";
			}

			if(is_uploaded_file($_FILES['close_up1']['tmp_name'])){
				$close_up1=time().rand(0,9999).$_FILES['close_up1']['name'];
				@move_uploaded_file($_FILES['close_up1']['tmp_name'],'uploads/products/'.$close_up1);
			}else{
				$close_up1="";
			}

			if(is_uploaded_file($_FILES['close_up2']['tmp_name'])){
				$close_up2=time().rand(0,9999).$_FILES['close_up2']['name'];
				@move_uploaded_file($_FILES['close_up2']['tmp_name'],'uploads/products/'.$close_up2);
			}else{
				$close_up2="";
			}

			// only if 
			if(is_uploaded_file($_FILES['hotImage1']['tmp_name'])){
				$hotImage1=time().rand(0,9999).$_FILES['hotImage1']['name'];
				@move_uploaded_file($_FILES['hotImage1']['tmp_name'],'uploads/products/'.$hotImage1);
			}else{
				$hotImage1="";
			}

			if(is_uploaded_file($_FILES['hotImage2']['tmp_name'])){
				$hotImage2=time().rand(0,9999).$_FILES['hotImage2']['name'];
				@move_uploaded_file($_FILES['hotImage2']['tmp_name'],'uploads/products/'.$hotImage2);
			}else{
				$hotImage2="";
			}

			if(is_uploaded_file($_FILES['hotImage3']['tmp_name'])){
				$hotImage3=time().rand(0,9999).$_FILES['hotImage3']['name'];
				@move_uploaded_file($_FILES['hotImage3']['tmp_name'],'uploads/products/'.$hotImage3);
			}else{
				$hotImage3="";
			}

			$data = array(

					'vendor_id'				=>	$vendor_id,

					'vehicle_type'			=>	$vehicle_type,
					
					'slug'                  =>  $slug,

					'year'					=>	$year,

					'model'					=>	$model,

					'brand'					=>	$brand,

					'top_speed'				=>	$top_speed,

					'product_range'			=>	$range,

					'charging_time'			=>	$charging_time,

					'motor_power'			=>	$motor_power,

					'registration_required'	=>  $registration_required,

					'tyres'					=>	$wheel_size,

					'battery_capacity'		=>	$battery_capacity,

					'connectivity'		    =>  $connectivity,

					'safety_features'		=>	$safety_features,

					'product_range'			=>	$range,

					'warranty'				=>	$warranty,

					'price'					=>	$price,

					'description'			=>	$description,

					'display'				=>	$display,

					'color'		        	=>	$color,

					'break_type'			=>	$break_type,

					'location'				=>	$location,

					'pincode'				=>	$pincode,

					'plan_id'				=>	$plan_id,

					'front_view'			=>	$front_view,

					'side_view1'			=>	$side_view1,

					'side_view2'			=>	$side_view2,

					'rear_view'				=>	$rear_view,

					'close_up1'				=>	$close_up1,

					'close_up2'				=>	$close_up2,


					'hot_image1'			=>	$hotImage1,
					'hot_image2'			=>	$hotImage2,
					'hot_image3'			=>	$hotImage3,

					);

									

			$this->db->insert('products',$data);
			
			if (!$this->db->insert_id())
            {
                $error = $this->db->error(); // Has keys 'code' and 'message'
                // echo $error['code'];
                if($error['code'] == 1062){
                    $this->session->set_flashdata('error', 'Product already exist');
                }else{
                    $this->session->set_flashdata('error', 'Not Updated');
                }
            } else {
    			$this->session->set_flashdata('success', 'Product  Updated successfully.');
            }
            
			redirect("Vendor/product_add");
		  }


	  	$data['trial_date'] = $this->db->select('is_website_activated, trial_start_date')->get_where('users', ['id'=>$vendor_id])->result();
	    $this->load->view('vendor/includes/header');
	    $this->load->view('vendor/includes/left', $data);
    	$this->load->view('vendor/products/add');
    	$this->load->view('vendor/includes/footer');

	}

	





public function edit_product()

	{

		$now = date("Y-m-d H:i:s");

		$id = $this->uri->segment(3);

		

	    $admin_admin = $this->session->userdata('admin_id');

		 $vendor_id=$admin_admin;

		if($admin_admin == "")

		{

			redirect('Admin');

		}

		if($this->input->post())
		{
            $this->db->select('slug');
			$this->db->from('products');
			$this->db->where('id',$id);
			$query =$this->db->get();
			$product_res = $query->row();
		    
			$vendor_id = $vendor_id;
			$this->db->select('*');
			$this->db->from('users');
			$this->db->where('id',$vendor_id);
			$query =$this->db->get();
			$row = $query->row();

		  //  product details
		    $vehicle_type = $this->input->post('vehicle_type');
			$brand = $this->input->post('brand_name');
			$top_speed = $this->input->post('top_speed');
			$range = $this->input->post('range');
			$charging_time = $this->input->post('charging_time');
			$motor_power = $this->input->post('motor_power');
			$registration_required = $this->input->post('registration_required');
			$wheel_size = $this->input->post('wheel_size');
			$battery_capacity = $this->input->post('battery_capacity');
			$year = $this->input->post('year');
			$model = $this->input->post('model');
			$display = $this->input->post('display');
			$connectivity = $this->input->post('connectivity');
			$safety_features = $this->input->post('safety_features');
			$color =$this->input->post('color');
			$break_type = $this->input->post('break_type');
			$warranty = $this->input->post('warranty');
			$price = $this->input->post('price');
			$description = base64_encode($this->input->post('description'));
			$location = $this->input->post('location');
			$pincode = $this->input->post('pincode');
            $slug = $model.'-'.$brand.'-'.$year.'-'.$vehicle_type.'-'.$row->company_name;
			$slug = preg_replace('/\s+/','-', strtolower($slug));
			$slug = preg_replace('/\-+/','-', $slug);
			

					 					

				if(is_uploaded_file($_FILES['front_view']['tmp_name']))

				{

					$front_view=time().rand(0,9999).$_FILES['front_view']['name'];

					move_uploaded_file($_FILES['front_view']['tmp_name'],'uploads/products/'.$front_view);

					if(is_file('uploads/products/'.$_REQUEST['old_front_view'])){ 
					
						unlink('uploads/products/'.$_REQUEST['old_front_view']);
					
					}

		 		}else{

					$front_view=$_REQUEST['old_front_view'];

		   		}

					

					

				if(is_uploaded_file($_FILES['side_view1']['tmp_name']))

				{

  						$side_view1=time().rand(0,9999).$_FILES['side_view1']['name'];

						move_uploaded_file($_FILES['side_view1']['tmp_name'],'uploads/products/'.$side_view1);

						if(is_file('uploads/products/'.$_REQUEST['old_side_view1'])){ unlink('uploads/products/'.$_REQUEST['old_side_view1']);}

				 	}else{

					$side_view1=$_REQUEST['old_side_view1'];

		   		}					

					

					

				if(is_uploaded_file($_FILES['side_view2']['tmp_name']))

				{

  						$side_view2=time().rand(0,9999).$_FILES['side_view2']['name'];

						move_uploaded_file($_FILES['side_view2']['tmp_name'],'uploads/products/'.$side_view2);

						if(is_file('uploads/products/'.$_REQUEST['old_side_view2'])){ unlink('uploads/products/'.$_REQUEST['old_side_view2']);}

				 	}else{

					$side_view2=$_REQUEST['old_side_view2'];

		   		}

				

				if(is_uploaded_file($_FILES['rear_view']['tmp_name']))

				{

  						$rear_view=time().rand(0,9999).$_FILES['rear_view']['name'];

						move_uploaded_file($_FILES['rear_view']['tmp_name'],'uploads/products/'.$rear_view);

						if(is_file('uploads/products/'.$_REQUEST['old_rear_view'])){ unlink('uploads/products/'.$_REQUEST['old_rear_view']);}

				 	}else{

					$rear_view=$_REQUEST['old_rear_view'];

		   		}	

					

				if(is_uploaded_file($_FILES['close_up1']['tmp_name']))

				{

  						$close_up1=time().rand(0,9999).$_FILES['close_up1']['name'];

						move_uploaded_file($_FILES['close_up1']['tmp_name'],'uploads/products/'.$close_up1);

						if(is_file('uploads/products/'.$_REQUEST['old_close_up1'])){ unlink('uploads/products/'.$_REQUEST['old_close_up1']);}

				 	}else{

					$close_up1=$_REQUEST['old_close_up1'];

		   		}		

					

					

				if(is_uploaded_file($_FILES['close_up2']['tmp_name']))

				{

  						$close_up2=time().rand(0,9999).$_FILES['close_up2']['name'];

						move_uploaded_file($_FILES['close_up2']['tmp_name'],'uploads/products/'.$close_up2);

						if(is_file('uploads/products/'.$_REQUEST['old_close_up2'])){ unlink('uploads/products/'.$_REQUEST['old_close_up2']);}

				 	}else{

					$close_up2=$_REQUEST['old_close_up2'];

		   		}
		   		
		   		
		   		if(is_uploaded_file($_FILES['hotImage1']['tmp_name']))

				{

  						$hot_image1=time().rand(0,9999).$_FILES['hotImage1']['name'];

						move_uploaded_file($_FILES['hotImage1']['tmp_name'],'uploads/products/'.$hot_image1);

						if(is_file('uploads/products/'.$_REQUEST['old_hot_image1'])){ unlink('uploads/products/'.$_REQUEST['old_hot_image1']);}

				 	}else{

					$hot_image1=$_REQUEST['old_hot_image1'];

		   		}
		   		
		   		
		   		if(is_uploaded_file($_FILES['hotImage2']['tmp_name']))

				{

  						$hot_image2=time().rand(0,9999).$_FILES['hotImage2']['name'];

						move_uploaded_file($_FILES['hotImage2']['tmp_name'],'uploads/products/'.$hot_image2);

						if(is_file('uploads/products/'.$_REQUEST['old_hot_image2'])){ unlink('uploads/products/'.$_REQUEST['old_hot_image2']);}

				 	}else{

					$hot_image2=$_REQUEST['old_hot_image2'];

		   		}
		   		
		   		
		   		if(is_uploaded_file($_FILES['hotImage3']['tmp_name']))

				{

  						$hot_image3=time().rand(0,9999).$_FILES['hotImage3']['name'];

						move_uploaded_file($_FILES['hotImage3']['tmp_name'],'uploads/products/'.$hot_image3);

						if(is_file('uploads/products/'.$_REQUEST['old_hot_image3'])){ unlink('uploads/products/'.$_REQUEST['old_hot_image3']);}

				 	}else{

					$hot_image3=$_REQUEST['old_hot_image3'];

		   		}
		   		
					
            if($product_res == $slug){
                $data = array(
					'vendor_id'				=>	$vendor_id,
					'vehicle_type'			=>	$vehicle_type,
					'slug'                  =>  $slug,
					'year'					=>	$year,
					'model'					=>	$model,
					'brand'					=>	$brand,
					'top_speed'				=>	$top_speed,
					'product_range'			=>	$range,
					'charging_time'			=>	$charging_time,
					'motor_power'			=>	$motor_power,
					'registration_required'	=>  $registration_required,
					'tyres'					=>	$wheel_size,
					'battery_capacity'		=>	$battery_capacity,
					'connectivity'		    =>  $connectivity,
					'safety_features'		=>	$safety_features,
					'product_range'			=>	$range,
					'warranty'				=>	$warranty,
					'price'					=>	$price,
					'description'			=>	$description,
					'display'				=>	$display,
					'color'		        	=>	$color,
					'break_type'			=>	$break_type,
					'location'				=>	$location,
					'pincode'				=>	$pincode,
					'front_view'			=>	$front_view,
					'side_view1'			=>	$side_view1,
					'side_view2'			=>	$side_view2,
					'rear_view'				=>	$rear_view,
					'close_up1'		    	=>	$close_up1,
					'close_up2'		    	=>	$close_up2,
					'hot_image1'            => $hot_image1,
					'hot_image2'            => $hot_image2,
					'hot_image3'            => $hot_image3,
					);
            } else{
                $data = array(
					'vendor_id'				=>	$vendor_id,
					'top_speed'				=>	$top_speed,
					'product_range'			=>	$range,
					'charging_time'			=>	$charging_time,
					'motor_power'			=>	$motor_power,
					'registration_required'	=>  $registration_required,
					'tyres'					=>	$wheel_size,
					'battery_capacity'		=>	$battery_capacity,
					'connectivity'		    =>  $connectivity,
					'safety_features'		=>	$safety_features,
					'product_range'			=>	$range,
					'warranty'				=>	$warranty,
					'price'					=>	$price,
					'description'			=>	$description,
					'display'				=>	$display,
					'color'		        	=>	$color,
					'break_type'			=>	$break_type,
					'location'				=>	$location,
					'pincode'				=>	$pincode,
					'front_view'			=>	$front_view,
					'side_view1'			=>	$side_view1,
					'side_view2'			=>	$side_view2,
					'rear_view'				=>	$rear_view,
					'close_up1'		    	=>	$close_up1,
					'close_up2'		    	=>	$close_up2,
					'hot_image1'            => $hot_image1,
					'hot_image2'            => $hot_image2,
					'hot_image3'            => $hot_image3,
					);
            }
            
            
			$product_id = array("id"=>$id);

            if (!$this->db->update('products',$data,$product_id))
            {
                $error = $this->db->error(); // Has keys 'code' and 'message'
                if($error['code'] == 1062){
                    $this->session->set_flashdata('error', 'Product already exist');
                }else{
                    $this->session->set_flashdata('error', 'Not Updated');
                }
            } else {
    			$this->session->set_flashdata('success', 'Product  Updated successfully.');
            }

			

			redirect("vendor/product_list");

		}

		$where = array("id" =>$this->uri->segment('3'));

		$get_banner = $this->webservice_common_model->get_where_row("products",$where);

		$page_data['product'] = $get_banner;


		$data['trial_date'] = $this->db->select('is_website_activated, trial_start_date')->get_where('users', ['id'=>$admin_admin])->result();

	    $this->load->view('vendor/includes/header');

	    $this->load->view('vendor/includes/left', $data);

    	$this->load->view('vendor/products/edit',$page_data);

    	$this->load->view('vendor/includes/footer');

		

	}

	

	

// 	public function delete_image($op = '', $id, $product_name){

	public function delete_image($id, $image_name){

	    

        $this->db->where('id', $id);

        $res = $this->db->update('products', [$image_name=>'']);

        if($res){

            echo 'Data deleted successfully';

        }

        else{

            echo 'Failed.';

        }

        

        

	    

        // exit($op.' - '.$id.' - '.$product_name);

	    

	   //switch($op){

	   //     case 1: //Delete image

	   //             $file = "uploads/products/".$product_name;

    //                 if (is_readable($file) && unlink($file)) {

    //                     $this->db->where('id', $id);

    //                     $res = $this->db->update('products', ['front_view'=>'']);

    // 	                if($res){

    // 	                    redirect("vendor/product_list");

    // 	                }

    // 	                else{

    // 	                    echo 'File deletion failed.';

    // 	                }

    //                 } else {

    //                     echo "The file was not found or not readable and could not be deleted";

    //                 }

	   //             break;

	                

    //         case 2: // Delete image

    // 	                $file = "uploads/products/".$product_name;

    //                     if (is_readable($file) && unlink($file)) {

    //     	                $this->db->where('id', $id);

    //                         $res = $this->db->update('products', ['side_view1'=>'']);

    //     	                if($res){

    //     	                    redirect("vendor/product_list");

    //     	                }

    //     	                else{

    //     	                    echo 'File deletion failed.';

    //     	                }

    //                     } else {

    //                         echo "The file was not found or not readable and could not be deleted";

    //                     }

	   //             break;

	                

    //         case 3: // Delete Image

    // 	                $file = "uploads/products/".$product_name;

    //                     if (is_readable($file) && unlink($file)) {

    //     	                $this->db->where('id', $id);

    //                         $res = $this->db->update('products', ['side_view2'=>'']);

    //     	                if($res){

    //     	                    redirect("vendor/product_list");

    //     	                }

    //     	                else{

    //     	                    echo 'File deletion failed.';

    //     	                }

    //                     } else {

    //                         echo "The file was not found or not readable and could not be deleted";

    //                     }

	   //             break;

	                

    //         case 4: // Delete Image

    // 	                $file = "uploads/products/".$product_name;

    //                     if (is_readable($file) && unlink($file)) {

    //     	                $this->db->where('id', $id);

    //                         $res = $this->db->update('products', ['rear_view'=>'']);

    //     	                if($res){

    //     	                    redirect("vendor/product_list");

    //     	                }

    //     	                else{

    //     	                    echo 'File deletion failed.';

    //     	                }

    //                     } else {

    //                         echo "The file was not found or not readable and could not be deleted";

    //                     }

	   //             break;

	                

    //         case 5: // Delete images

    // 	                $file = "uploads/products/".$product_name;

    //                     if (is_readable($file) && unlink($file)) {

    //     	                $this->db->where('id', $id);

    //                         $res = $this->db->update('products', ['close_up1'=>'']);

    //     	                if($res){

    //     	                    redirect("vendor/product_list");

    //     	                }

    //     	                else{

    //     	                    echo 'File deletion failed.';

    //     	                }

    //                     } else {

    //                         echo "The file was not found or not readable and could not be deleted";

    //                     }

	   //             break;

	                

    //         case 6: // Delete Images

    // 	                $file = "uploads/products/".$product_name;

    //                     if (is_readable($file) && unlink($file)) {

    //     	                $this->db->where('id', $id);

    //                         $res = $this->db->update('products', ['close_up2'=>'']);

    //     	                if($res){

    //     	                   // redirect('vendor/edit_product/'.$id);

    //     	                    redirect("vendor/product_list");

    //     	                }

    //     	                else{

    //     	                    echo 'File deletion failed.';

    //     	                }

    //                     } else {

    //                         echo "The file was not found or not readable and could not be deleted";

    //                     }

	   //             break;

	                

	   //     default: echo 'nothing ';

	   //             break;

	                

	   //}

	  

	}



	







public function ChangeStatus(){

  	$table=$this->input->post('table');

	$id=$this->input->post('id');

   	$status=$this->input->post('status');

	if($status==1){ $st=0;} if($status==0){ $st=1;}

	//echo 'UPDATE '.$table.' SET status="'.$st.'"  WHERE id="'.$id.'"'; die;

	

	$this->db->query('UPDATE '.$table.' SET status="'.$st.'"  WHERE id="'.$id.'"');

}



	

	

	



/*----------------------------------------Country -------------------------------------*/

	public function country_list()

	{

	   $vendor_id=$this->uri->segment(3);

	 

	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == ""){	redirect('Admin');}

		$sql_country =$this->db->query('SELECT * FROM countries order by id DESC');

		$page_data['country_list'] = $sql_country->result();

	

		

		

	    $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/country/list',$page_data);

    	$this->load->view('admin/includes/footer');

	}

	

	public function country_add()

	{

		$now = date("Y-m-d H:i:s");

		

	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == "")

		{

			redirect('Admin');

		}

		if($this->input->post()){

			$country_name=$this->input->post('country_name');

			

			

			

			$countrydata = array(

			        'country_name'	=>	$country_name

					);

			$this->db->insert('countries',$countrydata);

			$country_id=$this->db->insert_id();

			if($country_id > 0){ $this->session->set_flashdata('success', 'Country Created successfuly.');}	else{$this->session->set_flashdata('error', 'Not Added');}

			redirect("Admin/country_list");

		}  

	     $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/country/add');

    	$this->load->view('admin/includes/footer');

	}

	public function edit_country()

	{

		$now = date("Y-m-d H:i:s");

		$id = $this->uri->segment(3);

		

	    $admin_admin = $this->session->userdata('admin_id');

		

		if($admin_admin == "")

		{

			redirect('Admin');

		}

		if($this->input->post())

		{

		  	$country_name=$this->input->post('country_name');

		  

			

			

			$countrydata = array(

			        'country_name'	=>	$country_name

					);



			

			$country_id = array("id"=>$id);

			$update = $this->db->update('countries',$countrydata,$country_id);

			if($update > 0)

			{

				 $this->session->set_flashdata('success', 'Country  Updated successfully.');

			}

			else

			{

				$this->session->set_flashdata('error', 'Not Updated');

			}

			redirect("Admin/country_list");

		}

		$where = array("id" =>$this->uri->segment('3'));

		$get_country = $this->webservice_common_model->get_where_row("countries",$where);

		$page_data['country'] = $get_country;

	    $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/country/edit',$page_data);

    	$this->load->view('admin/includes/footer');

		

	}

	public function country_delete()

	{

		$admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == "")

		{

			redirect('Admin');

		}

		$id = $this->input->post('id');

		

		

		$update = $this->db->query('DELETE FROM countries WHERE id="'.$id.'"');

		if($update > 0)

		{

			$response['success']='1';	

			$response['message']="Delete done successfully."; 

		}

		else

		{

			$response['success']='0';	

			$response['message']="Not update";

		}

		echo  json_encode($response);

	}





/*----------------------------------------University -------------------------------------*/

	public function university_list()

	{

	   $vendor_id=$this->uri->segment(3);

	 

	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == ""){	redirect('Admin');}

		$sql_university =$this->db->query('SELECT * FROM universities order by id DESC');

		$page_data['university_list'] = $sql_university->result();

	

		

		

	    $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/university/list',$page_data);

    	$this->load->view('admin/includes/footer');

	}

	

	public function university_add()

	{

		$now = date("Y-m-d H:i:s");

		

	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == "")

		{

			redirect('Admin');

		}

		if($this->input->post()){

			$university_name=$this->input->post('university_name');

			

			

			

			$universitydata = array(

			        'university_name'	=>	$university_name

					);

			$this->db->insert('universities',$universitydata);

			$university_id=$this->db->insert_id();

			if($university_id > 0){ $this->session->set_flashdata('success', 'University Created successfuly.');}	else{$this->session->set_flashdata('error', 'Not Added');}

			redirect("Admin/university_list");

		}  

	     $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/university/add');

    	$this->load->view('admin/includes/footer');

	}

	public function edit_university()

	{

		$now = date("Y-m-d H:i:s");

		$id = $this->uri->segment(3);

		

	    $admin_admin = $this->session->userdata('admin_id');

		

		if($admin_admin == "")

		{

			redirect('Admin');

		}

		if($this->input->post())

		{

		  	$university_name=$this->input->post('university_name');

		  

			

			

			$universitydata = array(

			        'university_name'	=>	$university_name

					);



			

			$university_id = array("id"=>$id);

			$update = $this->db->update('universities',$universitydata,$university_id);

			if($update > 0)

			{

				 $this->session->set_flashdata('success', 'University  Updated successfully.');

			}

			else

			{

				$this->session->set_flashdata('error', 'Not Updated');

			}

			redirect("Admin/university_list");

		}

		$where = array("id" =>$this->uri->segment('3'));

		$get_university = $this->webservice_common_model->get_where_row("universities",$where);

		$page_data['university'] = $get_university;

	    $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/university/edit',$page_data);

    	$this->load->view('admin/includes/footer');

		

	}

	public function university_delete()

	{

		$admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == "")

		{

			redirect('Admin');

		}

		$id = $this->input->post('id');

		

		

		$update = $this->db->query('DELETE FROM universities WHERE id="'.$id.'"');

		if($update > 0)

		{

			$response['success']='1';	

			$response['message']="Delete done successfully."; 

		}

		else

		{

			$response['success']='0';	

			$response['message']="Not update";

		}

		echo  json_encode($response);

	}

		



/*----------------------------------------Course -------------------------------------*/

	public function course_list()

	{

	   $vendor_id=$this->uri->segment(3);

	 

	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == ""){	redirect('Admin');}

		$sql_course =$this->db->query('SELECT * FROM courses order by id DESC');

		$page_data['course_list'] = $sql_course->result();

	

		

		

	    $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/course/list',$page_data);

    	$this->load->view('admin/includes/footer');

	}

	

	public function course_add()

	{

		$now = date("Y-m-d H:i:s");

		

	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == "")

		{

			redirect('Admin');

		}

		if($this->input->post()){

			$course_name=$this->input->post('course_name');

			$description=$this->input->post('description');

			

			

			

			$coursedata = array(

			        'course_name'	=>	$course_name,

					'description'	=>	$description

					);

			$this->db->insert('courses',$coursedata);

			$course_id=$this->db->insert_id();

			if($course_id > 0){ $this->session->set_flashdata('success', 'Course Created successfuly.');}	else{$this->session->set_flashdata('error', 'Not Added');}

			redirect("Admin/course_list");

		}  

	     $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/course/add');

    	$this->load->view('admin/includes/footer');

	}

	public function edit_course()

	{

		$now = date("Y-m-d H:i:s");

		$id = $this->uri->segment(3);

		

	    $admin_admin = $this->session->userdata('admin_id');

		

		if($admin_admin == "")

		{

			redirect('Admin');

		}

		if($this->input->post())

		{

		  	$course_name=$this->input->post('course_name');

			$description=$this->input->post('description');

		  

			

			

				$coursedata = array(

			        'course_name'	=>	$course_name,

					'description'	=>	$description

					);



			

			$course_id = array("id"=>$id);

			$update = $this->db->update('courses',$coursedata,$course_id);

			if($update > 0)

			{

				 $this->session->set_flashdata('success', 'Course  Updated successfully.');

			}

			else

			{

				$this->session->set_flashdata('error', 'Not Updated');

			}

			redirect("Admin/course_list");

		}

		$where = array("id" =>$this->uri->segment('3'));

		$get_course = $this->webservice_common_model->get_where_row("courses",$where);

		$page_data['course'] = $get_course;

	    $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/course/edit',$page_data);

    	$this->load->view('admin/includes/footer');

		

	}

	public function course_delete()

	{

		$admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == "")

		{

			redirect('Admin');

		}

		$id = $this->input->post('id');

		

		

		$update = $this->db->query('DELETE FROM courses WHERE id="'.$id.'"');

		if($update > 0)

		{

			$response['success']='1';	

			$response['message']="Delete done successfully."; 

		}

		else

		{

			$response['success']='0';	

			$response['message']="Not update";

		}

		echo  json_encode($response);

	}

	





/*----------------------------------------Testimonial -------------------------------------*/

	public function testimonial_list()

	{

	   $vendor_id=$this->uri->segment(3);

	 

	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == ""){	redirect('Admin');}

		$sql_testi =$this->db->query('SELECT * FROM testimonials order by id DESC');

		$page_data['testimonial_ist'] = $sql_testi->result();

	

		

		

	    $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/testimonial/list',$page_data);

    	$this->load->view('admin/includes/footer');

	}

	

	public function add_testimonial()

	{

		$now = date("Y-m-d H:i:s");

		 $vendor_id=$this->uri->segment(3);

	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == "")

		{

			redirect('Admin');

		}

		if($this->input->post()){

			$name=$this->input->post('name');

			$designation = $this->input->post('designation');

			$course=$this->input->post('course');

			$message=$this->input->post('message');

			if(is_uploaded_file($_FILES['image']['tmp_name'])){

						$image=rand(0,9999).$_FILES['image']['name'];

						@move_uploaded_file($_FILES['image']['tmp_name'],'uploads/testimonials/'.$image);

					}else{

						$image="";

					}

			

			$testimonial_data = array(

			        'name'			=>	$name,

					'designation'	=>	$designation,

				   'course'			=>	$course,

				   'message'		=>	$message,

				   'image'			=> $image

				

					);

			$this->db->insert('testimonials',$testimonial_data);

			$testimonial_id=$this->db->insert_id();

			if($testimonial_id > 0){ $this->session->set_flashdata('success', 'Testimonial Created successfuly.');}	else{$this->session->set_flashdata('error', 'Not Added');}

			redirect("Admin/testimonial_list/".$vendor_id);

		}  

	     $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/testimonial/add');

    	$this->load->view('admin/includes/footer');

	}

	public function edit_testimonial()

	{

		$now = date("Y-m-d H:i:s");

		$id = $this->uri->segment(3);

		 $vendor_id=$this->uri->segment(4);

	    $admin_admin = $this->session->userdata('admin_id');

		

		if($admin_admin == "")

		{

			redirect('Admin');

		}

		if($this->input->post())

		{

		   $name=$this->input->post('name');

		   $designation = $this->input->post('designation');

			$course=$this->input->post('course');

			$message=$this->input->post('message');

			if(is_uploaded_file($_FILES['image']['tmp_name']))

			{

  				$image=rand(0,9999).$_FILES['image']['name'];

				move_uploaded_file($_FILES['image']['tmp_name'],'uploads/testimonials/'.$image);

				if(is_file('uploads/testimonials/'.$_REQUEST['old_image'])){ unlink('uploads/testimonials/'.$_REQUEST['old_image']);}

				 }else{

					$image=$_REQUEST['old_image'];

		   	}

			

			

			$testimonial_data = array(

			        'name'			=>	$name,

					'designation'			=>	$designation,

				   'course'			=>	$course,

				   'message'		=>	$message,

				   'image'			=> $image

				

					);



			

			$testimonial_id = array("id"=>$id);

			$update = $this->db->update('testimonials',$testimonial_data,$testimonial_id);

			if($update > 0)

			{

				 $this->session->set_flashdata('success', 'Testimonial  Updated successfully.');

			}

			else

			{

				$this->session->set_flashdata('error', 'Not Updated');

			}

			redirect("Admin/testimonial_list/".$vendor_id);

		}

		$where = array("id" =>$this->uri->segment('3'));

		$get_testimonial = $this->webservice_common_model->get_where_row("testimonials",$where);

		$page_data['testimonial'] = $get_testimonial;

	    $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/testimonial/edit',$page_data);

    	$this->load->view('admin/includes/footer');

		

	}

	public function delete_testimonial()

	{

		$admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == "")

		{

			redirect('Admin');

		}

		$id = $this->input->post('id');

		

		

		$update = $this->db->query('DELETE FROM testimonials WHERE id="'.$id.'"');

		if($update > 0)

		{

			$response['success']='1';	

			$response['message']="Delete done successfully."; 

		}

		else

		{

			$response['success']='0';	

			$response['message']="Not update";

		}

		echo  json_encode($response);

	}

	

	

/*----------------------------------------counselor -------------------------------------*/

	public function counselor_list()

	{

	   $vendor_id=$this->uri->segment(3);

	 

	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == ""){	redirect('Admin');}

		$sql_testi =$this->db->query('SELECT * FROM counselors order by id DESC');

		$page_data['counselor_list'] = $sql_testi->result();

	

		

		

	    $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/counselor/list',$page_data);

    	$this->load->view('admin/includes/footer');

	}

	

	public function add_counselor()

	{

		$now = date("Y-m-d H:i:s");

		 $vendor_id=$this->uri->segment(3);

	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == "")

		{

			redirect('Admin');

		}

		if($this->input->post()){

			$name=$this->input->post('name');

			$email=$this->input->post('email');

			$mobile=$this->input->post('mobile');

			$university=$this->input->post('university');

			$about=$this->input->post('about');

			if(is_uploaded_file($_FILES['image']['tmp_name'])){

						$image=rand(0,9999).$_FILES['image']['name'];

						@move_uploaded_file($_FILES['image']['tmp_name'],'uploads/counselors/'.$image);

					}else{

						$image="";

					}

			

			$counselordata = array(

			        'name'			=>	$name,

				   'email'			=>	$email,

				   'mobile'			=>	$mobile,

				   'university'		=>	$university,

				   'about'			=>	$about,

				   'image'			=> $image

				

					);

			$this->db->insert('counselors',$counselordata);

			$testimonial_id=$this->db->insert_id();

			if($testimonial_id > 0){ $this->session->set_flashdata('success', 'Counselor Created successfuly.');}	else{$this->session->set_flashdata('error', 'Not Added');}

			redirect("Admin/counselor_list/".$vendor_id);

		}  

	     $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/counselor/add');

    	$this->load->view('admin/includes/footer');

	}

	public function edit_counselor()

	{

		$now = date("Y-m-d H:i:s");

		$id = $this->uri->segment(3);

		 $vendor_id=$this->uri->segment(4);

	    $admin_admin = $this->session->userdata('admin_id');

		

		if($admin_admin == "")

		{

			redirect('Admin');

		}

		if($this->input->post())

		{

		 $name=$this->input->post('name');

			$email=$this->input->post('email');

			$mobile=$this->input->post('mobile');

			$university=$this->input->post('university');

			$about=$this->input->post('about');

			if(is_uploaded_file($_FILES['image']['tmp_name']))

			{

  				$image=rand(0,9999).$_FILES['image']['name'];

				move_uploaded_file($_FILES['image']['tmp_name'],'uploads/counselors/'.$image);

				if(is_file('uploads/testimonials/'.$_REQUEST['old_image'])){ unlink('uploads/counselors/'.$_REQUEST['old_image']);}

				 }else{

					$image=$_REQUEST['old_image'];

		   	}

			

			

			$counselordata = array(

			        'name'			=>	$name,

				   'email'			=>	$email,

				   'mobile'			=>	$mobile,

				   'university'		=>	$university,

				   'about'			=>	$about,

				   'image'			=> $image

				

					);



			

			$counselor_id = array("id"=>$id);

			$update = $this->db->update('counselors',$counselordata,$counselor_id);

			if($update > 0)

			{

				 $this->session->set_flashdata('success', 'Counselor  Updated successfully.');

			}

			else

			{

				$this->session->set_flashdata('error', 'Not Updated');

			}

			redirect("Admin/counselor_list/".$vendor_id);

		}

		$where = array("id" =>$this->uri->segment('3'));

		$get_testimonial = $this->webservice_common_model->get_where_row("counselors",$where);

		$page_data['counselor'] = $get_testimonial;

	    $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/counselor/edit',$page_data);

    	$this->load->view('admin/includes/footer');

		

	}

	public function delete_counselor()

	{

		$admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == "")

		{

			redirect('Admin');

		}

		$id = $this->input->post('id');

		

		

		$update = $this->db->query('DELETE FROM counselors WHERE id="'.$id.'"');

		if($update > 0)

		{

			$response['success']='1';	

			$response['message']="Delete done successfully."; 

		}

		else

		{

			$response['success']='0';	

			$response['message']="Not update";

		}

		echo  json_encode($response);

	}



	public function booking_requests()

	{

	   $vendor_id=$this->uri->segment(3);

	 

	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == ""){	redirect('Admin');}

			// $this->db->select('*,customer_bookings.dated as booking_date');

			$this->db->select('customer_bookings.*, products.model, products.year, products.brand, products.vehicle_type');

			$this->db->from('customer_bookings');

			$this->db->join('products', 'products.id = customer_bookings.product_id'); 

			$this->db->order_by('customer_bookings.dated', 'DESC'); 

			$this->db->where('products.vendor_id', $admin_admin); 

			$query = $this->db->get();

			$page_data['request_list']= $query->result();


			$data['trial_date'] = $this->db->select('is_website_activated, trial_start_date')->get_where('users', ['id'=>$admin_admin])->result();
			
			$this->load->view('vendor/includes/header');

			$this->load->view('vendor/includes/left', $data);

			$this->load->view('vendor/booking/list',$page_data);

			$this->load->view('vendor/includes/footer');

	}




	public function customer_queries()

	{

	   $vendor_id=$this->uri->segment(3);

	 

	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == ""){	redirect('Admin');}

			// $this->db->select('*,customer_bookings.dated as booking_date');

			$this->db->select('*');

			// $this->db->select('customer_bookings.id, customer_bookings.name, customer_bookings.email, customer_bookings.mobile, customer_bookings.location', 'customer_bookings.message, customer_bookings.dated');

			$this->db->from('customer_bookings');

			// $this->db->join('products', 'products.id = 0'); 

			$this->db->order_by('customer_bookings.dated', 'DESC'); 

			$this->db->where('customer_bookings.product_id', '0'); 

			$query = $this->db->get();

			$page_data['request_list']= $query->result();


			$data['trial_date'] = $this->db->select('is_website_activated, trial_start_date')->get_where('users', ['id'=>$admin_admin])->result();
			
			$this->load->view('vendor/includes/header');

			$this->load->view('vendor/includes/left', $data);

			$this->load->view('vendor/queries/list',$page_data);

			$this->load->view('vendor/includes/footer');

	}


	public function accept_it($is_accepted, $id){
		$data = [
			'is_accepted' => $is_accepted
		];
		$this->db->where('id', $id);
		$res = $this->db->update('customer_bookings', $data);
		if($res){
			echo '1';
		}
		else{
			echo '0';
		}
	}



	public function claim_product($product_id = '', $status = ''){

		$this->session->set_userdata('product_id', $product_id);
		redirect('pricing');

		// This will be done after plan purchase from product pricing page
		// $this->db->where('id', $product_id);
		// $res = $this->db->update('products', ['is_claimed'=>$status]);
		// if($res){
		// 	redirect('vendor/product_list');
		// }
		// else{
		// 	echo 'Failed';
		// 	redirect('vendor/product_list');
		// }
	}	

	public function verify_product($product_id = '', $status = ''){
		$this->db->where('id', $product_id);
		$res = $this->db->update('products', ['is_verified'=>$status]);
		if($res){
			redirect('vendor/product_list');
		}
		else{
			echo 'Failed';
			redirect('vendor/product_list');
		}
	}

	public function upgrade_product($product_id = '', $status = ''){
		
		// $this->db->where('id', $product_id);
		// $res = $this->db->update('products', ['is_verified'=>$status]);
		// if($res){
		// 	redirect('vendor/product_list');
		// }
		// else{
		// 	echo 'Failed';
		// 	redirect('vendor/product_list');
		// }
	}		


	public function customer_reviews(){

	    $admin_admin = $this->session->userdata('admin_id');


		if($admin_admin == ""){	redirect('Admin');}

		$this->db->select('*');

			$this->db->from('tbl_ratings');

		    $this->db->join('products', 'products.id = tbl_ratings.prod_id');
		     
		    // $this->db->join('users', 'users.id = tbl_ratings.vendor_id'); 

			$this->db->where('tbl_ratings.vendor_id',$admin_admin);

			$this->db->order_by('tbl_ratings.id','DESC');

			$query =$this->db->get();

			$products = $query->result();

			$data['review_list']=$products;

		$data['trial_date'] = $this->db->select('is_website_activated, trial_start_date')->get_where('users', ['id'=>$admin_admin])->result();

	    $this->load->view('vendor/includes/header');

	    $this->load->view('vendor/includes/left', $data);

    	$this->load->view('vendor/reviews/list',$data);

    	$this->load->view('vendor/includes/footer');

	}



	// Menu for website setting
	public function website_setting(){

	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == ""){	redirect('Admin');}

		if($this->input->post()){

			$chk = $this->db->get_where('tbl_website_settings', ['vendor_id'=>$this->input->post('vendor_id')])->result();

			if($chk){

				$upd_data = array(
			        'vendor_id' => $this->input->post('vendor_id'),
			        'about_us' 	=> $this->input->post('about_us'),
			        'phone' 	=> $this->input->post('phone'),
			        'email' 	=> $this->input->post('email'),
			        'timing' 	=> $this->input->post('timing'),
			        'status' 	=> 1
				);
				$this->db->where('vendor_id', $this->input->post('vendor_id'));
				$query = $this->db->update('tbl_website_settings', $upd_data);
				if($query){
					$this->session->set_flashdata('error', 'Content has been successfully updated.');
					redirect('vendor/website_setting');
				}
				else{
					$this->session->set_flashdata('error', 'Failed to update content.');
					redirect('vendor/website_setting');
				}

			}
			else{

				$ins_data = array(
			        'vendor_id' => $this->input->post('vendor_id'),
			        'about_us' 	=> $this->input->post('about_us'),
			        'phone' 	=> $this->input->post('phone'),
			        'email' 	=> $this->input->post('email'),
			        'timing' 	=> $this->input->post('timing'),
			        'status' 	=> 1
				);
				$query = $this->db->insert('tbl_website_settings', $ins_data);
				$query = $this->db->insert_id();
				if($query){
					$this->session->set_flashdata('error', 'Content has been successfully added.');
					redirect('vendor/website_setting');
				}
				else{
					$this->session->set_flashdata('error', 'Failed to add content.');
					redirect('vendor/website_setting');
				}

			}


		}

		$data['vendor'] = $this->db->get_where('tbl_website_settings', ['vendor_id'=>$this->session->userdata('admin_id')])->result_array();

		$data['trial_date'] = $this->db->select('is_website_activated, trial_start_date')->get_where('users', ['id'=>$admin_admin])->result();
	    
	    $this->load->view('vendor/includes/header');

	    $this->load->view('vendor/includes/left', $data);

    	$this->load->view('vendor/website_setting/setup',$data);

    	$this->load->view('vendor/includes/footer');

	}

	public function activate_trial($slug){
		$admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == "")
		{
			redirect('vendor');
		}

		$this->db->where('slug', $slug);
		$upd = $this->db->update('users', ['is_website_activated'=>'1', 'trial_start_date'=>date('Y-m-d H:i:s')]);
		if($upd){
			// echo 'yes';
			redirect($slug);
		}
		else{
			// echo 'no';
		}

	}

	public function get_my_website(){

		$admin_admin = $this->session->userdata('admin_id');
		if($admin_admin == "")
		{
			redirect('vendor');
		}

		$this->db->where('id', $admin_admin);
		$activate = $this->db->update('users', ['is_website_activated'=>'1']);
		if($activate){
			echo 'yes';
		}
		else{
			echo 'no';
		}

	}

	public function cancel_activation(){

		$admin_admin = $this->session->userdata('admin_id');
		if($admin_admin == "")
		{
			redirect('vendor');
		}

		$this->db->where('id', $admin_admin);
		$activate = $this->db->update('users', ['is_website_activated'=>'0']);
		if($activate){
			echo 'yes';
		}
		else{
			echo 'no';
		}

	}

} 