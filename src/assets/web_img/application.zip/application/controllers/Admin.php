<?php

defined('BASEPATH') OR exit('No direct script access allowed');



class Admin extends CI_Controller {

public function __construct()

    {

        parent::__construct();

        $this->load->library('email');

     		$config = array (

                  'mailtype' => 'html',

                  'charset'  => 'utf-8',

                  'priority' => '1'

                   );

        $this->email->initialize($config);

        $this->load->library('session');

      	$this->load->database(); 

        $this->load->helper('url');

    }



	/**

	 * Index Page for this controller.

	 *

	 * Maps to the following URL

	 * 		http://example.com/index.php/welcome

	 *	- or -

	 * 		http://example.com/index.php/welcome/index

	 *	- or -

	 * Since this controller is set as the default controller in

	 * config/routes.php, it's displayed at http://example.com/

	 *

	 * So any other public methods not prefixed with an underscore will

	 * map to /index.php/welcome/

<method_name>

* @see https://codeigniter.com/user_guide/general/urls.html

	 */

	public function index()

	{

	    if($this->input->post('email'))

		{

			$username = $this->input->post('email');

			$password = md5($this->input->post('password'));

			

			$login_query = $this->db->query("select * from admin_users where email = '".$username."' and password = '".$password."'");
		

			if($login_query->num_rows() > 0)

			{

				$user_row = $login_query->row();

				

		 		$this->session->set_userdata('admin_id', $user_row->id);

				$this->session->set_userdata('admin_email', $user_row->email);

				$this->session->set_userdata('admin_name', $user_row->name);

		 		$this->session->set_userdata('user_type', $user_row->user_type);

		 		//$this->session->set_userdata('user_image', $user_row->image);

		 

		 		redirect(base_url('Admin/dashboard'));

			}

			else

			{

				// unsuccessfull login

				 $this->session->set_flashdata('error', 'Incorrect login details.');

			}

		}

    	$this->load->view('admin/login');

    

	}

	public function logout()

	{

		$this->load->helper('url');

		$this->session->sess_destroy();

		redirect('Admin');

	}

	public function dashboard()

	{

	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == "")
		{
			redirect('Admin');
		}

	    $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/home');

    	$this->load->view('admin/includes/footer');

	}

	

	







/*------------------------------------------------------------------------------------------------------------------------*/

	

public function profile(){

 $user_id = $this->session->userdata('admin_id');

  $where = array("id" =>$user_id);

		$get_user_details = $this->webservice_common_model->get_where_row("admin_users",$where);

		$page_data['profile'] = $get_user_details;

	    $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/my_profile',$page_data);

    	$this->load->view('admin/includes/footer');



 		if($this->input->post())

		{

		    $id = $user_id;

			$name=$this->input->post('name');

			$email = $this->input->post('email');

			$phone = $this->input->post('phone');

			if(is_uploaded_file($_FILES['image']['tmp_name']))

			{

  				$image=rand(0,9999).$_FILES['image']['name'];

				move_uploaded_file($_FILES['image']['tmp_name'],'uploads/profile/'.$image);

				if(is_file('uploads/profile/'.$_REQUEST['old_image'])){ unlink('uploads/profile/'.$_REQUEST['old_image']);}

				 }else{

					$image=$_REQUEST['old_image'];

		   	}

			

			$userdata = array(

			        'name'			=>	$name,

					'email'			=>	$email,

					'phone'			=>	$phone,

					'image'			=>	$image,

					);

				$this->db->where('id',$id);

				$this->db->update('admin_users',$userdata);

			   $this->session->set_flashdata('success', 'Profile updated successfully.');

			  redirect("Admin/profile");

		}

}





public function change_password(){

 $user_id = $this->session->userdata('admin_id');

  $where = array("id" =>$user_id);

		$get_user_details = $this->webservice_common_model->get_where_row("admin_users",$where);

		$page_data['profile'] = $get_user_details;

	    $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/change_password',$page_data);

    	$this->load->view('admin/includes/footer');



 		if($this->input->post())

		{

		    $id = $user_id;

			$old_password=md5($this->input->post('old_password'));

			$new_password = $this->input->post('new_password');

			$confirm_password = $this->input->post('confirm_password');

			

			$chk=$this->db->query('SELECT * FROM admin_users WHERE password="'.$old_password.'" AND id="'.$id.'"');

			if($chk->num_rows()<=0){

			    $this->session->set_flashdata('error', 'Your current password does not match.');

			}else if($new_password!=$confirm_password){

			  $this->session->set_flashdata('error', 'Confirm password does not match.');

			}else{			

			$userdata = array(

			        'password'			=>	md5($confirm_password)

					);

				$this->db->where('id',$id);

				$this->db->update('admin_users',$userdata);

			   $this->session->set_flashdata('success', 'Password has been changed successfully.');

			 }

			  redirect("Admin/change_password");

		}

}





/*--------------------------Upload Products---------------------------------------------*/

public function product_list()

	{

	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == ""){	redirect('Admin');}

		$this->db->select('*');

			$this->db->from('products');

			//$this->db->where('vendor_id',$admin_admin);

			$this->db->order_by('id','DESC');

			$query =$this->db->get();

			$products = $query->result();

			$data['product_list']=$products;

	    $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/products/list',$data);

    	$this->load->view('admin/includes/footer');

	}

	



    public function product_add() {
        
		$renew_date = date("Y-m-d");
	    $vendor_id = $this->session->userdata('admin_id');
		if($vendor_id == "")
		{
			redirect(base_url('vendor'));
		}

		if($this->input->post())
		{
			$vendor_id = $vendor_id;
			$this->db->select('*');
			$this->db->from('users');
			$this->db->where('id',$vendor_id);
			$query =$this->db->get();
			$row = $query->row();

			$year = $this->input->post('year');
			$brand = $this->input->post('brand');
			$model = $this->input->post('model');
			$sensors =$this->input->post('sensors');
			$socket_type = $this->input->post('socket_type');
			$battery_type = $this->input->post('battery_type');
			$motor_type = $this->input->post('motor_type');
			$range = $this->input->post('range');
			$charging_time = $this->input->post('charging_time');
			$price = $this->input->post('price');
			$description = $this->input->post('description');
			$starting = $this->input->post('starting');
			$safety_features = $this->input->post('safety_features');
			$chassis_suspension = $this->input->post('chassis_suspension');
			$tyres = $this->input->post('tyres');
			$break_type = $this->input->post('break_type');
			$warranty = $this->input->post('warranty');
			$location = $this->input->post('location');
			$slug = $model.' '.$brand.' '.$year.' '.$vehicle_type.' '.$row->company_name;
			$slug = preg_replace('/\s+/','-',strtolower($slug));

			if(is_uploaded_file($_FILES['front_view']['tmp_name'])){
				$front_view=time().rand(0,9999).$_FILES['front_view']['name'];
				@move_uploaded_file($_FILES['front_view']['tmp_name'],'uploads/products/'.$front_view);
			}else{
				$front_view="";
			}

			if(is_uploaded_file($_FILES['side_view1']['tmp_name'])){
				$side_view1=time().rand(0,9999).$_FILES['side_view1']['name'];
				@move_uploaded_file($_FILES['side_view1']['tmp_name'],'uploads/products/'.$side_view1);
			}else{
				$side_view1="";
			}

			if(is_uploaded_file($_FILES['side_view2']['tmp_name'])){
				$side_view2=time().rand(0,9999).$_FILES['side_view2']['name'];
				@move_uploaded_file($_FILES['side_view2']['tmp_name'],'uploads/products/'.$side_view2);
			}else{
				$side_view2="";
			}

    		if(is_uploaded_file($_FILES['rear_view']['tmp_name'])){
    			$rear_view=time().rand(0,9999).$_FILES['rear_view']['name'];
    			@move_uploaded_file($_FILES['rear_view']['tmp_name'],'uploads/products/'.$rear_view);
    		}else{
    			$rear_view="";
    		}
    
    		if(is_uploaded_file($_FILES['close_up1']['tmp_name'])){
    			$close_up1=time().rand(0,9999).$_FILES['close_up1']['name'];
    			@move_uploaded_file($_FILES['close_up1']['tmp_name'],'uploads/products/'.$close_up1);
    		}else{
    			$close_up1="";
    		}
    
    		if(is_uploaded_file($_FILES['close_up2']['tmp_name'])){
    			$close_up2=time().rand(0,9999).$_FILES['close_up2']['name'];
    			@move_uploaded_file($_FILES['close_up2']['tmp_name'],'uploads/products/'.$close_up2);
    		}else{
    			$close_up2="";
    		}

			$data = array(
					'year'				=>	$year,
					'model'				=>	$model,
					'slug'              =>  $slug,
					'brand'				=>	$brand,
					'socket_type'		=>	$socket_type,
					'battery_type'		=>	$battery_type,
					'motor_type'		=>	$motor_type,
					'product_range'		=>	$range,
					'charging_time'		=>	$charging_time,
					'price'				=>	$price,
					'description'		=>	$description,
					'starting_type'		=>	$starting,
					'safety_features'	=>	$safety_features,
					'sensors'			=>	$sensors,
					'chassis_suspension'=>	$chassis_suspension,
					'tyres'				=>	$tyres,
					'break_type'		=>	$break_type,
					'warranty'			=>	$warranty,
					'location'			=>	$location,
					'front_view'		=>	$front_view,
					'side_view1'		=>	$side_view1,
					'side_view2'		=>	$side_view2,
					'rear_view'			=>	$rear_view,
					'close_up1'			=>	$close_up1,
					'close_up2'			=>	$close_up2,
					);
									
			$this->db->insert('products',$data);
			$product_id=$this->db->insert_id();
			if($banner_id > 0){ $this->session->set_flashdata('success', 'Product Added successfuly.');}	else{$this->session->set_flashdata('error', 'Not Added');}
			redirect("admin/product_add");
		  }

	    $this->load->view('admin/includes/header');
	    $this->load->view('admin/includes/left');
    	$this->load->view('admin/products/add');
    	$this->load->view('admin/includes/footer');
	}

	





    public function edit_product() {

		$now = date("Y-m-d H:i:s");
		$id = $this->uri->segment(3);
	    $admin_admin = $this->session->userdata('admin_id');
		$vendor_id = $this->uri->segment(4);
		if($admin_admin == "") {
			redirect('Admin');
		}

		if($this->input->post()){
		    
		    $this->db->select('slug');
			$this->db->from('products');
			$this->db->where('id',$id);
			$query =$this->db->get();
			$product_res = $query->row();

			$vendor_id = $vendor_id;
			$this->db->select('*');
			$this->db->from('users');
			$this->db->where('id',$vendor_id);
			$query =$this->db->get();
			$vendors = $query->row();

		    $vehicle_type = $this->input->post('vehicle_type');
			$brand = $this->input->post('brand_name');
			$top_speed = $this->input->post('top_speed');
			$range = $this->input->post('range');
			$charging_time = $this->input->post('charging_time');
			$motor_power = $this->input->post('motor_power');
			$registration_required = $this->input->post('registration_required');
			$wheel_size = $this->input->post('wheel_size');
			$battery_capacity = $this->input->post('battery_capacity');
			$year = $this->input->post('year');
			$model = $this->input->post('model');
			$display = $this->input->post('display');
			$connectivity = $this->input->post('connectivity');
			$safety_features = $this->input->post('safety_features');
			$color =$this->input->post('color');
			$break_type = $this->input->post('break_type');
			$warranty = $this->input->post('warranty');
			$price = $this->input->post('price');
			$description = base64_encode($this->input->post('description'));
			$location = $this->input->post('location');
			$pincode = $this->input->post('pincode');
			$slug = $model.'-'.$brand.'-'.$year.'-'.$vehicle_type.'-'.$vendors->company_name;
			$slug = preg_replace('/\s+/','-', strtolower($slug));
			$slug = preg_replace('/\-+/','-', $slug);

		    if(is_uploaded_file($_FILES['front_view']['tmp_name'])) {
				$front_view=time().rand(0,9999).$_FILES['front_view']['name'];
				move_uploaded_file($_FILES['front_view']['tmp_name'],'uploads/products/'.$front_view);
				if(is_file('uploads/products/'.$_REQUEST['old_front_view'])){ 
					unlink('uploads/products/'.$_REQUEST['old_front_view']);
				}
	 		}else{
				$front_view=$_REQUEST['old_front_view'];
	   		}

			if(is_uploaded_file($_FILES['side_view1']['tmp_name'])) {
  				$side_view1=time().rand(0,9999).$_FILES['side_view1']['name'];
				move_uploaded_file($_FILES['side_view1']['tmp_name'],'uploads/products/'.$side_view1);

				if(is_file('uploads/products/'.$_REQUEST['old_side_view1'])){ 
				    unlink('uploads/products/'.$_REQUEST['old_side_view1']);
				}
			}else{

				$side_view1=$_REQUEST['old_side_view1'];

	   		}					

			if(is_uploaded_file($_FILES['side_view2']['tmp_name'])) {
  				$side_view2=time().rand(0,9999).$_FILES['side_view2']['name'];
				move_uploaded_file($_FILES['side_view2']['tmp_name'],'uploads/products/'.$side_view2);
				
				if(is_file('uploads/products/'.$_REQUEST['old_side_view2'])){ 
				    unlink('uploads/products/'.$_REQUEST['old_side_view2']);
				}
			 }else{
				$side_view2=$_REQUEST['old_side_view2'];
	   		}

				

				if(is_uploaded_file($_FILES['rear_view']['tmp_name']))

				{

  						$rear_view=time().rand(0,9999).$_FILES['rear_view']['name'];

						move_uploaded_file($_FILES['rear_view']['tmp_name'],'uploads/products/'.$rear_view);

						if(is_file('uploads/products/'.$_REQUEST['old_rear_view'])){ unlink('uploads/products/'.$_REQUEST['old_rear_view']);}

				 	}else{

					$rear_view=$_REQUEST['old_rear_view'];

		   		}	

					

				if(is_uploaded_file($_FILES['close_up1']['tmp_name']))

				{

  						$close_up1=time().rand(0,9999).$_FILES['close_up1']['name'];

						move_uploaded_file($_FILES['close_up1']['tmp_name'],'uploads/products/'.$close_up1);

						if(is_file('uploads/products/'.$_REQUEST['old_close_up1'])){ unlink('uploads/products/'.$_REQUEST['old_close_up1']);}

				 	}else{

					$close_up1=$_REQUEST['old_close_up1'];

		   		}		

					

					

				if(is_uploaded_file($_FILES['close_up2']['tmp_name']))

				{

  						$close_up2=time().rand(0,9999).$_FILES['close_up2']['name'];

						move_uploaded_file($_FILES['close_up2']['tmp_name'],'uploads/products/'.$close_up2);

						if(is_file('uploads/products/'.$_REQUEST['old_close_up2'])){ unlink('uploads/products/'.$_REQUEST['old_close_up2']);}

				 	}else{

					$close_up2=$_REQUEST['old_close_up2'];

		   		}
		   		
		   		
		   		if(is_uploaded_file($_FILES['hotImage1']['tmp_name']))

				{

  						$hot_image1=time().rand(0,9999).$_FILES['hotImage1']['name'];

						move_uploaded_file($_FILES['hotImage1']['tmp_name'],'uploads/products/'.$hot_image1);

						if(is_file('uploads/products/'.$_REQUEST['old_hot_image1'])){ unlink('uploads/products/'.$_REQUEST['old_hot_image1']);}

				 	}else{

					$hot_image1=$_REQUEST['old_hot_image1'];

		   		}
		   		
		   		
		   		if(is_uploaded_file($_FILES['hotImage2']['tmp_name']))

				{

  						$hot_image2=time().rand(0,9999).$_FILES['hotImage2']['name'];

						move_uploaded_file($_FILES['hotImage2']['tmp_name'],'uploads/products/'.$hot_image2);

						if(is_file('uploads/products/'.$_REQUEST['old_hot_image2'])){ unlink('uploads/products/'.$_REQUEST['old_hot_image2']);}

				 	}else{

					$hot_image2=$_REQUEST['old_hot_image2'];

		   		}
		   		
		   		
		   		if(is_uploaded_file($_FILES['hotImage3']['tmp_name']))

				{

  						$hot_image3=time().rand(0,9999).$_FILES['hotImage3']['name'];

						move_uploaded_file($_FILES['hotImage3']['tmp_name'],'uploads/products/'.$hot_image3);

						if(is_file('uploads/products/'.$_REQUEST['old_hot_image3'])){ unlink('uploads/products/'.$_REQUEST['old_hot_image3']);}

				 	}else{

					$hot_image3=$_REQUEST['old_hot_image3'];

		   		}
		   		
		   	if($product_res == $slug){
                $data = array(
					'vendor_id'				=>	$vendor_id,
					'vehicle_type'			=>	$vehicle_type,
					'slug'                  =>  $slug,
					'year'					=>	$year,
					'model'					=>	$model,
					'brand'					=>	$brand,
					'top_speed'				=>	$top_speed,
					'product_range'			=>	$range,
					'charging_time'			=>	$charging_time,
					'motor_power'			=>	$motor_power,
					'registration_required'	=>  $registration_required,
					'tyres'					=>	$wheel_size,
					'battery_capacity'		=>	$battery_capacity,
					'connectivity'		    =>  $connectivity,
					'safety_features'		=>	$safety_features,
					'product_range'			=>	$range,
					'warranty'				=>	$warranty,
					'price'					=>	$price,
					'description'			=>	$description,
					'display'				=>	$display,
					'color'		        	=>	$color,
					'break_type'			=>	$break_type,
					'location'				=>	$location,
					'pincode'				=>	$pincode,
					'front_view'			=>	$front_view,
					'side_view1'			=>	$side_view1,
					'side_view2'			=>	$side_view2,
					'rear_view'				=>	$rear_view,
					'close_up1'		    	=>	$close_up1,
					'close_up2'		    	=>	$close_up2,
					'hot_image1'            => $hot_image1,
					'hot_image2'            => $hot_image2,
					'hot_image3'            => $hot_image3,
				);
            } else{
                $data = array(
					'vendor_id'				=>	$vendor_id,
					'top_speed'				=>	$top_speed,
					'product_range'			=>	$range,
					'charging_time'			=>	$charging_time,
					'motor_power'			=>	$motor_power,
					'registration_required'	=>  $registration_required,
					'tyres'					=>	$wheel_size,
					'battery_capacity'		=>	$battery_capacity,
					'connectivity'		    =>  $connectivity,
					'safety_features'		=>	$safety_features,
					'product_range'			=>	$range,
					'warranty'				=>	$warranty,
					'price'					=>	$price,
					'description'			=>	$description,
					'display'				=>	$display,
					'color'		        	=>	$color,
					'break_type'			=>	$break_type,
					'location'				=>	$location,
					'pincode'				=>	$pincode,
					'front_view'			=>	$front_view,
					'side_view1'			=>	$side_view1,
					'side_view2'			=>	$side_view2,
					'rear_view'				=>	$rear_view,
					'close_up1'		    	=>	$close_up1,
					'close_up2'		    	=>	$close_up2,
					'hot_image1'            => $hot_image1,
					'hot_image2'            => $hot_image2,
					'hot_image3'            => $hot_image3,
				);
            }

			$product_id = array("id"=>$id);
			$update = $this->db->update('products',$data,$product_id);
			if($update > 0)
			{
				 $this->session->set_flashdata('success', 'Product  Updated successfully.');
			}
			else
			{
				$this->session->set_flashdata('error', 'Not Updated');
			}

			redirect("admin/product_list");
		}

		$where = array("id" =>$this->uri->segment('3'));
		$get_banner = $this->webservice_common_model->get_where_row("products",$where);
		$page_data['product'] = $get_banner;

	    $this->load->view('admin/includes/header');
	    $this->load->view('admin/includes/left');
    	$this->load->view('admin/products/edit',$page_data);
    	$this->load->view('admin/includes/footer');

	}

	

	

	public function delete_image($id, $image_name){

	    

        $this->db->where('id', $id);

        $res = $this->db->update('products', [$image_name=>'']);

        if($res){

            echo 'Data deleted successfully';

        }

        else{

            echo 'Failed.';

        }

        

	}

	

	

    public function delete_product()

	{

		$admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == "")

		{

			redirect('Admin');

		}

		$id = $this->input->post('id');

		

		$sql_p= $this->db->query('SELECT * FROM products WHERE id="'.$id.'"');

		$p=$sql_p->row();

		unlink('uploads/products/'.$p->front_view);

		unlink('uploads/products/'.$p->side_view1);

		unlink('uploads/products/'.$p->side_view2);

		unlink('uploads/products/'.$p->rear_view);

		unlink('uploads/products/'.$p->close_up1);

		unlink('uploads/products/'.$p->close_up2);

		$update = $this->db->query('DELETE FROM products WHERE id="'.$id.'"');

		if($update > 0)

		{

			$response['success']='1';	

			$response['message']="Delete done successfully."; 

		}

		else

		{

			$response['success']='0';	

			$response['message']="Not update";

		}

		echo  json_encode($response);

	}



    public function delete_vendor()
	{

		$admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == "")

		{

			redirect('Admin');

		}

		$id = $this->input->post('id');

		

		$sql_p= $this->db->query('SELECT * FROM users WHERE id="'.$id.'"');

		$p=$sql_p->row();

		if($p->cover_photo != ''){
			unlink('uploads/profile/'.$p->cover_photo);
		}
		if($p->logo_img != ''){
			unlink('uploads/profile/'.$p->logo_img);
		}


		// unlink('uploads/products/'.$p->side_view1);

		// unlink('uploads/products/'.$p->side_view2);

		// unlink('uploads/products/'.$p->rear_view);

		// unlink('uploads/products/'.$p->close_up1);

		// unlink('uploads/products/'.$p->close_up2);

		$update = $this->db->query('DELETE FROM users WHERE id="'.$id.'"');

		if($update > 0)
		{
			$response['success']='1';	
			$response['message']="Delete done successfully."; 
		}
		else
		{
			$response['success']='0';	
			$response['message']="Not update";
		}
		echo  json_encode($response);

	}




    public function delete_user()
	{

		$admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == "")

		{

			redirect('Admin');

		}

		$id = $this->input->post('id');

		

		$sql_p= $this->db->query('SELECT * FROM users WHERE id="'.$id.'"');

		$p=$sql_p->row();

		if($p->cover_photo != ''){
			unlink('uploads/profile/'.$p->cover_photo);
		}
		if($p->logo_img != ''){
			unlink('uploads/profile/'.$p->logo_img);
		}

		$update = $this->db->query('DELETE FROM users WHERE id="'.$id.'"');

		if($update > 0)
		{
			$response['success']='1';	
			$response['message']="Delete done successfully."; 
		}
		else
		{
			$response['success']='0';	
			$response['message']="Not update";
		}
		echo  json_encode($response);

	}

	

public function vendor_list()

	{

	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == ""){	redirect('Admin');}

		

		$this->db->select('*,users.id as user_id,users.name as vendor_name,cities.city as city_name,states.name as state_name');

		$this->db->from('users');

		$this->db->join('cities', 'cities.id = users.city');

		$this->db->join('states', 'states.id = users.state');

		$this->db->where('users.user_type!=', 'customer');

		$this->db->order_by('users.id', 'DESC');



		$query = $this->db->get();

		$data['user_list'] = $query->result();

		

		

	    $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/vendors/list',$data);

    	$this->load->view('admin/includes/footer');

	}



	public function user_list()

	{
		
	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == ""){	redirect('Admin');}

		

		$this->db->select('*,users.id as user_id,users.name as vendor_name,cities.city as city_name,states.name as state_name');

		$this->db->from('users');

		$this->db->join('cities', 'cities.id = users.city');

		$this->db->join('states', 'states.id = users.state');

		// $this->db->where('users.user_type!=', 'customer');
		$this->db->where('users.user_role=', '2');

		$this->db->order_by('users.id', 'DESC');



		$query = $this->db->get();

		$data['user_list'] = $query->result();

		

		

	    $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/users/list',$data);

    	$this->load->view('admin/includes/footer');

	}




	public function verfied_product_list()

	{

	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == ""){	redirect('Admin');}

		
		$this->db->select('*');
		$this->db->where('is_verified', '1');
		$products = $this->db->get('products')->result();

		$data['product_list'] = $products;
		

	    $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/products/verified_product_list',$data);

    	$this->load->view('admin/includes/footer');

	}



	public function claimed_product_list()

	{

	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == ""){	redirect('Admin');}

		
		$this->db->select('*');
		$this->db->where('is_claimed', '1');
		$products = $this->db->get('products')->result();

		$data['product_list'] = $products;
		

	    $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/products/claimed_product_list',$data);

    	$this->load->view('admin/includes/footer');

	}


	

	

	public function edit_vendor()

	{

	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == ""){	redirect('Admin');}

		$id=$this->uri->segment(3);

		

		if($this->input->post()){
		    
		    if (isset($_FILES['cover_photo']['name']) && !empty($_FILES['cover_photo']['name'])) {
			    // do_upload
				// Here the file uploading condition will be uploaded.
				$image_info = getimagesize($_FILES['cover_photo']['tmp_name']);
				if($image_info[0] > 1110 && $image_info[0] > 315)
				{

					// File upload for cover photo
				   	if(is_uploaded_file($_FILES['cover_photo']['tmp_name']))
				   	{
						$cover_photo=rand(0,9999).$_FILES['cover_photo']['name'];
						move_uploaded_file($_FILES['cover_photo']['tmp_name'],'uploads/profile/'.$cover_photo);
						if(is_file('uploads/profile/'.$_REQUEST['old_cover_photo'])){
						 	unlink('uploads/profile/'.$_REQUEST['old_cover_photo']);
						}
				 	} else {
						$cover_photo=$_REQUEST['old_cover_photo'];
				   	}

				}else{
					// echo 'Please, upload an image bigger then 1110pixels X 315pixels.';
					$this->session->set_flashdata('err_msg', 'Please, upload an image bigger then 1110pixels X 315pixels.');
					redirect('admin/edit_vendor/'.$id);
					exit();
				}

			}
			else{
				$cover_photo=$_REQUEST['old_cover_photo'];
			}
			   	
		   	// File upload for logo image
		   	if(is_uploaded_file($_FILES['logo_img']['tmp_name']))
			{
  				$logo_img=rand(0,9999).$_FILES['logo_img']['name'];
  				
				move_uploaded_file($_FILES['logo_img']['tmp_name'],'uploads/profile/'.$logo_img);
				if(is_file('uploads/profile/'.$_REQUEST['old_logo_img'])){ 
					unlink('uploads/profile/'.$_REQUEST['old_logo_img']);
				}

		 	}else{
				$logo_img=$_REQUEST['old_logo_img'];
		   	}

		    	
				 
			

		    $vendor_data=array(

		        'name' => $this->input->post('name'),

		        'company_name' => $this->input->post('company'),

		        'email' => $this->input->post('email'),

		        'mobile' => $this->input->post('mobile'),
		        
		        'whatsapp' => $this->input->post('whatsapp'),
		        'gst_number' => $this->input->post('gst_number'),
		        'city' => $this->input->post('city'),
		        'state' => $this->input->post('state'),
		        'neighborhood'=>$this->input->post('neighborhood'),
		        'pincode'=>$this->input->post('pincode'),
		        'image'	=> $logo_img,
				'cover_photo' => $cover_photo,

		        );

		    $where_id=array('id'=>$id);

		    $this->db->update('users',$vendor_data,$where_id);

		     $this->session->set_flashdata('success', 'Vendor  Updated successfully.');

		     redirect(base_url('Admin/vendor_list'));

	}

		

		

		$this->db->select('users.*,users.id as user_id,cities.city as city_name,states.name as state_name');

		$this->db->from('users');

		$this->db->join('cities', 'cities.id = users.city','RIGHT');

		$this->db->join('states', 'states.id = users.state','RIGHT');

		$this->db->where('users.id', $id);

	



		$query = $this->db->get();

		$data['vendor'] = $query->row();

		

		

	    $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/vendors/edit',$data);

    	$this->load->view('admin/includes/footer');

	}






public function edit_user()

	{

	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == ""){	redirect('Admin');}

		$id=$this->uri->segment(3);

		

		if($this->input->post()){

		    	if(is_uploaded_file($_FILES['image']['tmp_name']))

				{

		            $image=time().rand(0,9999).$_FILES['image']['name'];

						move_uploaded_file($_FILES['image']['tmp_name'],'uploads/users/'.$image);

						if(is_file('uploads/users/'.$_REQUEST['old_image'])){ unlink('uploads/users/'.$_REQUEST['old_image']);}

				 	}else{

					$image=$_REQUEST['old_image'];

				 }

		    $vendor_data=array(

		        'name' => $this->input->post('name'),

		        'company_name' => $this->input->post('company'),

		        'email' => $this->input->post('email'),

		        'mobile' => $this->input->post('mobile'),

		        'city' => $this->input->post('city'),

		        'state' => $this->input->post('state'),

		        'neighborhood'=>$this->input->post('neighborhood'),

		        'pincode'=>$this->input->post('pincode'),

		        'image'=>$image

		        );

		    $where_id=array('id'=>$id);

		    $this->db->update('users',$vendor_data,$where_id);

		     $this->session->set_flashdata('success', 'User Updated successfully.');

		     redirect(base_url('Admin/user_list'));

	}

		

		

		$this->db->select('*,users.id as user_id,cities.city as city_name,states.name as state_name');

		$this->db->from('users');

		$this->db->join('cities', 'cities.id = users.city','RIGHT');

		$this->db->join('states', 'states.id = users.state','RIGHT');

		$this->db->where('users.id', $id);

	



		$query = $this->db->get();

		$data['vendor'] = $query->row();

		

		

	    $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/users/edit',$data);

    	$this->load->view('admin/includes/footer');

	}





public function ChangeStatus(){

  	$table=$this->input->post('table');

	$id=$this->input->post('id');

   	$status=$this->input->post('status');

	if($status==1){ $st=0;} if($status==0){ $st=1;}



	

	$this->db->query('UPDATE '.$table.' SET status="'.$st.'" WHERE id="'.$id.'"');

}



public function ChangeFeaturedStatus(){

  	$table=$this->input->post('table');

	$id=$this->input->post('id');

   	$status=$this->input->post('status');

	if($status==1){ $st=0;} if($status==0){ $st=1;}

	//echo 'UPDATE '.$table.' SET status="'.$st.'"  WHERE id="'.$id.'"'; die;

	

	$this->db->query('UPDATE '.$table.' SET is_featured="'.$st.'"  WHERE id="'.$id.'"');

}



public function ChangePopularStatus(){

  	$table=$this->input->post('table');

	$id=$this->input->post('id');

   	$status=$this->input->post('status');

	if($status==1){ $st=0;} if($status==0){ $st=1;}

	//echo 'UPDATE '.$table.' SET status="'.$st.'"  WHERE id="'.$id.'"'; die;

	

	$this->db->query('UPDATE '.$table.' SET popular="'.$st.'"  WHERE id="'.$id.'"');

}



public function ChangeBannerStatus(){

  	$table=$this->input->post('table');

	$id=$this->input->post('id');

   	$status=$this->input->post('status');

	if($status==1){ $st=0;} if($status==0){ $st=1;}

	//echo 'UPDATE '.$table.' SET status="'.$st.'"  WHERE id="'.$id.'"'; die;

	

	$this->db->query('UPDATE '.$table.' SET show_banner="'.$st.'"  WHERE id="'.$id.'"');

}





	

public function banner_add()

{

	$renew_date = date("Y-m-d");

    $admin_admin = $this->session->userdata('admin_id');

	if($admin_admin == "")

	{

		redirect('Admin');

	}

	if($this->input->post())

	{

		  		

		$title = $this->input->post('title');

		$description = $this->input->post('description');

		

				 if(is_uploaded_file($_FILES['image']['tmp_name'])){

					$image=rand(0,9999).$_FILES['image']['name'];

					@move_uploaded_file($_FILES['image']['tmp_name'],'uploads/banners/'.$image);

				}else{

					$image="";

				}

		

		$bannerdata = array(

				

				'title'			=>	$title,

				'description'	=>	$description,

				'image'			=>	$image

				);

								

		$this->db->insert('banners',$bannerdata);

		$banner_id=$this->db->insert_id();

		if($banner_id > 0){ $this->session->set_flashdata('success', 'Banner Added successfuly.');}	else{$this->session->set_flashdata('error', 'Not Added');}

		redirect("Admin/banner_list");

		

	  }

    $this->load->view('admin/includes/header');

    $this->load->view('admin/includes/left');

	$this->load->view('admin/banner/add');

	$this->load->view('admin/includes/footer');

}

	



	





	public function edit_banner()

	{

		$now = date("Y-m-d H:i:s");

		$id = $this->uri->segment(3);

		 $vendor_id=$this->uri->segment(4);

	    $admin_admin = $this->session->userdata('admin_id');

		

		if($admin_admin == "")

		{

			redirect('Admin');

		}

		if($this->input->post())

		{

		    $title = $this->input->post('title');

			$description = $this->input->post('description');

			if(is_uploaded_file($_FILES['image']['tmp_name']))

			{

  				$image=rand(0,9999).$_FILES['image']['name'];

				move_uploaded_file($_FILES['image']['tmp_name'],'uploads/banners/'.$image);

				if(is_file('uploads/banners/'.$_REQUEST['old_image'])){ unlink('uploads/banners/'.$_REQUEST['old_image']);}

				 }else{

					$image=$_REQUEST['old_image'];

		   	}

			

			

			$bannerdata = array(

					

					'title'			=>	$title,

					'description'	=>	$description,

					'image'			=>	$image

					);

						

			

			$banner_id = array("id"=>$id);

			$update = $this->db->update('banners',$bannerdata,$banner_id);

			if($update > 0)

			{

				 $this->session->set_flashdata('success', 'Banner  Updated successfully.');

			}

			else

			{

				$this->session->set_flashdata('error', 'Not Updated');

			}

			redirect("Admin/banner_list");

		}

		$where = array("id" =>$this->uri->segment('3'));

		$get_banner = $this->webservice_common_model->get_where_row("banners",$where);

		$page_data['banner'] = $get_banner;

	    $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/banner/edit',$page_data);

    	$this->load->view('admin/includes/footer');

	}



	public function delete_banner()

	{

		$admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == "")

		{

			redirect('Admin');

		}

		$id = $this->input->post('id');

		

		

		$update = $this->db->query('DELETE FROM banners WHERE id="'.$id.'"');

		if($update > 0)

		{

			$response['success']='1';	

			$response['message']="Delete done successfully."; 

		}

		else

		{

			$response['success']='0';	

			$response['message']="Not update";

		}

		echo  json_encode($response);

	}

	



/*----------------------------------------Country -------------------------------------*/

	public function country_list()

	{

	   $vendor_id=$this->uri->segment(3);

	 

	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == ""){	redirect('Admin');}

		$sql_country =$this->db->query('SELECT * FROM countries order by id DESC');

		$page_data['country_list'] = $sql_country->result();

	

		

		

	    $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/country/list',$page_data);

    	$this->load->view('admin/includes/footer');

	}

	

	public function country_add()

	{

		$now = date("Y-m-d H:i:s");

		

	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == "")

		{

			redirect('Admin');

		}

		if($this->input->post()){

			$country_name=$this->input->post('country_name');

			

			

			

			$countrydata = array(

			        'country_name'	=>	$country_name

					);

			$this->db->insert('countries',$countrydata);

			$country_id=$this->db->insert_id();

			if($country_id > 0){ $this->session->set_flashdata('success', 'Country Created successfuly.');}	else{$this->session->set_flashdata('error', 'Not Added');}

			redirect("Admin/country_list");

		}  

	     $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/country/add');

    	$this->load->view('admin/includes/footer');

	}

	public function edit_country()

	{

		$now = date("Y-m-d H:i:s");

		$id = $this->uri->segment(3);

		

	    $admin_admin = $this->session->userdata('admin_id');

		

		if($admin_admin == "")

		{

			redirect('Admin');

		}

		if($this->input->post())

		{

		  	$country_name=$this->input->post('country_name');

		  

			

			

			$countrydata = array(

			        'country_name'	=>	$country_name

					);



			

			$country_id = array("id"=>$id);

			$update = $this->db->update('countries',$countrydata,$country_id);

			if($update > 0)

			{

				 $this->session->set_flashdata('success', 'Country  Updated successfully.');

			}

			else

			{

				$this->session->set_flashdata('error', 'Not Updated');

			}

			redirect("Admin/country_list");

		}

		$where = array("id" =>$this->uri->segment('3'));

		$get_country = $this->webservice_common_model->get_where_row("countries",$where);

		$page_data['country'] = $get_country;

	    $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/country/edit',$page_data);

    	$this->load->view('admin/includes/footer');

		

	}

	public function country_delete()

	{

		$admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == "")

		{

			redirect('Admin');

		}

		$id = $this->input->post('id');

		

		

		$update = $this->db->query('DELETE FROM countries WHERE id="'.$id.'"');

		if($update > 0)

		{

			$response['success']='1';	

			$response['message']="Delete done successfully."; 

		}

		else

		{

			$response['success']='0';	

			$response['message']="Not update";

		}

		echo  json_encode($response);

	}





/*----------------------------------------University -------------------------------------*/

	public function university_list()

	{

	   $vendor_id=$this->uri->segment(3);

	 

	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == ""){	redirect('Admin');}

		$sql_university =$this->db->query('SELECT * FROM universities order by id DESC');

		$page_data['university_list'] = $sql_university->result();

	

		

		

	    $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/university/list',$page_data);

    	$this->load->view('admin/includes/footer');

	}

	

	public function university_add()

	{

		$now = date("Y-m-d H:i:s");

		

	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == "")

		{

			redirect('Admin');

		}

		if($this->input->post()){

			$university_name=$this->input->post('university_name');

			

			

			

			$universitydata = array(

			        'university_name'	=>	$university_name

					);

			$this->db->insert('universities',$universitydata);

			$university_id=$this->db->insert_id();

			if($university_id > 0){ $this->session->set_flashdata('success', 'University Created successfuly.');}	else{$this->session->set_flashdata('error', 'Not Added');}

			redirect("Admin/university_list");

		}  

	     $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/university/add');

    	$this->load->view('admin/includes/footer');

	}

	public function edit_university()

	{

		$now = date("Y-m-d H:i:s");

		$id = $this->uri->segment(3);

		

	    $admin_admin = $this->session->userdata('admin_id');

		

		if($admin_admin == "")

		{

			redirect('Admin');

		}

		if($this->input->post())

		{

		  	$university_name=$this->input->post('university_name');

		  

			

			

			$universitydata = array(

			        'university_name'	=>	$university_name

					);



			

			$university_id = array("id"=>$id);

			$update = $this->db->update('universities',$universitydata,$university_id);

			if($update > 0)

			{

				 $this->session->set_flashdata('success', 'University  Updated successfully.');

			}

			else

			{

				$this->session->set_flashdata('error', 'Not Updated');

			}

			redirect("Admin/university_list");

		}

		$where = array("id" =>$this->uri->segment('3'));

		$get_university = $this->webservice_common_model->get_where_row("universities",$where);

		$page_data['university'] = $get_university;

	    $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/university/edit',$page_data);

    	$this->load->view('admin/includes/footer');

		

	}

	public function university_delete()

	{

		$admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == "")

		{

			redirect('Admin');

		}

		$id = $this->input->post('id');

		

		

		$update = $this->db->query('DELETE FROM universities WHERE id="'.$id.'"');

		if($update > 0)

		{

			$response['success']='1';	

			$response['message']="Delete done successfully."; 

		}

		else

		{

			$response['success']='0';	

			$response['message']="Not update";

		}

		echo  json_encode($response);

	}

		



/*----------------------------------------Course -------------------------------------*/

	public function course_list()

	{

	   $vendor_id=$this->uri->segment(3);

	 

	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == ""){	redirect('Admin');}

		$sql_course =$this->db->query('SELECT * FROM courses order by id DESC');

		$page_data['course_list'] = $sql_course->result();

	

		

		

	    $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/course/list',$page_data);

    	$this->load->view('admin/includes/footer');

	}

	

	public function course_add()

	{

		$now = date("Y-m-d H:i:s");

		

	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == "")

		{

			redirect('Admin');

		}

		if($this->input->post()){

			$course_name=$this->input->post('course_name');

			$description=$this->input->post('description');

			

			

			

			$coursedata = array(

			        'course_name'	=>	$course_name,

					'description'	=>	$description

					);

			$this->db->insert('courses',$coursedata);

			$course_id=$this->db->insert_id();

			if($course_id > 0){ $this->session->set_flashdata('success', 'Course Created successfuly.');}	else{$this->session->set_flashdata('error', 'Not Added');}

			redirect("Admin/course_list");

		}  

	     $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/course/add');

    	$this->load->view('admin/includes/footer');

	}

	public function edit_course()

	{

		$now = date("Y-m-d H:i:s");

		$id = $this->uri->segment(3);

		

	    $admin_admin = $this->session->userdata('admin_id');

		

		if($admin_admin == "")

		{

			redirect('Admin');

		}

		if($this->input->post())

		{

		  	$course_name=$this->input->post('course_name');

			$description=$this->input->post('description');

		  

			

			

				$coursedata = array(

			        'course_name'	=>	$course_name,

					'description'	=>	$description

					);



			

			$course_id = array("id"=>$id);

			$update = $this->db->update('courses',$coursedata,$course_id);

			if($update > 0)

			{

				 $this->session->set_flashdata('success', 'Course  Updated successfully.');

			}

			else

			{

				$this->session->set_flashdata('error', 'Not Updated');

			}

			redirect("Admin/course_list");

		}

		$where = array("id" =>$this->uri->segment('3'));

		$get_course = $this->webservice_common_model->get_where_row("courses",$where);

		$page_data['course'] = $get_course;

	    $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/course/edit',$page_data);

    	$this->load->view('admin/includes/footer');

		

	}

	public function course_delete()

	{

		$admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == "")

		{

			redirect('Admin');

		}

		$id = $this->input->post('id');

		

		

		$update = $this->db->query('DELETE FROM courses WHERE id="'.$id.'"');

		if($update > 0)

		{

			$response['success']='1';	

			$response['message']="Delete done successfully."; 

		}

		else

		{

			$response['success']='0';	

			$response['message']="Not update";

		}

		echo  json_encode($response);

	}

	





/*----------------------------------------Testimonial -------------------------------------*/

	public function testimonial_list()

	{

	   $vendor_id=$this->uri->segment(3);

	 

	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == ""){	redirect('Admin');}

		$sql_testi =$this->db->query('SELECT * FROM testimonials order by id DESC');

		$page_data['testimonial_ist'] = $sql_testi->result();

	

		

		

	    $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/testimonial/list',$page_data);

    	$this->load->view('admin/includes/footer');

	}

	

	public function add_testimonial()

	{

		$now = date("Y-m-d H:i:s");

		 $vendor_id=$this->uri->segment(3);

	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == "")

		{

			redirect('Admin');

		}

		if($this->input->post()){

			$name=$this->input->post('name');

			$designation = $this->input->post('designation');

			$course=$this->input->post('course');

			$message=$this->input->post('message');

			if(is_uploaded_file($_FILES['image']['tmp_name'])){

						$image=rand(0,9999).$_FILES['image']['name'];

						@move_uploaded_file($_FILES['image']['tmp_name'],'uploads/testimonials/'.$image);

					}else{

						$image="";

					}

			

			$testimonial_data = array(

			        'name'			=>	$name,

					'designation'	=>	$designation,

				   'course'			=>	$course,

				   'message'		=>	$message,

				   'image'			=> $image

				

					);

			$this->db->insert('testimonials',$testimonial_data);

			$testimonial_id=$this->db->insert_id();

			if($testimonial_id > 0){ $this->session->set_flashdata('success', 'Testimonial Created successfuly.');}	else{$this->session->set_flashdata('error', 'Not Added');}

			redirect("Admin/testimonial_list/".$vendor_id);

		}  

	     $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/testimonial/add');

    	$this->load->view('admin/includes/footer');

	}

	public function edit_testimonial()

	{

		$now = date("Y-m-d H:i:s");

		$id = $this->uri->segment(3);

		 $vendor_id=$this->uri->segment(4);

	    $admin_admin = $this->session->userdata('admin_id');

		

		if($admin_admin == "")

		{

			redirect('Admin');

		}

		if($this->input->post())

		{

		   $name=$this->input->post('name');

		   $designation = $this->input->post('designation');

			$course=$this->input->post('course');

			$message=$this->input->post('message');

			if(is_uploaded_file($_FILES['image']['tmp_name']))

			{

  				$image=rand(0,9999).$_FILES['image']['name'];

				move_uploaded_file($_FILES['image']['tmp_name'],'uploads/testimonials/'.$image);

				if(is_file('uploads/testimonials/'.$_REQUEST['old_image'])){ unlink('uploads/testimonials/'.$_REQUEST['old_image']);}

				 }else{

					$image=$_REQUEST['old_image'];

		   	}

			

			

			$testimonial_data = array(

			        'name'			=>	$name,

					'designation'			=>	$designation,

				   'course'			=>	$course,

				   'message'		=>	$message,

				   'image'			=> $image

				

					);



			

			$testimonial_id = array("id"=>$id);

			$update = $this->db->update('testimonials',$testimonial_data,$testimonial_id);

			if($update > 0)

			{

				 $this->session->set_flashdata('success', 'Testimonial  Updated successfully.');

			}

			else

			{

				$this->session->set_flashdata('error', 'Not Updated');

			}

			redirect("Admin/testimonial_list/".$vendor_id);

		}

		$where = array("id" =>$this->uri->segment('3'));

		$get_testimonial = $this->webservice_common_model->get_where_row("testimonials",$where);

		$page_data['testimonial'] = $get_testimonial;

	    $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/testimonial/edit',$page_data);

    	$this->load->view('admin/includes/footer');

		

	}

	public function delete_testimonial()

	{

		$admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == "")

		{

			redirect('Admin');

		}

		$id = $this->input->post('id');

		

		

		$update = $this->db->query('DELETE FROM testimonials WHERE id="'.$id.'"');

		if($update > 0)

		{

			$response['success']='1';	

			$response['message']="Delete done successfully."; 

		}

		else

		{

			$response['success']='0';	

			$response['message']="Not update";

		}

		echo  json_encode($response);

	}

	

	

/*----------------------------------------counselor -------------------------------------*/

	public function counselor_list()

	{

	   $vendor_id=$this->uri->segment(3);

	 

	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == ""){	redirect('Admin');}

		$sql_testi =$this->db->query('SELECT * FROM counselors order by id DESC');

		$page_data['counselor_list'] = $sql_testi->result();

	

		

		

	    $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/counselor/list',$page_data);

    	$this->load->view('admin/includes/footer');

	}

	

	public function add_counselor()

	{

		$now = date("Y-m-d H:i:s");

		 $vendor_id=$this->uri->segment(3);

	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == "")

		{

			redirect('Admin');

		}

		if($this->input->post()){

			$name=$this->input->post('name');

			$email=$this->input->post('email');

			$mobile=$this->input->post('mobile');

			$university=$this->input->post('university');

			$about=$this->input->post('about');

			if(is_uploaded_file($_FILES['image']['tmp_name'])){

						$image=rand(0,9999).$_FILES['image']['name'];

						@move_uploaded_file($_FILES['image']['tmp_name'],'uploads/counselors/'.$image);

					}else{

						$image="";

					}

			

			$counselordata = array(

			        'name'			=>	$name,

				   'email'			=>	$email,

				   'mobile'			=>	$mobile,

				   'university'		=>	$university,

				   'about'			=>	$about,

				   'image'			=> $image

				

					);

			$this->db->insert('counselors',$counselordata);

			$testimonial_id=$this->db->insert_id();

			if($testimonial_id > 0){ $this->session->set_flashdata('success', 'Counselor Created successfuly.');}	else{$this->session->set_flashdata('error', 'Not Added');}

			redirect("Admin/counselor_list/".$vendor_id);

		}  

	     $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/counselor/add');

    	$this->load->view('admin/includes/footer');

	}

	public function edit_counselor()

	{

		$now = date("Y-m-d H:i:s");

		$id = $this->uri->segment(3);

		 $vendor_id=$this->uri->segment(4);

	    $admin_admin = $this->session->userdata('admin_id');

		

		if($admin_admin == "")

		{

			redirect('Admin');

		}

		if($this->input->post())

		{

		 $name=$this->input->post('name');

			$email=$this->input->post('email');

			$mobile=$this->input->post('mobile');

			$university=$this->input->post('university');

			$about=$this->input->post('about');

			if(is_uploaded_file($_FILES['image']['tmp_name']))

			{

  				$image=rand(0,9999).$_FILES['image']['name'];

				move_uploaded_file($_FILES['image']['tmp_name'],'uploads/counselors/'.$image);

				if(is_file('uploads/testimonials/'.$_REQUEST['old_image'])){ unlink('uploads/counselors/'.$_REQUEST['old_image']);}

				 }else{

					$image=$_REQUEST['old_image'];

		   	}

			

			

			$counselordata = array(

			        'name'			=>	$name,

				   'email'			=>	$email,

				   'mobile'			=>	$mobile,

				   'university'		=>	$university,

				   'about'			=>	$about,

				   'image'			=> $image

				

					);



			

			$counselor_id = array("id"=>$id);

			$update = $this->db->update('counselors',$counselordata,$counselor_id);

			if($update > 0)

			{

				 $this->session->set_flashdata('success', 'Counselor  Updated successfully.');

			}

			else

			{

				$this->session->set_flashdata('error', 'Not Updated');

			}

			redirect("Admin/counselor_list/".$vendor_id);

		}

		$where = array("id" =>$this->uri->segment('3'));

		$get_testimonial = $this->webservice_common_model->get_where_row("counselors",$where);

		$page_data['counselor'] = $get_testimonial;

	    $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/counselor/edit',$page_data);

    	$this->load->view('admin/includes/footer');

		

	}

	public function delete_counselor()

	{

		$admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == "")

		{

			redirect('Admin');

		}

		$id = $this->input->post('id');

		

		

		$update = $this->db->query('DELETE FROM counselors WHERE id="'.$id.'"');

		if($update > 0)

		{

			$response['success']='1';	

			$response['message']="Delete done successfully."; 

		}

		else

		{

			$response['success']='0';	

			$response['message']="Not update";

		}

		echo  json_encode($response);

	}



	public function contact_us()

	{

	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == ""){	redirect('Admin');}

		

		$this->db->select('*');

		$this->db->from('cms');

		$this->db->where('page_name','contact-us');

		$query = $this->db->get();

		$data['cms'] = $query->row();

		if($this->input->post()){

		

		if(is_uploaded_file($_FILES['image']['tmp_name']))

			{

  				$image=rand(0,9999).$_FILES['image']['name'];

				move_uploaded_file($_FILES['image']['tmp_name'],'uploads/cms/'.$image);

				if(is_file('uploads/cms/'.$_REQUEST['old_image'])){ unlink('uploads/cms/'.$_REQUEST['old_image']);}

				 }else{

					$image=$_REQUEST['old_image'];

		   	}

			

		$title = $this->input->post('title');

		$content = base64_encode($this->input->post('content'));

		$contact = $this->input->post('contact');

		$whatsapp_no = $this->input->post('whatsapp_no');

		$email = $this->input->post('email');

		$address = $this->input->post('address');
		
		$metaTitle = $this->input->post('metaTitle');
		
        $metaDescription = $this->input->post('metaDescription');
        
        $metaKeyword = $this->input->post('metaKeyword');

		

			$cmsdata=array(

			   'title'=>$title,

			   'content'=>$content,

			   'contact'=>$contact,

			   'whatsapp_no'=>$whatsapp_no,

			   'email'=>$email,

			   'address'=>$address,

			   'image'=>$image,
			     
			   'meta_title' => $metaTitle,
			     
			   'meta_Description' => $metaDescription,
			     
			   'meta_keyword' => $metaKeyword

			);

			//print_r($cmsdata); die;

			$this->db->where('page_name','contact_us');

			$this->db->update('cms',$cmsdata);

			

			

			 $this->session->set_flashdata('success', 'Contact Us  Updated successfully.');

			 redirect(base_url('admin/contact_us'));

		}

		

	    $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/cms/contact_us',$data);

    	$this->load->view('admin/includes/footer');

	}

	

	public function terms_conditions(){
	    
	    $admin_admin = $this->session->userdata('admin_id');
		if($admin_admin == ""){	redirect('Admin');}

		$this->db->select('*');
		$this->db->from('cms');
		$this->db->where('page_name','terms');
		$query = $this->db->get();
		$data['cms'] = $query->row();

		if($this->input->post()){
		    
			$cmsdata = array(
                'content' => base64_encode($this->input->post('content')),
                'meta_title' => $this->input->post('metaTitle'),
                'meta_Description' => $this->input->post('metaDescription'),
                'meta_keyword' => $this->input->post('metaKeyword')
			);

			$this->db->where('page_name','terms_conditions');
			$this->db->update('cms',$cmsdata);
            $this->session->set_flashdata('success', 'Terms & Conditions Updated successfully.');
            redirect(base_url('admin/terms_conditions'));
		}

	    $this->load->view('admin/includes/header');
	    $this->load->view('admin/includes/left');
    	$this->load->view('admin/cms/terms_conditions',$data);
    	$this->load->view('admin/includes/footer');
	}	

    public function privacy_policy(){

	    $admin_admin = $this->session->userdata('admin_id');
		if($admin_admin == ""){	redirect('Admin');}
		
		$this->db->select('*');
		$this->db->from('cms');
		$this->db->where('page_name','privacy');
		$query = $this->db->get();
		$data['cms'] = $query->row();
		
		if($this->input->post()){
			$cmsdata = array(
                'content' => base64_encode($this->input->post('content')),
                'meta_title' => $this->input->post('metaTitle'),
                'meta_Description' => $this->input->post('metaDescription'),
                'meta_keyword' => $this->input->post('metaKeyword')
			);

			$this->db->where('page_name','privacy');
			$this->db->update('cms',$cmsdata);
			$this->session->set_flashdata('success', 'Privacy policy Updated successfully.');
			redirect(base_url('admin/privacy_policy'));
		}

	    $this->load->view('admin/includes/header');
	    $this->load->view('admin/includes/left');
    	$this->load->view('admin/cms/privacy_policy',$data);
    	$this->load->view('admin/includes/footer');
	}

    public function cancellation_policy(){
        
	    $admin_admin = $this->session->userdata('admin_id');
		if($admin_admin == ""){	redirect('Admin');}

		$this->db->select('*');
        $this->db->from('cms');
		$this->db->where('page_name','cancellation');
		$query = $this->db->get();
		$data['cms'] = $query->row();

		if($this->input->post()){
			$cmsdata=array(
                'content' => base64_encode($this->input->post('content')),
                'meta_title' => $this->input->post('metaTitle'),
                'meta_Description' => $this->input->post('metaDescription'),
                'meta_keyword' => $this->input->post('metaKeyword')
            );
            
			$this->db->where('page_name','cancellation');
			$this->db->update('cms',$cmsdata);
			$this->session->set_flashdata('success', 'Cancellation Policy Updated successfully.');
            redirect(base_url('admin/cancellation_policy'));
		}

	    $this->load->view('admin/includes/header');
	    $this->load->view('admin/includes/left');
    	$this->load->view('admin/cms/cancellation_policy',$data);
    	$this->load->view('admin/includes/footer');
	}



	// Table : tbl_plan
	// Pricing - Free listing
    public function pricing_free_listing()

	{
	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == ""){	redirect('Admin');}


		$this->db->select('*');
		$this->db->from('tbl_plan');
		$this->db->where('id','1');  // id = 1  means Free pricing page
		$query = $this->db->get();

		$data['id'] = 1;
		$data['cms'] = $query->row();

		if($this->input->post()){

			$short_content = $this->input->post('short_desc');
			$long_content = base64_encode($this->input->post('content'));

			$cmsdata=array(

			     'short_desc' => $short_content,
			     'long_desc'  => $long_content,
			     'amount'     => $this->input->post('amount')

			 );

			//print_r($cmsdata); die;

			$this->db->where('id','1');

			$this->db->update('tbl_plan',$cmsdata);

		 	
		 	$this->session->set_flashdata('success', 'Pricing free listing Updated successfully.');

			redirect(base_url('admin/pricing_free_listing'));

		}

	    $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/cms/pricing_free',$data);

    	$this->load->view('admin/includes/footer');

	}


	// Pricing - Featured listing
    public function pricing_featured_listing()

	{

	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == ""){	redirect('Admin');}


		$this->db->select('*');

		$this->db->from('tbl_plan');

		$this->db->where('id','2');  // id = 1  means Free pricing page

		$query = $this->db->get();

		$data['id'] = 2;

		$data['cms'] = $query->row();

		if($this->input->post()){

			$short_content = $this->input->post('short_desc');
			$long_content = base64_encode($this->input->post('content'));

			$cmsdata=array(

			     'short_desc' => $short_content,
			     'long_desc'  => $long_content,
			     'amount'     => $this->input->post('amount')

			 );

			//print_r($cmsdata); die;

			$this->db->where('id','2');

			$this->db->update('tbl_plan',$cmsdata);

		 	
		 	$this->session->set_flashdata('success', 'Pricing featured listing Updated successfully.');

			redirect(base_url('admin/pricing_featured_listing'));

		}

	    $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/cms/pricing_free',$data);

    	$this->load->view('admin/includes/footer');

	}


	// Pricing - Hot & Happening listing
    public function pricing_hot_listing()

	{

	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == ""){	redirect('Admin');}


		$this->db->select('*');

		$this->db->from('tbl_plan');

		$this->db->where('id','3');  // id = 1  means Free pricing page

		$query = $this->db->get();

		$data['id'] = 3;

		$data['cms'] = $query->row();

		if($this->input->post()){

			$short_content = $this->input->post('short_desc');
			$long_content = base64_encode($this->input->post('content'));

			$cmsdata=array(

			     'short_desc' => $short_content,
			     'long_desc'  => $long_content,
			     'amount'     => $this->input->post('amount'),
			     'website'    => $this->input->post('website')

			 );

			//print_r($cmsdata); die;

			$this->db->where('id','3');

			$this->db->update('tbl_plan',$cmsdata);

		 	
		 	$this->session->set_flashdata('success', 'Pricing hot listing Updated successfully.');

			redirect(base_url('admin/pricing_hot_listing'));

		}

	    $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/cms/pricing_free',$data);

    	$this->load->view('admin/includes/footer');

	}

	
	
    
	

    public function about_us()

	{

	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == ""){	redirect('Admin');}

		

		$this->db->select('*');

		$this->db->from('cms');

		

		$this->db->where('page_name','about-us');

		$query = $this->db->get();

		$data['cms'] = $query->result();
		
		$this->db->select('*');

		$this->db->from('cms');
		
		$this->db->where('parent',$data['cms'][0]->id);

		$query = $this->db->get();

		$data['cms_sections'] = $query->result();

		if($this->input->post()){

		$content = base64_encode($this->input->post('content'));
		
			$cmsdata=array(

			     'content'=>$content

			 );

			//print_r($cmsdata); die;

			$this->db->where('page_name','about_us');
			

			$this->db->update('cms',$cmsdata);

			

			

			 $this->session->set_flashdata('success', 'About us Updated successfully.');

			 redirect(base_url('admin/about_us'));

		}

		

	    $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/cms/about_us',$data);

    	$this->load->view('admin/includes/footer');

	}
	

	public function about_us_add(){

		if($this->input->post()){

		   $title= $this->input->post('title');

		   $content = base64_encode($this->input->post('content'));

		    		if(is_uploaded_file($_FILES['image']['tmp_name'])){

								$image=rand(0,9999).$_FILES['image']['name'];

								@move_uploaded_file($_FILES['image']['tmp_name'],'uploads/about/'.$image);

							}else{

								$image="";

							}

			

			$this->db->query('INSERT INTO cms SET page_name="about_us", title="'.$title.'",content="'.$content.'",image="'.$image.'"');

			$this->session->set_flashdata('success', 'About us created successfully.');

					redirect('admin/about_us');

		}

        $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/cms/add_about');

    	$this->load->view('admin/includes/footer');

	}



	public function delete_about()

	{

		$admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == "")

		{

			redirect('Admin');

		}

		$id = $this->input->post('id');

		

		

		$update = $this->db->query('DELETE FROM cms WHERE id="'.$id.'"');

		if($update > 0)

		{

			$response['success']='1';	

			$response['message']="Delete done successfully."; 

		}

		else

		{

			$response['success']='0';	

			$response['message']="Not update";

		}

		echo  json_encode($response);

	}

					



	public function booking_requests()
	{

	   	$vendor_id=$this->uri->segment(3);
 

	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == ""){	redirect('Admin');}

		  $this->db->select('*,customer_bookings.dated as booking_date');

          $this->db->from('customer_bookings');
        
          $this->db->join('products', 'products.id = customer_bookings.product_id'); 
        
          $this->db->where('customer_bookings.is_accepted',1);
        
          $this->db->order_by('customer_bookings.dated', 'DESC'); 
        
          $query = $this->db->get();
        
          $page_data['request_list']= $query->result();
		

	    $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/booking/list',$page_data);

    	$this->load->view('admin/includes/footer');

	}





	public function website_free_trials()
	{

	   	$vendor_id=$this->uri->segment(3);
 

	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == ""){	redirect('Admin');}

		  $this->db->select('name, email, mobile, whatsapp, is_website_activated, trial_start_date');

          $this->db->from('users');
        
          $this->db->order_by('users.id', 'ASC'); 
          $this->db->where('is_website_activated', 1);
          $this->db->where('trial_start_date IS NOT NULL');
        
          $query = $this->db->get();
        
          $page_data['request_list']= $query->result();
		

	    $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/trials/list',$page_data);

    	$this->load->view('admin/includes/footer');

	}
	
	
	public function payments()
	{

	   	$vendor_id=$this->uri->segment(3);
 

	    $admin_admin = $this->session->userdata('admin_id');

		if($admin_admin == ""){	redirect('Admin');}

		  $this->db->select('name, email, mobile, whatsapp, is_website_activated, trial_start_date');

          $this->db->from('users');
        
          $this->db->order_by('users.id', 'ASC'); 
        
          $query = $this->db->get();
        
          $page_data['request_list']= $query->result();
		

	    $this->load->view('admin/includes/header');

	    $this->load->view('admin/includes/left');

    	$this->load->view('admin/trials/list',$page_data);

    	$this->load->view('admin/includes/footer');

	}
	
	
//     public function checkAdmin(){
//         $admin_admin = $this->session->userdata('admin_id');
// 		    if($admin_admin == ""){	redirect('Admin');}
//     }

//     public function viewPageData($page_name){
//         $admin_admin = $this->session->userdata('admin_id');
// 		if($admin_admin == ""){	redirect('Admin');}

// 		$this->db->select('*');
// 		$this->db->from('cms');
// 		$this->db->where('page_name',$page_name);
// 		$query = $this->db->get();
// 		$data['cms'] = $query->result();
		
// 		$this->db->select('*');
// 		$this->db->from('cms');
// 		$this->db->where('parent',$data['cms'][0]->id);
// 		$query = $this->db->get();
//         $data['cms_sections'] = $query->result();

// 	    $this->load->view('admin/includes/header');
//         $this->load->view('admin/includes/left');
//     	$this->load->view('admin/cms/'.$page_name,$data);
//     	$this->load->view('admin/includes/footer');
//     }
    
//     public function sell(){
//         viewPageData('sell');
//     }
    
    public function sell()
	{
	   // checkAdmin();
	    $admin_admin = $this->session->userdata('admin_id');
		if($admin_admin == ""){	redirect('Admin');}

		$this->db->select('*');
		$this->db->from('cms');
		$this->db->where('page_name','sell');
		$query = $this->db->get();
		$data['cms'] = $query->result();
		
		$this->db->select('*');
		$this->db->from('cms');
		$this->db->where('parent',$data['cms'][0]->id);
		$query = $this->db->get();
        $data['cms_sections'] = $query->result();

	    $this->load->view('admin/includes/header');
        $this->load->view('admin/includes/left');
    	$this->load->view('admin/cms/sell',$data);
    	$this->load->view('admin/includes/footer');
	}
	
	public function home()
	{
	    $admin_admin = $this->session->userdata('admin_id');
		if($admin_admin == ""){	redirect('Admin');}

		$this->db->select('*');
		$this->db->from('cms');
		$this->db->where('page_name','home');

		$query = $this->db->get();
		$data['cms'] = $query->result();
		$this->db->select('*');
		$this->db->from('cms');
		
		$this->db->where('parent',$data['cms'][0]->id);
		$query = $this->db->get();
		$data['cms_sections'] = $query->result();

	    $this->load->view('admin/includes/header');
	    $this->load->view('admin/includes/left');
    	$this->load->view('admin/cms/home',$data);
    	$this->load->view('admin/includes/footer');
	}
	
	public function partner_with_us()
	{
	    $admin_admin = $this->session->userdata('admin_id');
		if($admin_admin == ""){	redirect('Admin');}

		$this->db->select('*');
		$this->db->from('cms');
		$this->db->where('page_name','partner-with-us');

		$query = $this->db->get();
		$data['cms'] = $query->result();
		$this->db->select('*');
		$this->db->from('cms');
		
		$this->db->where('parent',$data['cms'][0]->id);
		$query = $this->db->get();
		$data['cms_sections'] = $query->result();

	    $this->load->view('admin/includes/header');
	    $this->load->view('admin/includes/left');
    	$this->load->view('admin/cms/partner_with_us',$data);
    	$this->load->view('admin/includes/footer');
	}
	
	
	public function pricing()
	{
	    $admin_admin = $this->session->userdata('admin_id');
		if($admin_admin == ""){	redirect('Admin');}

		$this->db->select('*');
		$this->db->from('cms');
		$this->db->where('page_name','pricing');
		$query = $this->db->get();
		$data['cms'] = $query->result();
		
		$this->db->select('*');
		$this->db->from('cms');
		$this->db->where('parent',$data['cms'][0]->id);
		$query = $this->db->get();
		$data['cms_sections'] = $query->result();

	    $this->load->view('admin/includes/header');
	    $this->load->view('admin/includes/left');
    	$this->load->view('admin/cms/pricing',$data);
    	$this->load->view('admin/includes/footer');
	}
	
	public function vendor_payments(){
	    $admin_admin = $this->session->userdata('admin_id');
		if($admin_admin == ""){	redirect('Admin');}
        
        $this->db->select('users.*, tbl_payments.payment_user, tbl_payments.payment_for, cities.city')->from('users')->join('tbl_payments', 'users.id = tbl_payments.payment_user');
        $this->db->join('cities','cities.id = users.city');
        $this->db->where('users.user_role', 1);
        $this->db->group_by('tbl_payments.payment_user');
        $query = $this->db->get();
        $page_data['request_list']= $query->result();

	    $this->load->view('admin/includes/header');
	    $this->load->view('admin/includes/left');
    	$this->load->view('admin/vendorpayments/list',$page_data);
    	$this->load->view('admin/includes/footer');
	}
	
	public function vendor_payment_details($id, $payment_for){
	    //echo $id.'---'.$payment_for;
	    $admin_admin = $this->session->userdata('admin_id');
		if($admin_admin == ""){	redirect('Admin');}
        
        $this->db->select('*')->from('tbl_payments');
        $this->db->where('payment_user', $id);
        $this->db->where('payment_for', $payment_for);
        $query = $this->db->get();
        $page_data['request_list']= $query->result();
        
        $this->db->select('*')->from('users');
        $this->db->where('id', $id);
        $query = $this->db->get();
        $page_data['vendor_details']= $query->result();
        $page_data['payment_for'] = $payment_for;

	    $this->load->view('admin/includes/header');
	    $this->load->view('admin/includes/left');
    	$this->load->view('admin/vendorpayments/verified_payment_list',$page_data);
    	$this->load->view('admin/includes/footer');
	}
	
	
	public function seo_page($page_name, $redirect_url){
	    if($this->input->post()){
    		$metaTitle = $this->input->post('metaTitle');
            $metaDescription = $this->input->post('metaDescription');
            $metaKeyword = $this->input->post('metaKeyword');
			$cmsdata=array(
                'meta_title' => $metaTitle,
                'meta_Description' => $metaDescription,
                'meta_keyword' => $metaKeyword
			);

			$this->db->where('page_name',$page_name);
			$this->db->where('parent', 0);
			$this->db->update('cms',$cmsdata);
			$this->session->set_flashdata('success', 'SEO Details Updated successfully.');
            redirect(base_url('admin/'.$redirect_url));
	    }
        
    }
	
	public function edit_content($id, $page_name){
	    
		if($this->input->post()){
		    $update_arr = array();
		    $image = '';
		    $contentrow = $this->db->get_where('cms', array('id' => $id))->result();
		    
		    if($contentrow[0]->parent == 0){
		        $contentrowsections = $this->db->get_where('cms', array('parent' => $contentrow[0]->id))->result(); 
		        if(count($contentrowsections) > 0){
		            $update_arr = array(
                        'meta_title' => $this->input->post('meta_title'),
                        'meta_Description' => $this->input->post('meta_Description'),
                        'meta_keyword' => $this->input->post('meta_keyword')
		            );
		       }else{
		            if(is_uploaded_file($_FILES['image']['tmp_name'])){
                        $image=rand(0,9999).$_FILES['image']['name'];
                    	move_uploaded_file($_FILES['image']['tmp_name'],'uploads/cms/'.$image);
                    	if(is_file('uploads/cms/'.$_REQUEST['old_image'])){ unlink('uploads/cms/'.$_REQUEST['old_image']);}
                    }else{
                    	$image=$_REQUEST['old_image'];
                    }
                    
		            $update_arr = array(
		                        'title' => $this->input->post('title'),
                                'content'=>base64_encode($this->input->post('content')),
                                'image' => $image,
                                'img_alt' => $this->input->post('img_alt'),
                                'meta_title' => $this->input->post('meta_title'),
                                'meta_Description' => $this->input->post('meta_Description'),
                                'meta_keyword' => $this->input->post('meta_keyword')
		            );
		       }
		    }else{
		        if(is_uploaded_file($_FILES['image']['tmp_name'])){
                    $image=rand(0,9999).$_FILES['image']['name'];
                	move_uploaded_file($_FILES['image']['tmp_name'],'uploads/cms/'.$image);
                	if(is_file('uploads/cms/'.$_REQUEST['old_image'])){ unlink('uploads/cms/'.$_REQUEST['old_image']);}
                }else{
                    $image=$_REQUEST['old_image'];
                }
                
		        $update_arr = array(
	                        'title' => $this->input->post('title'),
                            'content'=>base64_encode($this->input->post('content')),
                            'image' => $image,
                            'img_alt' => $this->input->post('img_alt')
		        );
		    }
		    $this->db->where('id', $id);
            $this->db->update('cms', $update_arr);
		    
			$this->session->set_flashdata('success', 'Content updated successfully.');
			redirect('admin/'.$page_name);
		}

        $where = array("id" =>$this->uri->segment('3'));
        $get_cms = $this->webservice_common_model->get_where_row("cms",$where);
		$page_data['cms'] = $get_cms;

        $this->load->view('admin/includes/header');
	    $this->load->view('admin/includes/left');
    	$this->load->view('admin/cms/edit_content',$page_data);
    	$this->load->view('admin/includes/footer');

	}




} 