<?php
defined('BASEPATH') OR exit('No direct script access allowed');
error_reporting(1);
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: GET, OPTIONS");
class Common extends CI_Controller {

	
	public function __construct()
    {
        parent::__construct();
 
        // load Session Library
        $this->load->library('session');
		$this->load->library('encryption');
        //load model
		
		$this->load->model('webservice_common_model','common');
		
		$this->load->database(); 
        // load url helper
        $this->load->helper('url');
    }
	
	public function GetVehicleList(){
	 $query=$this->db->query('SELECT * FROM vehicle_master  ORDER BY vehicle_id DESC');
	  $result=$query->result();
	  if(empty($result)){
	         $data['code']=0;
			$data['message']='No anehicle found.';
			echo json_encode($data);
	  }else{
	      
	         $data['code']=1;
			$data['message']='vehcle list available';
			$data['vehicle_list']=$result;
			echo json_encode($data);
	  }
	}




}
