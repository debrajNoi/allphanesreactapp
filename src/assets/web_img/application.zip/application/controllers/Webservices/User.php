<?php
defined('BASEPATH') OR exit('No direct script access allowed');
error_reporting(1);
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: GET,POST, OPTIONS");
class User extends CI_Controller {

	
	public function __construct()
    {
        parent::__construct();
        $this->load->library('session');
       	$this->load->model('webservice_common_model','common');
		$this->load->database(); 
        $this->load->helper('url');
    }
	
	
	public function login(){
	  $mobile = $this->input->post('mobile');
	  $password = $this->input->post('password');
	  
	  if($mobile=='' || $password==''){
	     $data['code']=0;
		 $data['message']='Required all fields';
		 
		 echo json_encode($data);
		 
	  }else{
	     $chk= $this->db->query('SELECT * FROM users WHERE mobile="'.$mobile.'" AND password="'.md5($password).'"');
		 if($chk->num_rows()>0){
		    $row=$chk->row();
			$data['code']=1;
			$data['message']='Login Successfully.';
			$data['data']=$row;
		 	
		 	echo json_encode($data);
		 }else{
		   	$data['code']=0;
			$data['message']='Incorrect login details';
		 	echo json_encode($data);
		 }
	  }
	  
	}
	
    function create_party(){
	     $user_id= $this->input->post('user_id');
		 $party_name= $this->input->post('party_name');
		 $gst_no= $this->input->post('gst_no');
		 $address= $this->input->post('address');
		 $mobile= $this->input->post('mobile');
		 $shop_name= $this->input->post('shop_name');
		 if($user_id=='' || $party_name=='' || $gst_no=='' ||  $address=='' || $mobile=='' || $shop_name==''){
		   	$data['code']=0;
			$data['message']='Required all fields.';
		 	echo json_encode($data);
		 }else{
		    $chk= $this->db->query('SELECT * FROM party_info WHERE mobile="'.$mobile.'"');
			if($chk->num_rows()>0){
			    $data['code']=0;
				$data['message']='Mobile number already exist';
		 	    echo json_encode($data);
			}else{
			  $partydata=array(
			   'creator_id' =>	$user_id,
			   'party_name' =>	$party_name,
			   'gst_no' 	=>	$gst_no,
			   'address' 	=>	$address,
			   'mobile' 	=>	$mobile,
			   'shop_name' =>	$shop_name
			    );
				$this->db->insert('party_info',$partydata);
				 $data['code']=1;
				$data['message']='Party Created successfully.';
		 	    echo json_encode($data);
			
			}
		 
		 }
		 
	}
	
	
  function update_party(){
	     $party_id= $this->input->post('party_id');
		 $party_name= $this->input->post('party_name');
		 $gst_no= $this->input->post('gst_no');
		 $address= $this->input->post('address');
		 $mobile= $this->input->post('mobile');
		 $shop_name= $this->input->post('shop_name');
		 if($party_id=='' || $party_name=='' || $gst_no=='' ||  $address=='' || $mobile=='' || $shop_name==''){
		   	$data['code']=0;
			$data['message']='Required all fields.';
		 	echo json_encode($data);
		 }else{
		    
			  $partydata=array(
			   'party_name' =>	$party_name,
			   'gst_no' 	=>	$gst_no,
			   'address' 	=>	$address,
			   'mobile' 	=>	$mobile,
			   'shop_name' =>	$shop_name
			    );
				$where=array('party_id'=>$party_id);
				$this->db->update('party_info',$partydata,$where);
				 $data['code']=1;
				$data['message']='Party info updated successfully.';
		 	    echo json_encode($data);
			
				 
		 }
		 
	}
	

  function get_party_list(){
    $user_id = $this->input->post('user_id');
	 if($user_id==''){
	    	$data['code']=0;
			$data['message']='Required User Id.';
		 	echo json_encode($data);
	 }else{
	     $sql_get= $this->db->query('SELECT * FROM party_info WHERE creator_id="'.$user_id.'"');
		 
		 if($sql_get->num_rows()>0){
		   $party=$sql_get->result();
		    	$data['code']=1;
				$data['message']='Party list available.';
				$data['data']=$party;
		 	    echo json_encode($data);
		 }else{
		   $data['code']=0;
				$data['message']='No any party found.';
		 	    echo json_encode($data);
		 }
	 }
  }
  
  function Update_profile(){
    $user_id = $this->input->post('user_id');
	$name = $this->input->post('name');
	$mobile = $this->input->post('mobile');
	
	if($user_id=='' || $name=='' || $mobile=='' ){
	    	$data['code']=0;
			$data['message']='Required all fields.';
		 	echo json_encode($data);
	 }else{
	   $this->db->query('UPDATE users SET name="'.$name.'",mobile="'.$mobile.'" WHERE user_id="'.$user_id.'"');
	        $data['code']=1;
			$data['message']='Profile updated successfully.';
		 	echo json_encode($data);
	 }
  }
  
  
  
  function create_bill(){
    
	$party_id = $this->input->post('party_id');
	$vehicle_no = $this->input->post('vehicle_no');
	$invoice_no = $this->input->post('invoice_no');
	$bill_date = date('Y-m-d',strtotime($this->input->post('bill_date')));
	$image = $this->input->post('image');
	
	
	if($party_id=='' || $invoice_no=='' || $vehicle_no=='' || $bill_date=='' ){
	    	$data['code']=0;
			$data['message']='Required all fields.';
		 	echo json_encode($data);
	 }else{
	     $chk=$this->db->query('SELECT * FROM bills WHERE invoice_no="'.$invoice_no.'"');
		 if($chk->num_rows()>0){
		    $data['code']=0;
			$data['message']='Invoice no already created';
		 	echo json_encode($data);
		 }else{
					if(is_uploaded_file($_FILES['image']['tmp_name'])){
									$image=rand(0,9999).$_FILES['image']['name'];
									@move_uploaded_file($_FILES['image']['tmp_name'],'uploads/bills/'.$image);
								}else{
									$image="";
								}
				
			$this->db->query('INSERT INTO bills SET invoice_no="'.$invoice_no.'", party_id="'.$party_id.'",vehicle_no	="'.$vehicle_no.'",	bill_date="'.$bill_date.'",	image="'.$image.'"');
				
					
	        $data['code']=1;
			$data['message']='Bill created successfully.';
		 	echo json_encode($data);
	 }
	 
	 }
  }

 
 public function GetBillList(){
   $party_id=$this->input->post('party_id');
   $bill_date = $this->input->post('bill_date');
   $invoice_no = $this->input->post('invoice_no');
   
   if($party_id=='' &&    $bill_date=='' && $invoice_no==''){
      
	  
	 $this->db->select('bills.bill_id as bill_id,bills.party_id as party_id,party_info.party_name as party_name,bills.vehicle_no as vehicle_no,bills.invoice_no as invoice_no,bills.bill_date as bill_date');
	$this->db->from('bills');
	$this->db->join('party_info', 'party_info.party_id = bills.party_id');
	$this->db->order_by('bills.bill_id','DESC');
	//$this->db->where(array('category.id' => 10));
     $query = $this->db->get();
	  $result=$query->result();
	        $data['code']=1;
			$data['message']='Bill List available.';
			$data['bill_list']=$result;
		 	echo json_encode($data);
   }
   
   if($bill_date!='' && $party_id!=''){
        $this->db->select('bills.bill_id as bill_id,bills.party_id as party_id,party_info.party_name as party_name,bills.vehicle_no as vehicle_no,bills.invoice_no as invoice_no,bills.bill_date as bill_date');
		$this->db->from('bills');
		$this->db->join('party_info', 'party_info.party_id = bills.party_id');
		$this->db->where(array('bills.bill_date' => $bill_date,'bills.party_id'=>$party_id));
		$this->db->order_by('bills.bill_id','DESC');
		 $query = $this->db->get();
	     $result=$query->result();
	        $data['code']=1;
			$data['message']='Bill List available.';
			$data['bill_list']=$result;
		 	echo json_encode($data);
   }
   
   
   if($bill_date!='' && $party_id==''){
        $this->db->select('bills.bill_id as bill_id,bills.party_id as party_id,party_info.party_name as party_name,bills.vehicle_no as vehicle_no,bills.invoice_no as invoice_no,bills.bill_date as bill_date');
		$this->db->from('bills');
		$this->db->join('party_info', 'party_info.party_id = bills.party_id');
		$this->db->where(array('bills.bill_date' => $bill_date));
		$this->db->order_by('bills.bill_id','DESC');
		$query = $this->db->get();
	    $result=$query->result();
	        $data['code']=1;
			$data['message']='Bill List available.';
			$data['bill_list']=$result;
		 	echo json_encode($data);
   }
   
   if($bill_date=='' && $party_id!=''){
       $this->db->select('bills.bill_id as bill_id,bills.party_id as party_id,party_info.party_name as party_name,bills.vehicle_no as vehicle_no,bills.invoice_no as invoice_no,bills.bill_date as bill_date');
		$this->db->from('bills');
		$this->db->join('party_info', 'party_info.party_id = bills.party_id');
		$this->db->where(array('bills.party_id' => $party_id));
		$this->db->order_by('bills.bill_id','DESC');
		$query = $this->db->get();
	    $result=$query->result();
	        $data['code']=1;
			$data['message']='Bill List available.';
			$data['bill_list']=$result;
		 	echo json_encode($data);
   }
   
   
   
 }
 
 public function view_bill_details(){
   $bill_id= $this->input->post('bill_id');
   if($bill_id==''){
    		 $data['code']=0;
			$data['message']='Provide bill id.';
			echo json_encode($data);
   }else{
        $query=$this->db->query('SELECT * FROM bills WHERE bill_id="'.$bill_id.'"');
	 if($query->num_rows()>0){
		  $row=$query->row();
		     $data['code']=1;
			$data['message']='Provide bill id';
			$data['image']=base_url('uploads/bills/'. $row->image);
			echo json_encode($data);
	}else{
		    $data['code']=0;
			$data['message']='Not Available';
			echo json_encode($data);
	     }
	 }
 }
 
 
 

}
