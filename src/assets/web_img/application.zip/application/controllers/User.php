<?php

error_reporting(1);

defined('BASEPATH') OR exit('No direct script access allowed');



class User extends CI_Controller {



	

	public function __construct()

    {

        parent::__construct();

        $this->load->library('email');

         $config = array (

                  'mailtype' => 'html',

                  'charset'  => 'utf-8',

                  'priority' => '1'

                   );

        $this->email->initialize($config);

        $this->load->library('session');

      	$this->load->database(); 

        $this->load->helper('url');

    }




  public function index()

	{

    	if($this->input->post('email'))
			{

				$username = $this->input->post('email');

				$password = md5($this->input->post('password'));

				$login_query = $this->db->query('select * from users where email ="'.$username.'" and password ="'.$password.'" and user_type = "customer"');

				if($login_query->num_rows() > 0)
				{

					$user_row = $login_query->row();

					if($user_row->status==0){

				    $this->session->set_flashdata('error', 'This Account is Deactivated. Please Contact with evdeamz Admin.');

						$this->load->view('users/login');

					}
					else if($user_row->email_verification==0){

			    	$this->session->set_flashdata('error', 'You are not verified via Email.');

						$this->load->view('users/login');
					}
					else{

						$this->session->set_userdata('admin_id', $user_row->id);

						$this->session->set_userdata('admin_email', $user_row->email);

						$this->session->set_userdata('admin_name', $user_row->name);

						$this->session->set_userdata('user_type', $user_row->user_type);

						$this->session->set_userdata('claim_product', '0');

						//$this->session->set_userdata('user_image', $user_row->image);

						redirect(base_url('user/ShowProfile'));

					}

				}
				else
				{

				// unsuccessfull login

				 $this->session->set_flashdata('error', 'Incorrect login details.');

			}

		}

    	$this->load->view('users/login');

    

	}


  

   

    

   

   

 public function ResetPassword(){

    $email=$this->input->post('email');

	

	   $chk=$this->db->query('SELECT * FROM users WHERE email="'.$email.'"');

	    if($chk->num_rows()>0){

		 $row=$chk->row(); 

		   

			$this->email->set_newline("\r\n");

			$this->email->from('goretoinfoways@gmail.com', 'Reset Password');

      		$data['user_id']=$row->user_id;

      		$to=$row->email;

      		$subject='Reset Password';

       		$this->email->to($to);



    		$this->email->subject($subject); // replace it with relevant subject 

    		$body = $this->load->view('reset_password_template',$data,TRUE);

    		$this->email->message($body);   

        	$this->email->send();

		        $this->session->set_flashdata('success', 'Password has been sent on '.$email);

		   

		}else{

		  $this->session->set_flashdata('error', $email.' is not registered with Goreto');

		}

	redirect(base_url('forgot-password'));

 }

 

 

 public function ShowProfile(){

 	$user_id = $this->session->userdata('admin_id');

  $where = array("id" =>$user_id);

		$get_user_details = $this->webservice_common_model->get_where_row("admin_users",$where);

		$page_data['profile'] = $get_user_details;

	    $this->load->view('users/includes/header');

	    $this->load->view('users/includes/left');

    	$this->load->view('users/my_profile',$page_data);

    	$this->load->view('users/includes/footer');



 		if($this->input->post())

		{

		    $id = $user_id;

			$name=$this->input->post('name');

			$email = $this->input->post('email');

			$phone = $this->input->post('phone');

			if(is_uploaded_file($_FILES['image']['tmp_name']))

			{

  				$image=rand(0,9999).$_FILES['image']['name'];

				move_uploaded_file($_FILES['image']['tmp_name'],'uploads/profile/'.$image);

				if(is_file('uploads/profile/'.$_REQUEST['old_image'])){ unlink('uploads/profile/'.$_REQUEST['old_image']);}

				 }else{

					$image=$_REQUEST['old_image'];

		   	}

			

			$userdata = array(

	        'name'			=>	$name,

					'email'			=>	$email,

					'phone'			=>	$phone,

					'image'			=>	$image,

					);

				$this->db->where('id',$id);

				$this->db->update('admin_users',$userdata);

			   $this->session->set_flashdata('success', 'Profile updated successfully.');

			  redirect("Admin/profile");

		}

}



 

 

 public function UpdateProfile(){

 $user=$this->session->userdata('userdata');

    if(is_uploaded_file($_FILES['image']['tmp_name']))

			{

  				$image=rand(0,9999).$_FILES['image']['name'];

				move_uploaded_file($_FILES['image']['tmp_name'],'uploads/users/'.$image);

				if(is_file('uploads/profile/'.$_REQUEST['old_image'])){ unlink('uploads/users/'.$_REQUEST['old_image']);}

				 }else{

					$image=$_REQUEST['old_image'];

		   	}

     $data=array(

	 		'first_name'	=>	$this->input->post('first_name'),

			'last_name'	=>	$this->input->post('last_name'),

			'email'	=>	$this->input->post('profile_email'),

			'mobile'	=>	$this->input->post('phone_number'),

			'address'	=>	$this->input->post('address'),

			'image'		=>	$image

			 );

		$this->db->where('user_id',$user['user_id']);

		$this->db->update('users',$data);

		 $this->session->set_flashdata('success', 'Profile updated successfully.');

		 redirect(base_url('dashboard'));

 }

 



 public function timeline(){

  $user=$this->session->userdata('userdata');

    $query=$this->db->query('SELECT * FROM timeline WHERE user_id="'.$user['user_id'].'" ORDER BY id ASC');

	 $data['timeline']= $query->result();

	

    $this->load->view('includes/header');

	 $this->load->view('timeline',$data);

	 $this->load->view('includes/footer');

 }

 

  public function create_timeline(){

    $user=$this->session->userdata('userdata');

   	$timeline_date=$this->input->post('timeline_date');

	$title=$this->input->post('title');

	$description=base64_encode($this->input->post('description'));

	$query=$this->db->query('INSERT INTO timeline SET user_id="'.$user['user_id'].'",timeline_date="'.$timeline_date.'",title="'.$title.'",description="'.$description.'"');

	  $this->session->set_flashdata('success', 'Timeline created successfully.');

	 redirect(base_url('timeline'));

 }



public function notification(){

	$get_notification = $this->webservice_common_model->GetNotificationList();

	$data['notification_list'] = $get_notification;

 	$this->load->view('includes/header');

	 $this->load->view('notification',$data);

	 $this->load->view('includes/footer');

}



public function courses(){

 $user=$this->session->userdata('userdata');

 $sql_selected_course=$this->db->query('SELECT * FROM users WHERE user_id="'.$user['user_id'].'"');

 $selected_course= $sql_selected_course->row();

  $search='FIND_IN_SET (course_id,"'.$selected_course->course.'")'; 

  

 

 $sql_lession=$this->db->query('SELECT * FROM lessions WHERE '.$search);

 $res=$sql_lession->result();

 

 

 

 

$get_notification = $this->webservice_common_model->GetNotificationList();

	$data['lessions'] = $res;

 	$this->load->view('includes/header');

	 $this->load->view('selected_course',$data);

	 $this->load->view('includes/footer');

}





public function my_plan(){

  $user=$this->session->userdata('userdata');

  $query=$this->db->query('SELECT * FROM user_plans WHERE user_id="'.$user['user_id'].'" AND remove_status=0 ORDER BY id DESC ');

	 $data['myplan']= $query->result();

	 $this->load->view('includes/header');

	 $this->load->view('my_plan',$data);

	 $this->load->view('includes/footer');

 }





public function Add_plan(){

 

  $user=$this->session->userdata('userdata');

   	$title=$this->input->post('title');

	$plan_date=$this->input->post('plan_date');

	$description=base64_encode($this->input->post('description'));

	 if(is_uploaded_file($_FILES['image']['tmp_name'])){

				$image=rand(0,9999).$_FILES['image']['name'];

			@move_uploaded_file($_FILES['image']['tmp_name'],'uploads/plans/'.$image);

		  	}else{

				$image="";

			}

			

		$plandata=array(

		  'user_id' =>	$user['user_id'],

		  'plan_title'	=>	$title,

		  'description'	=>	$description,

		  'plan_date'	=>	$plan_date,

		  'image'		=>	$image

		);

		

		

	$this->db->insert('user_plans',$plandata);

	   $this->session->set_flashdata('success', 'Plan created successfully.');

	   redirect(base_url('my-plan'));

}





public function update_plan(){

  $plan_id=$this->input->post('plan_id');

   $title=$this->input->post('title');

  $plan_date=$this->input->post('plan_date');

  $description=base64_encode($this->input->post('description'));

    if(is_uploaded_file($_FILES['image']['tmp_name']))

			{

  				$image=rand(0,9999).$_FILES['image']['name'];

				move_uploaded_file($_FILES['image']['tmp_name'],'uploads/plans/'.$image);

				if(is_file('uploads/plans/'.$_REQUEST['old_image'])){ unlink('uploads/plans/'.$_REQUEST['old_image']);}

				 }else{

					$image=$_REQUEST['old_image'];

		   	}

	$plandata=array(

		  'plan_title'	=>	$title,

		  'description'	=>	$description,

		  'plan_date'	=>	$plan_date,

		  'image'		=>	$image

		);

		

		$this->db->where('id',$plan_id);

		$this->db->update('user_plans',$plandata);

		$this->session->set_flashdata('success', 'Plan updated successfully.');

	   redirect(base_url('my-plan'));

  

}

  public function RemovePlan(){

    $plan_id=$this->input->post('plan_id');

	$sql_plan=$this->db->query('SELECT * FROM user_plans WHERE id="'.$plan_id.'"');

	$plan=$sql_plan->row();

	unlink('uploads/plans/'.$plan->image);

	$this->db->query('DELETE FROM user_plans WHERE id="'.$plan_id.'"');

	$this->session->set_flashdata('success', 'Plan Remove successfully.');

	   redirect(base_url('my-plan'));

  }

  

  public function my_gallery(){

     $user=$this->session->userdata('userdata');

	 if($this->input->get('category')){

	    

  	$query=$this->db->query('SELECT * FROM gallery WHERE user_id="'.$user['user_id'].'" AND category_id="'.$this->input->get('category').'" AND remove_status=0 ORDER BY id DESC ');

	}

	else if($this->input->get('subcategory')){

	$query=$this->db->query('SELECT * FROM gallery WHERE user_id="'.$user['user_id'].'" AND subcategory_id="'.$this->input->get('subcategory').'" AND remove_status=0 ORDER BY id DESC ');

	}else{

		$query=$this->db->query('SELECT * FROM gallery WHERE user_id="'.$user['user_id'].'" AND remove_status=0 ORDER BY id DESC ');

		}

	 $data['my_gallery']= $query->result();

	 $this->load->view('includes/header');

	 $this->load->view('my_gallery',$data);

	 $this->load->view('includes/footer');

  }

  

  public function Add_gallery(){

    $user=$this->session->userdata('userdata');

	$category_id = $this->input->post('category_id');

	$subcategory_id = $this->input->post('subcategory_id');

	$title = $this->input->post('title');

	$location=$this->input->post('location');

	$dated=	$this->input->post('dated');

	$sql_cat=$this->db->query('SELECT * FROM categories WHERE id="'.$category_id.'"');

			$cat=$sql_cat->row();

			

			$sql_subcat=$this->db->query('SELECT * FROM subcategories WHERE id="'.$subcategory_id.'"');

			$subcat=$sql_subcat->row();

	  if(is_uploaded_file($_FILES['image']['tmp_name'])){

			$image=rand(0,9999).$_FILES['image']['name'];

			@move_uploaded_file($_FILES['image']['tmp_name'],'uploads/gallery/'.$image);

		  	}else{

				$image="";

		}

	$gallerydata = array(

					'category_id'		=>	$category_id,

					'category_name'		=>	$cat->category_name,

					'subcategory_id'	=>	$subcategory_id,

					'subcategory_name'	=>	$subcat->subcategory_name,

					'user_id'			=>	$user['user_id'],

					'title'				=>	$title,

					'location'			=>	$location,

					'dated'				=>	$dated,

					'image'				=>	$image

				);

		$this->db->insert('gallery',$gallerydata);

		$this->session->set_flashdata('success', 'Gallery added successfully.');

	   redirect(base_url('my-gallery'));

  }

  

  

  public function EditorFileUpload(){

   if(isset($_FILES['upload']['name']))

	{

 	$file = $_FILES['upload']['tmp_name'];

 	$file_name = $_FILES['upload']['name'];

 	$file_name_array = explode(".", $file_name);

 	$extension = end($file_name_array);

 	$new_image_name = rand() . '.' . $extension;

 	chmod('uploads/editor_uploads/', 0777);

 	$allowed_extension = array("jpg", "gif", "png");

 	if(in_array($extension, $allowed_extension))

 	{

  	move_uploaded_file($file, 'uploads/editor_uploads/' . $new_image_name);

  	$function_number = $_GET['CKEditorFuncNum'];

  	$url = 'uploads/editor_uploads/' . $new_image_name;

  	$message = '';

  	echo "<script type='text/javascript'>window.parent.CKEDITOR.tools.callFunction($function_number, '$url', '$message');</script>";

 }

}

  }

  



  public function ProductBooking(){

  	$product_id = base64_decode($this->input->post('product_id'));

  	//$id =$this->input->post('product_id');
  	$slug =$this->input->post('slug');

  	$this->db->select('*');
  	$this->db->from('products');
  	$this->db->join('users', 'products.vendor_id = users.id'); 
  	$this->db->where('products.slug',$slug);
  	$query = $this->db->get();
  	$vendor =$query->row();

  	$v_company = preg_replace('/\s+/',' ', $vendor->company_name);
  	
  	$this->db->select('id');
  	$this->db->from('products');
  	$this->db->where('products.slug',$slug);
  	$queryp = $this->db->get();
  	$pro_id =$queryp->row();


    $customer_id = $this->input->post('cus_id');
    $location= $this->input->post('customer_location');
    $this->db->select('*');
  	$this->db->from('users');
  	$this->db->where('id',$customer_id);
  	$queryc = $this->db->get();
  	$customerd =$queryc->row();
  	
  	
  	$askingBuying= $this->input->post('when_to_buy');

  	$queries= $this->input->post('query');

  	$chk=$this->db->query('SELECT * FROM customer_bookings WHERE mobile="'.$mobile.'" AND product_id="'.$id.'"');

  	if($chk->num_rows()>0){

  		$this->session->set_flashdata('error', 'you have already requested.');

  		redirect(base_url('product-details/'.$slug));

  	}else{

  	    $response = $this->db->query('INSERT INTO customer_bookings SET
  			product_id="'.$pro_id->id.'",
  			name="'.$customerd->name.'",
  			email="'.$customerd->email.'",
  			mobile="'.$customerd->mobile.'",
  			location="'.$location.'",
  			when_to_buy="'.$askingBuying.'",
  			message="'.$queries.'"');
  			
  		if($response){
  		    $uname = str_replace('-', '%2d', str_replace(' ','%20', trim($customerd->name)));
            $v_company = str_replace('-', '%2d', str_replace(' ','%20', trim($v_company)));
            $user_phone = str_replace('-', '%2d', str_replace(' ','%20', trim($customerd->mobile)));
  		    // ----- SMS Code initiated ------
        	$api_key = "SMVIHqlkBEqEbQbX6NHDDQ";
        	$sender_id = "EVDRMZ";
        	$channel_id = "Trans";
			$dcs = 0;
			$flash_msg = 0;
			$route_id = 5;
            
            $msg = "Dear+".$uname."%2c+you+have+successfully+submitted+your+booking+request+to+".$v_company."%2e+EV+Dreamz+Private+Limited%2e";
            
        	// otp message send
        	$cSession = curl_init(); 
			
			//step2
			curl_setopt($cSession,CURLOPT_URL,"http://cloud.smsindiahub.in/api/mt/SendSMS?APIKey=".$api_key."&senderid=".$sender_id."&channel=".$channel_id."&DCS=".$dcs."&flashsms=".$flash_msg."&number=".$user_phone."&text=".$msg."&route=".$route_id."##&PEId=##");
			curl_setopt($cSession,CURLOPT_RETURNTRANSFER,true);
			curl_setopt($cSession,CURLOPT_HEADER, false); 
			//step3
			$result=curl_exec($cSession);
			//step4
			curl_close($cSession);
			//step5
 			// echo $result;
            // ----- SMS Code ended ------
            
            // ---SMS send to ADMIN . TEMPLATE : NOTIFA
                                
            // replaceing the space and - with unicode
			$phone = $this->db->get_where('admin_users', ['id'=>'1'])->row()->phone;
			
			##var## has successfully submitted a booking request to ##var##. EV Dreamz Private Limited.

        	$msg = $uname.'+has+successfully+submitted+a+booking+request+to+'.$v_company.'%2e+EV+Dreamz+Private+Limited%2e';

        	// otp message send
        	$cSession = curl_init(); 

			//step2
			curl_setopt($cSession,CURLOPT_URL,"http://cloud.smsindiahub.in/api/mt/SendSMS?APIKey=".$api_key."&senderid=".$sender_id."&channel=".$channel_id."&DCS=".$dcs."&flashsms=".$flash_msg."&number=".$phone."&text=".$msg."&route=".$route_id."##&PEId=##");
			curl_setopt($cSession,CURLOPT_RETURNTRANSFER,true);
			curl_setopt($cSession,CURLOPT_HEADER, false); 
			//step3
			$result=curl_exec($cSession);
			//step4
			curl_close($cSession);
			//step5
 			// echo $result;
            // ----- SMS Code ended ------
  		
  		}



  		$this->email->set_newline("\r\n");



  		$this->email->from('donotreply@evdreamz.com', 'Evdreamz Verification');

  		$data = array(

  			'name'=> $name,

  			'email'=> $email,

  			'mobile'=> $mobile,

  			'location'=> $location,

  			'model'=> $vendor->model,

  			'brand'=> $vendor->brand,
  			
  			'when_to_buy' => $askingBuying,

  			'message'=> $queries



  		);

  		$subject="Evdreamz Booking Request";

  		$this->email->to($vendor->email);

        //$this->email->to('mdkalamlhs@gmail.com'); 

        // replace it with receiver mail id

        $this->email->subject($subject); // replace it with relevant subject 

        $body = $this->load->view('booking_request_email',$data,TRUE);

        $this->email->message($body);   

        $this->email->send();

        $this->session->set_flashdata('success', 'Your Request has been sent successfully. We will get in touch with you soon.');

        redirect(base_url('product-details/'.$slug));	
        // redirect(base_url($vendor->slug));					   

      }

    }



    public function ProductBookingVendor(){



  	$product_id = base64_decode($this->input->post('product_id'));

  	$id =$this->input->post('product_id');

  	$this->db->select('*');

  	$this->db->from('products');

  	$this->db->join('users', 'users.id = products.vendor_id'); 

  	$this->db->where('products.id',$product_id);

  	$query = $this->db->get();

  	$vendor =$query->row();



  	

  	$name= $this->input->post('customer_name');

  	$email= $this->input->post('customer_email');

  	$mobile= $this->input->post('customer_mobile');

  	$location= $this->input->post('customer_location');

  	$queries= $this->input->post('query');

  	$chk=$this->db->query('SELECT * FROM customer_bookings WHERE mobile="'.$mobile.'" AND product_id="'.$id.'"');

  	if($chk->num_rows()>0){

  		$this->session->set_flashdata('error', 'you have already requested.');

  		redirect(base_url('product-details?id='.$id));

  	}else{

  		$this->db->query('INSERT INTO customer_bookings SET

  			product_id="'.$product_id.'",

  			name="'.$name.'",

  			email="'.$email.'",

  			mobile="'.$mobile.'",

  			location="'.$location.'",

  			message="'.$queries.'"');

  		

  		$this->email->set_newline("\r\n");

  		

  		$this->email->from('donotreply@evdreamz.com', 'Evdreamz Verification');

  		$data = array(

  			'name'=> $name,

  			'email'=> $email,

  			'mobile'=> $mobile,

  			'location'=> $location,

  			'model'=> $vendor->model,

  			'brand'=> $vendor->brand,

  			'message'=> $queries

  			

  		);

  		$subject="Evdreamz Booking Request";

  		$this->email->to($vendor->email);

        //$this->email->to('mdkalamlhs@gmail.com'); 

        // replace it with receiver mail id

        $this->email->subject($subject); // replace it with relevant subject 

        $body = $this->load->view('booking_request_email',$data,TRUE);

        $this->email->message($body);   

        $this->email->send();

        $this->session->set_flashdata('success', 'Your Request has been sent successfully. We will get in touch with you soon.');

        redirect(base_url('front/vendor_details/'.$vendor->id.'?id='.$id));				   
        // redirect(base_url($vendor->slug));		

      }

    }



    public function ProductBookingVendorWebsite(){

    	$btn_id = $this->input->post('btn_id');
    	// exit('d : '.$btn_id);

    	$this->db->select('*');

    	$this->db->from('users');

    	$this->db->where('users.id',$this->input->post('vendor_id'));

    	$query = $this->db->get();

    	$vendor =$query->row();




    	$name= $this->input->post('customer_name');

    	$email= $this->input->post('customer_email');

    	$mobile= $this->input->post('customer_mobile');

    	$location= $this->input->post('customer_location');

    	$queries= $this->input->post('query');

    	// $chk=$this->db->query('SELECT * FROM customer_bookings WHERE mobile="'.$mobile.'" AND product_id="'.$id.'"');
    	$chk=$this->db->query('SELECT * FROM customer_bookings WHERE mobile="'.$mobile.'" AND product_id="0"');

    	if($chk->num_rows()>0){

 				if($btn_id == 'c1'){
    			$this->session->set_flashdata('error1', 'you have already requested.');
    		}
    		else{
    			$this->session->set_flashdata('error2', 'you have already requested.');
    		}


    		redirect(base_url('product-details?id='.$id));

    	}else{

    		$this->db->query('INSERT INTO customer_bookings SET

    			product_id="'.$product_id.'",

    			name="'.$name.'",

    			email="'.$email.'",

    			mobile="'.$mobile.'",

    			location="'.$location.'",

    			message="'.$queries.'"');



    		$this->email->set_newline("\r\n");



    		$this->email->from('donotreply@evdreamz.com', 'Evdreamz Verification');

    		$data = array(

    			'name'=> $name,

    			'email'=> $email,

    			'mobile'=> $mobile,

    			'location'=> $location,

    			'model'=> $vendor->model,

    			'brand'=> $vendor->brand,

    			'message'=> $queries



    		);

    		$subject="Evdreamz Booking Request";

    		$this->email->to($vendor->email);

	        //$this->email->to('mdkalamlhs@gmail.com'); 

	        // replace it with receiver mail id

	        $this->email->subject($subject); // replace it with relevant subject 

	        $body = $this->load->view('booking_request_email',$data,TRUE);

	        $this->email->message($body);   

	        $this->email->send();

	        if($btn_id == 'c1'){
	        	$this->session->set_flashdata('success1', 'Your Request has been sent successfully. We will get in touch with you soon.');
	        }
	        else{
	        	$this->session->set_flashdata('success2', 'Your Request has been sent successfully. We will get in touch with you soon.');
	        }


	        // redirect(base_url('front/vendor_details/'.$vendor->id.'?id='.$id));				   
	        redirect(base_url($vendor->slug));		

	      }

    }









}

