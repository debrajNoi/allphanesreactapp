<?php

defined('BASEPATH') OR exit('No direct script access allowed');



class Front extends CI_Controller {

    private $admin_phone = '';
     
    public function __construct()
    {
        parent::__construct();

        $this->load->library('email');

	    $this->load->model('User_Model','user');

        $config = array (

                  'mailtype' => 'html',

                  'charset'  => 'utf-8',

                  'priority' => '1'

                   );

        $this->email->initialize($config);

        $this->load->library('session');

        $this->load->library('form_validation');

      	$this->load->database(); 

        $this->load->helper('url');
        
        $this->admin_phone = $this->db->get_where('admin_users', ['id'=>'1'])->row()->phone;

    }



	public function index()

	{	

		$sql_brands=$this->db->query('SELECT DISTINCT(brand) FROM products');

		$page_data['brands']=$sql_brands->result();
		

		$sql_cities=$this->db->query('SELECT DISTINCT(location) FROM products ORDER BY location ASC');

		$page_data['clty_list']=$sql_cities->result();

		

		$sql_banners=$this->db->query('SELECT users.*, products.* FROM products JOIN users ON products.vendor_id = users.id WHERE products.status=1 AND products.show_banner=1 ORDER BY products.id DESC');

		$page_data['banner_list']=$sql_banners->result();

		

		$sql_featured=$this->db->query('SELECT users.*, products.* FROM products JOIN users ON products.vendor_id = users.id WHERE products.status=1 AND products.is_featured=1 ORDER BY products.id DESC');

		$page_data['fearured_list']=$sql_featured->result();

		

		$sql_popular=$this->db->query('SELECT users.*, products.* FROM products JOIN users ON products.vendor_id = users.id WHERE products.status=1 AND products.popular=1 ORDER BY products.id DESC');

		$page_data['popular_list']=$sql_popular->result();
		
		$this->load->helper('common_helper');
        $page_data['cms'] = $this->db->get_where('cms', array('page_name' => 'home', 'parent' => 0))->result();

		
	    $this->load->view('includes/header');

	    $this->load->view('index',$page_data);

	    $this->load->view('includes/footer');

	}

	

	// For the pricing page we are creating a static page.
	public function pricing($id = ''){


		$data['callback_url']       = base_url().'checkout/callback';
		
		if($id != ''){
	        $data['surl']               = base_url().'checkout/success/'.base64_encode($id);
	        $data['furl']               = base_url().'checkout/failed/'.base64_encode($id);
		}
		else{
			$data['surl']               = base_url().'checkout/success';
	        $data['furl']               = base_url().'checkout/failed';
		}

        $data['currency_code']      = 'INR';

		$data['website_demo']='';
		$data['website']='';
        if($this->session->userdata('admin_id')!=''){
            $vendor = $this->db->get_where('users',array('id'=>$this->session->userdata('admin_id')))->result();
            if($vendor){
                $slug = $vendor[0]->slug;
                $data['slug']=$slug;
                $data['user_type']=$vendor[0]->user_type;
                $data['website_demo']=base_url().$slug;
    		    $data['website']='javascript:void(0)'; 
            }else{
                $data['slug']='';
                $data['user_type']='';
                $data['website_demo']=base_url('vendor');
    		    $data['website']=base_url('vendor');
            }
            
        }else{
            $data['slug']='';
            $data['user_type']='';
            $data['website_demo']=base_url('vendor');
		    $data['website']=base_url('vendor');
        }
                    
		$data['pricing'] = $this->db->get_where('tbl_plan', ['status'=>'1'],3,0)->result();
		$this->load->helper('common_helper');
        $data['cms'] = $this->db->get_where('cms', array('page_name' => 'pricing', 'parent' => 0))->result();
        
        $this->load->view('includes/header');
	    $this->load->view('pricing', $data);
	    $this->load->view('includes/footer');
	}


	// For the pricing page we are creating a static page.
	public function vendor_details($vendor_id = ''){

		$data['vendor'] = $this->db->get_where('users', ['id'=>$vendor_id])->result_array();
		$data['city'] = $this->db->get_where('cities', ['id'=>$data['vendor'][0]['city']])->result_array();
		$data['state'] = $this->db->get_where('states', ['id'=>$data['vendor'][0]['state']])->result_array();
		$data['products'] = $this->db->get_where('products', ['vendor_id'=>$vendor_id])->result_array();

		$sql_popular=$this->db->query('SELECT COUNT(*) AS count_it, SUM(rate) as rate_it FROM tbl_ratings WHERE vendor_id = '.$vendor_id);
		$data['ratings']=$sql_popular->result();

        $this->load->view('includes/header');

	    $this->load->view('vendor_details', $data);

	    $this->load->view('includes/footer');

	}


	public function vendor_website(){
	    // if($this->session->userdata('admin_id') == ''){
	    //     redirect('vendor');
	    // }
	    $slug = $this->uri->segment(1);
	    $vendor = $this->db->get_where('users',array('slug'=>$slug))->result();
	    $vendor_id = $vendor[0]->id;

		$data['vendor'] = $this->db->get_where('users', ['id'=>$vendor_id])->result_array();		
		$data['city'] = $this->db->get_where('cities', ['id'=>$data['vendor'][0]['city']])->result_array();
		$data['state'] = $this->db->get_where('states', ['id'=>$data['vendor'][0]['state']])->result_array();
		$data['products'] = $this->db->get_where('products', ['vendor_id'=>$vendor_id])->result_array();
		$data['vendor_web'] = $this->db->get_where('tbl_website_settings', ['vendor_id'=>$vendor_id])->result();

		$sql_popular=$this->db->query('SELECT COUNT(*) AS count_it, SUM(rate) as rate_it FROM tbl_ratings WHERE vendor_id = '.$vendor_id);
		$data['ratings']=$sql_popular->result();

        $this->load->view('includes/header_dedicated_website');

	    $this->load->view('vendor_website', $data);

	    // $this->load->view('includes/footer');

	}


	public function products(){

	    $vehicle_type = $this->input->get('vehicle_type');

	     $brand = $this->input->get('brand');

		 $location = $this->input->get('location');

		 $budget = $this->input->get('budget');

		

		 $pincode =$this->input->get('pincode');

		 $this->db->select('*');

		 $this->db->from('products');

		 	if($vehicle_type!=''){

			$this->db->where('vehicle_type',$vehicle_type);

		}

		if($brand!=''){

			$this->db->where('brand',$brand);

		}

		if($location!=''){

			$this->db->where('location',$location);

		}

		if($budget!='Select Budget' && $budget!=''){

			$this->db->where('price <=',$budget);

		}

		

		if($pincode!=''){

			$this->db->where('pincode <=',$pincode);

		}

		$this->db->where('status',1);

		$query = $this->db->get();

	//echo $this->db->last_query();die;

		$products =$query->result();

		$page_data['product_list']=$products;

	        $this->load->view('includes/header');

		    $this->load->view('products',$page_data);

		    $this->load->view('includes/footer');

	}





public function sell(){
    
        $this->load->helper('common_helper');

        $data['sell'] = $this->db->get_where('cms', array('page_name' => 'sell', 'parent' => 0))->result();
        
        // $data['steps'] = $this->db->get_where('cms', array('page_name' => 'sell', 'parent' => 13))->result();

        $this->load->view('includes/header');

	    $this->load->view('sell', $data);

	    $this->load->view('includes/footer');

}



public function partner_with_us(){
        $this->load->helper('common_helper');

        $data['cms'] = $this->db->get_where('cms', array('page_name' => 'partner-with-us', 'parent' => 0))->result();

        $this->load->view('includes/header');

	    $this->load->view('partner_with_us', $data);

	    $this->load->view('includes/footer');

}



public function coming_soon(){

   $this->load->view('includes/header');

	    $this->load->view('coming_soon');

	    $this->load->view('includes/footer');

}





    public function product_details($slug)
    {
    	$this->db->select('*');
    	$this->db->from('products');
    	$this->db->where('slug',urldecode($slug));
    	$query = $this->db->get();
    	$products =$query->row();
    
    	$sql_vendor= $this->db->query('SELECT * FROM users WHERE id="'.$products->vendor_id.'"');
    	$vendor=$sql_vendor->row();
    
    	$sql_city = $this->db->query('SELECT * FROM cities WHERE id="'.$vendor->city.'"');
    	$city =$sql_city->row();
    
    	$sql_reviews = $this->db->order_by("id", "desc")->limit(5)->get_where('tbl_ratings', ['prod_id'=>$products->id]);
    
    	$where = "";
    	if($products->price < 70000){
    		$where = "price < 70000 ";
    	}
    	else if($products->price > 70000 && $products->price < 100000){
    		$where = "price > 70000 AND price < 100000 ";
    	}
    	else if($products->price > 100000 && $products->price < 150000){
    		$where = "price > 100000 AND price < 150000 ";
    	}
    
    	$sql_popular=$this->db->query('SELECT products.*, users.* FROM products JOIN users WHERE products.status=1 AND products.popular=1 AND products.'.$where.' ORDER BY products.id DESC LIMIT 0, 4');
    	
    	$page_data['review_list']=$sql_reviews->result();
    	$page_data['popular_list']=$sql_popular->result();
    	$page_data['product']=$products;
    	$page_data['vendor']=$vendor;
    	$page_data['vendor_city']=$city;
    
        $this->load->view('includes/header');
	    $this->load->view('product_details',$page_data);
	    $this->load->view('includes/footer');
    }





public function contact_us(){

        $this->db->select('*');

		$this->db->from('cms');

		$this->db->where('page_name','contact-us');

		$query = $this->db->get();

		$data['cms'] = $query->row();

		if($this->input->post()){

			$name = $this->input->post('name');

			$email = $this->input->post('email');

			$mobile = $this->input->post('mobile');

			$message = $this->input->post('message');

			$to=$data['cms']->email;

		    

	     	$this->email->set_newline("\r\n");

	        $subject="Evdreamz Contact Us";

	    	$this->email->from('support@evdreamz.com', 'Evdreamz Verification');

	    	$data = array(

				 'name'=> $name,

				 'email'=> $email,

				 'mobile'=> $mobile,

				 'message'=>$message

			);

	        $this->email->to($email);  // replace it with receiver mail id

	        $this->email->subject($subject); // replace it with relevant subject 

	        $body = $this->load->view('contact_template',$data,TRUE);

	        $this->email->message($body);   

	        $this->email->send();



			$this->session->set_flashdata('success', 'Thank You ! Your message has been sent. We will get in touch with you soon.');


		 	redirect(base_url('contact-us'));

		}

        $this->load->view('includes/header');

	    $this->load->view('contact_us',$data);

	    $this->load->view('includes/footer');

    }

    

    public function terms(){

            $this->db->select('*');

    		$this->db->from('cms');

    		$this->db->where('page_name','terms');
    		
    		$this->db->where('parent', 0);

    		$query = $this->db->get();

    		$data['cms'] = $query->row();

            $this->load->view('includes/header');

    	    $this->load->view('terms',$data);

    	    $this->load->view('includes/footer');

    }
    
    public function invoice(){


            $this->load->view('includes/header');

    	    $this->load->view('invoice_template');

    	    $this->load->view('includes/footer');

    }

    

    public function about_us(){

            $this->db->select('*');

    		$this->db->from('cms');

    		$this->db->where('page_name','about-us');
    		
    		$this->db->where('parent', 0);

    		$query = $this->db->get();

    		$data['cms'] = $query->result();

            $this->load->view('includes/header');

    	    $this->load->view('about_us',$data);

    	    $this->load->view('includes/footer');

    }

    

    public function privacy(){

           $this->db->select('*');

    		$this->db->from('cms');

    		$this->db->where('page_name','privacy');
    		
    		$this->db->where('parent', 0);

    		$query = $this->db->get();

    		$data['cms'] = $query->row();

            $this->load->view('includes/header');

    	    $this->load->view('privacy',$data);

    	    $this->load->view('includes/footer');

    }



    public function cancellation(){

           $this->db->select('*');

    		$this->db->from('cms');

    		$this->db->where('page_name','cancellation');
    		
    		$this->db->where('parent', 0);

    		$query = $this->db->get();

    		$data['cms'] = $query->row();

            $this->load->view('includes/header');

    	    $this->load->view('cancellation',$data);

    	    $this->load->view('includes/footer');

    }



	public function vendor_regisration()

	{

	  $sql_city=$this->db->query('SELECT * FROM cities');

	  $data['city_list']=$sql_city->result();


	  $sql_state=$this->db->query('SELECT * FROM states');

	  $data['state_list']=$sql_state->result();


	  if($this->input->post()){

	  	// echo '<pre>';
	  	// print_r($this->input->post());
	  	// exit();
	  	// echo 'rolr : '.$this->input->post('user_role');

	  	if($this->input->post(''))

	     $user_role	=	$this->input->post('user_role');

	     $user_type	=	$this->input->post('user_type');

		 $name	=	$this->input->post('name');

		 $company_name	=	$this->input->post('company_name');
		 
		 $slug = strtolower(str_replace(' ','',$this->input->post('company_name')));

		 $email	=	$this->input->post('email');

		 $mobile	=	$this->input->post('mobile');

		 $city	=	$this->input->post('city');

		 $state	=	$this->input->post('state');

		 $neighborhood	=	$this->input->post('neighborhood');

		 $pincode	=	$this->input->post('pincode');

		 $whatsapp	=	$this->input->post('whatsapp');

		 $password	=	$this->input->post('password');

		 

		 $chk=$this->db->query('SELECT * FROM users WHERE email="'.$email.'" OR mobile="'.$mobile.'"');

		 if($chk->num_rows()>0){

		    $this->session->set_flashdata('error', 'Email or Mobile already exist.');

		 	redirect(base_url('vendor/regisration'));

		 }

		 // echo $user_role;

	      $userdata=array(

		     'user_role'        =>$this->input->post('user_role'),

		     'user_type'        =>$user_type,

			 'name'             =>$name,

			 'company_name'     =>$company_name,
			 
			 'slug'             =>$slug, //$vendor_slug,

			 'email'            =>$email,

			 'mobile'           =>$mobile,

			 'city'             =>$city,

			 'state'            =>$state,

			 'neighborhood'     =>$neighborhood,

			 'password'         =>md5($password),

			 'pincode'          =>$pincode,

			 'whatsapp'          =>$whatsapp

		  );

	  	// echo '<pre>';
	  	// print_r($userdata);
	  	// exit();

		  $this->db->insert('users',$userdata);

		  $user_id =$this->db->insert_id();

		  $token =md5($user_id);

		  

		  $this->db->query('UPDATE users SET token="'.$token.'" WHERE id="'.$user_id.'"');

		// Send Email

 		 $this->email->set_newline("\r\n");

         $subject="Evdreamz Email Verification";

        	$this->email->from('support@evdreamz.com', 'Evdreamz Verification');

        	$data = array(

             'user_id'=> $user_id,

			 'name'=> $name,

			 'email'=> $email,

			 'mobile'=> $mobile,

			 'token' =>	$token

		);

        $this->email->to($email);  // replace it with receiver mail id

        $this->email->subject($subject); // replace it with relevant subject 

        $body = $this->load->view('email_verification',$data,TRUE);

        $this->email->message($body);   

        $this->email->send();
        
        
        // Send sms for VENDOR TEMPLATE: MSG NOTIF
        
        // replaceing the space and - with unicode
        $vname = str_replace('-', '%2d', str_replace(' ','%20', trim($name)));
        $vendor_phone = $mobile;
        
        // ----- SMS Code initiated ------
    	$api_key = "SMVIHqlkBEqEbQbX6NHDDQ";
    	$sender_id = "EVDRMZ";
    	$channel_id = "Trans";
		$dcs = 0;
		$flash_msg = 0;
		$route_id = 5;

        // Just add the template properly
    	$msg = "Dear+".$vname."%2c+you+have+successfully+registered+on+the+EV+Dreamz+website%2e+EV+Dreamz+Private+Limited%2e";
        
    	// otp message send
    	$cSession = curl_init(); 
		
		//step2
		curl_setopt($cSession,CURLOPT_URL,"http://cloud.smsindiahub.in/api/mt/SendSMS?APIKey=".$api_key."&senderid=".$sender_id."&channel=".$channel_id."&DCS=".$dcs."&flashsms=".$flash_msg."&number=".$vendor_phone."&text=".$msg."&route=".$route_id."##&PEId=##");
		curl_setopt($cSession,CURLOPT_RETURNTRANSFER,true);
		curl_setopt($cSession,CURLOPT_HEADER, false); 
		//step3
		$result=curl_exec($cSession);
		//step4
		curl_close($cSession);
		//step5
 		// echo $result;
        // ----- SMS Code ended ------
        
        
        
        // ---SMS send to ADMIN . TEMPLATE : NOTIFA
        
        // replaceing the space and - with unicode
        // $aname = $vname;
        // $a_product_name = $v_product_name;
        // $admin_section = str_replace('-', '%2d', str_replace(' ','%20', trim('Product')));
        
        // ----- SMS Code initiated ------
    	$api_key = "SMVIHqlkBEqEbQbX6NHDDQ";
    	$sender_id = "EVDRMZ";
    	$channel_id = "Trans";
		$dcs = 0;
		$flash_msg = 0;
		$route_id = 5;
		$phone = $this->db->get_where('admin_users', ['id'=>'1'])->row()->phone;

        // Just add the template properly
    	$msg = $vname."+has+successfully+registered+on+the+EV+Dreamz+website%2e+EV+Dreamz+Private+Limited%2e";

    	// otp message send
    	$cSession = curl_init(); 

		//step2
		curl_setopt($cSession,CURLOPT_URL,"http://cloud.smsindiahub.in/api/mt/SendSMS?APIKey=".$api_key."&senderid=".$sender_id."&channel=".$channel_id."&DCS=".$dcs."&flashsms=".$flash_msg."&number=".$phone."&text=".$msg."&route=".$route_id."##&PEId=##");
		curl_setopt($cSession,CURLOPT_RETURNTRANSFER,true);
		curl_setopt($cSession,CURLOPT_HEADER, false); 
		//step3
		$result=curl_exec($cSession);
		//step4
		curl_close($cSession);
		//step5
 		// echo $result;
        // ----- SMS Code ended ------

		  

		  

		 $this->session->set_flashdata('success', 'Thank You ! Please check your email and continue...');

		 redirect(base_url('vendor/regisration'));

	  }

	  

	  	 $this->load->view('includes/header');

	  	$this->load->view('vendor_registration',$data);

	  	$this->load->view('includes/footer');

	}






	public function user_regisration()
	{

		$sql_city=$this->db->query('SELECT * FROM cities');
		$data['city_list']=$sql_city->result();

		$sql_state=$this->db->query('SELECT * FROM states');

		$data['state_list']=$sql_state->result();
		if($this->input->post()){

	  	if($this->input->post(''))
			$user_role	=	$this->input->post('user_role');
			$user_type	=	$this->input->post('user_type');
			$name	=	$this->input->post('name');
			// $company_name	=	$this->input->post('company_name');
			$email	=	$this->input->post('email');
			$mobile	=	$this->input->post('mobile');
			$city	=	$this->input->post('city');
			$state	=	$this->input->post('state');
			$neighborhood	=	$this->input->post('neighborhood');
			$pincode	=	$this->input->post('pincode');
			$password	=	$this->input->post('password');

		 	$chk=$this->db->query('SELECT * FROM users WHERE email="'.$email.'" OR mobile="'.$mobile.'"');

		 	if($chk->num_rows()>0){
				$this->session->set_flashdata('error', 'Email or Mobile already exist.');
				redirect(base_url('users/registration'));
		 	}

		 	// echo $user_role;
	      	$userdata=array(
					'user_role'=>$this->input->post('user_role'),
					'user_type'=>$user_type,
					'name'=>$name,
					// 'company_name'=>$company_name,
					'email'=>$email,
					'mobile'=>$mobile,
					'city'=>$city,
					'state'=>$state,
					// 'neighborhood'=>$neighborhood,
					'password'=>md5($password),
					'pincode'=>$pincode

		  		);

			$this->db->insert('users',$userdata);
			$user_id =$this->db->insert_id();

			$token =md5($user_id);

		  	$this->db->query('UPDATE users SET token="'.$token.'" WHERE id="'.$user_id.'"');

			// Send Email
			$this->email->set_newline("\r\n");
			$subject="Evdreamz Email Verification";
        	$this->email->from('support@evdreamz.com', 'Evdreamz Verification');

        	$data = array(
		             'user_id'=> $user_id,
					 'name'=> $name,
					 'email'=> $email,
					 'mobile'=> $mobile,
					 'token' =>	$token
				);

			$this->email->to($email);  // replace it with receiver mail id
			$this->email->subject($subject); // replace it with relevant subject 
			$body = $this->load->view('email_verification',$data,TRUE);
			$this->email->message($body);   
			$this->email->send();
		  
			$this->session->set_flashdata('success', 'Thank You ! Please check your email and continue...');
			redirect(base_url('users/registration'));

		}

		$this->load->view('includes/header');
		$this->load->view('user_registration',$data);
		$this->load->view('includes/footer');

	}



public function verify_email(){

	$token=$this->input->get('token');

	// $chk=$this->db->query('SELECT * FROM users WHERE token="'.$token.'" AND email_verification=0');
	$chk=$this->db->query('SELECT * FROM users WHERE token="'.$token.'"');

	if($chk->num_rows()>0){

		$res = $chk->result();

		if($res[0]->email_verification == 0){

		   	$this->db->query('UPDATE users SET email_verification=1 WHERE token="'.$token.'"');

		    $this->session->set_flashdata('success', 'Thank You ! Email verification successfully please wait a moment...');

			redirect(base_url('verify-email?token='.$token));
		}

		else{
			// echo $token.'<br/>';
			// echo $res[0]->user_role;
			// die();


			if($res[0]->user_role == 1){
				//Todo code
				redirect(base_url('vendor/dashboard'));
			}
			else{
				redirect(base_url('user/login'));
			}

		}

	}
	

    $this->load->view('includes/header');

	$this->load->view('verify_email');

	$this->load->view('includes/footer');

}	

	



public function GetCityByState(){

  	$state_id = $_REQUEST['state_id'];

   $sql_city =$this->db->query('SELECT * FROM cities WHERE state_id="'.$state_id.'"');

   $cities= $sql_city->result();

   foreach($cities as $st){?>

     <option value="<?php echo $st->id;?>"><?php echo $st->city;?></option>

   <?php }

   

}	



public function send_otp($product_id = null){

	// echo $product_id;
	$vendor_id = $this->db->get_where('products', ['id' => $product_id])->row()->vendor_id;

	// Generate a random code 
	$otp_code = rand(111111, 999999);

	// Find users phone number and email address
	$email = $this->db->get_where('users', ['id' => $vendor_id])->row()->email;
	$phone = $this->db->get_where('users', ['id' => $vendor_id])->row()->mobile;
	$vname = $this->db->get_where('users', ['id' => $vendor_id])->row()->name;

	// echo $vendor_id.' - '.$otp_code.' - '.$email.' - '.$phone;

	// Now save the otp in tbl_otp
	$otp_data = [
				"user_id"=>$vendor_id,
				"otp_for"=>"product",
				"reff_id"=>$product_id,
				"otp"=>$otp_code,
				"status"=>1,
				"expiry_date"=>""
			];
	$insert_otp = $this->db->insert('tbl_otp', $otp_data);
	if($insert_otp){
	// Now send the otp in the users mail and phone number 
    
    	$this->email->from('support@evdreamz.com', 'Evdreamz Verification');		
		// $this->email->to("debrajsarkar86@gmail.com"); //
		$this->email->to($email); //
        $this->email->subject("OTP Verfication");  
        // $body = $this->load->view('contact_template',$data,TRUE);
        // $this->email->message($body);
        $this->email->message("Hi, Your OTP to claim this product is ".$otp_code.". Please, donot share this OTP.");   

        if($this->email->send()){
        // 	echo "Mail sent successfully.";
            

            // replaceing the space and - with unicode
            $vname = str_replace('-', '%2d', str_replace(' ','%20', trim($vname)));
            
            // ----- SMS Code initiated ------
        	$api_key = "SMVIHqlkBEqEbQbX6NHDDQ";
        	$sender_id = "EVDRMZ";
        	$channel_id = "Trans";
			$dcs = 0;
			$flash_msg = 0;
			$route_id = 5;
        // 	$msg = "Dear%20".$vname."%2C+your+OTP+is+".$otp_code.".Please%2C+do+not+share+these+OTP+with+anyone+else.";
        	$msg = "Dear+".$vname."%2c+your+OTP+is+".$otp_code."%2e+Please%2c+do+not+share+this+OTP+with+anyone+else%2e+EV+Dreamz+Private+Limited%2e";
            
        	// otp message send
        	$cSession = curl_init(); 
			
			//step2
			curl_setopt($cSession,CURLOPT_URL,"http://cloud.smsindiahub.in/api/mt/SendSMS?APIKey=".$api_key."&senderid=".$sender_id."&channel=".$channel_id."&DCS=".$dcs."&flashsms=".$flash_msg."&number=".$phone."&text=".$msg."&route=".$route_id."##&PEId=##");
			curl_setopt($cSession,CURLOPT_RETURNTRANSFER,true);
			curl_setopt($cSession,CURLOPT_HEADER, false); 
			//step3
			$result=curl_exec($cSession);
			//step4
			curl_close($cSession);
			//step5
// 			echo $result;
            // echo '<br/>res : ';
			print_r($result);
            // ----- SMS Code ended ------

        }
        else{
        	echo "Failed to sent the mail.";
        }

	}


}




public function check_otp($product_id = '', $otp = ''){
	// echo $product_id.' / '.$otp;
	

	
	if(!empty($otp)){
		$res = $this->db->get_where('tbl_otp', [
						'reff_id' => $product_id, 
						'otp'=>$otp, 
						'status'=>1
					])->result_array();

		if(count($res) > 0){
			$this->db->where('id', $res[0]['id']);
			$upd = $this->db->update('tbl_otp', ['status' => 2]);
			if($upd){

				$login_query = $this->db->query('select * from users where id = '.$res[0]['user_id']);

				$user_row = $login_query->row();

				$this->session->set_userdata('admin_id', $user_row->id);

				$this->session->set_userdata('admin_email', $user_row->email);

				$this->session->set_userdata('admin_name', $user_row->name);

		 		$this->session->set_userdata('user_type', $user_row->user_type);

		 		$this->session->set_userdata('claim_product', '1');
		 		
		 		$this->email->from('support@evdreamz.com', 'EV Dreamz');		
        		$this->email->to('ashish@evdreamz.com');
                $this->email->subject("New Vendor Registered");  
                // $body = $this->load->view('contact_template',$data,TRUE);
                // $this->email->message($body);
                $this->email->message("Hi Admin, a new vendor, $user_row->name has registered in EV Dreamz. Please check vendor list.");
                $this->email->send();
				exit(json_encode(['result'=>'text-success', 'r'=>'1', 'message'=>'OTP Verified.']));
			}
			else{
				exit(json_encode(['result'=>'text-danger', 'r'=>'2', 'message'=>'Not updated.']));
			}
		}
		else{
			exit(json_encode(['result'=>'text-danger', 'r'=>'3', 'message'=>'Wrong OTP.']));
		}

	}
	else{
		exit(json_encode(['result'=>'text-danger', 'r'=>'4', 'message'=>'Enter the OTP.']));
	}

}



// public function check_otp1(){

// 	$this->form_validation->set_rules('otp_data', 'otp', 'trim|required');

// 	if ($this->form_validation->run() == true) {
		
// 		$res = $this->db->get_where('tbl_otp', [
// 						'reff_id' => $this->input->post('otp_product_id'), 
// 						'otp'=>$this->input->post('otp_data'), 
// 						'status'=>1
// 					])->result_array();

// 		if(count($res) > 0){
// 			$this->db->where('id', $res[0]['id']);
// 			$upd = $this->db->update('tbl_otp', ['status' => 2]);
// 			if($upd){
// 				echo 'OTP Verified.';
// 			}
// 			else{
// 				echo 'Not updated';
// 			}
// 		}
// 		else{
// 			// echo 'Verification failed.';

// 			$this->session->set_flashdata('error', 'Wrong OTP. Please enter a proper OTP.');

// 			// $id = base64_decode($this->input->post('otp_product_id'));

// 			// $this->db->select('*');

// 			// $this->db->from('products');

// 			// $this->db->where('id',$id);

// 			// $query = $this->db->get();

// 			// $products =$query->row();

// 			// $sql_vendor= $this->db->query('SELECT * FROM users WHERE id="'.$products->vendor_id.'"');

// 			// $vendor=$sql_vendor->row();

// 			// $sql_city = $this->db->query('SELECT * FROM cities WHERE id="'.$vendor->city.'"');

// 			// $city =$sql_city->row();

// 			// $page_data['product']=$products;

// 			// $page_data['vendor']=$vendor;

// 			// $page_data['vendor_city']=$city;

// 		 //        $this->load->view('includes/header');

// 			//     $this->load->view('product_details',$page_data);

// 			//     $this->load->view('includes/footer');

			
// 		}

// 	}
// 	else{

// 		// $id = base64_decode($this->input->post('otp_product_id'));

// 		// $this->db->select('*');

// 		// $this->db->from('products');

// 		// $this->db->where('id',$id);

// 		// $query = $this->db->get();

// 		// $products =$query->row();

// 		// $sql_vendor= $this->db->query('SELECT * FROM users WHERE id="'.$products->vendor_id.'"');

// 		// $vendor=$sql_vendor->row();

// 		// $sql_city = $this->db->query('SELECT * FROM cities WHERE id="'.$vendor->city.'"');

// 		// $city =$sql_city->row();

// 		// $page_data['product']=$products;

// 		// $page_data['vendor']=$vendor;

// 		// $page_data['vendor_city']=$city;

// 	 //        $this->load->view('includes/header');

// 		//     $this->load->view('product_details',$page_data);

// 		//     $this->load->view('includes/footer');
// 	}
	
// }

	

	

	public function submit_rating(){
		$ins_data = [
					"prod_id"=>$this->input->post('prod_id'),
					"vendor_id"=>$this->input->post('vendor_id'),
					"content"=>$this->input->post('review'),
					"rate"=>$this->input->post('rate'),
					"status"=>1
				];
		$this->db->insert('tbl_ratings', $ins_data);
		if($this->db->insert_id()){
			exit(json_encode(['status'=>'1', 'message'=>'Thank you for sharing your review.']));
		}
		else{
			exit(json_encode(['status'=>'0', 'message'=>'Sorry, failed to insert the review.']));
		}
	}
	
	
	public function mark_as_favorite(){
	    
	    
	    $ins_data = [
					"product_id"=>$this->input->post('product_id'),
					"user_id"=>$this->input->post('user_id'),
					"status"=>1
				];
				
	    $sql_markasfavorite = $this->db->query('SELECT id,status FROM tbl_favorite WHERE user_id="'.$ins_data['user_id'].'" AND product_id = "'.$ins_data['product_id'].'"');
    
        $markasfavorite = $sql_markasfavorite->row();
		
				
		if($markasfavorite)	{
		    if($markasfavorite->status == 1){
		        $this->db->query('UPDATE tbl_favorite SET status=0 WHERE id="'.$markasfavorite->id.'"');
		        exit(json_encode(['status'=>'3', 'message'=>'unmarked successfully']));
		    }
		    if($markasfavorite->status == 0){
		        $this->db->query('UPDATE tbl_favorite SET status=1 WHERE id="'.$markasfavorite->id.'"');
		        exit(json_encode(['status'=>'2', 'message'=>'marked successfully']));
		    }
		    
		} else{
		  //  exit(json_encode('entered else part'));
		    $this->db->insert('tbl_favorite', $ins_data);
		    if($this->db->insert_id()){
			    exit(json_encode(['status'=>'1', 'message'=>'insert and marked successfully']));
		    }   else{
			    exit(json_encode(['status'=>'0', 'message'=>'Sorry, failed to insert favorite.']));
		    }
		}
		
		
	}
	

    // Function to test the message templates
    public function test__1(){
        
        $product_id = '1,2,3';
        
        $exp = explode(',', $product_id);
        foreach($exp as $pids){
        
            $product_id = '1';
            
            $this->admin_phone;
            
            $this->db->select('users.name as vname, users.mobile as vphone');
            $this->db->from('products');
            $this->db->join('users', 'products.vendor_id=users.id');
            $this->db->where('products.id', $pids);
            $res = $this->db->get()->result();
            $vname = $res[0]->vname;
            $vendor_phone = $res[0]->vphone;
            
            $vname = str_replace('-', '%2d', str_replace(' ','%20', trim($vname)));
            
            // VENDOR
            $msg = "Dear+".$vname."%2c+you+have+successfully+verified+your+product%2fs%2e+EV+Dreamz+Private+Limited%2e";  // NOTIFVRF 
            
            $input_data = [
                'phone'=>$vendor_phone,
                'msg'=>$msg
            ];
            
            $this->send_msg_dy($input_data);
            
            
            // ADMIN
            $admin_msg = "Dear+".$vname."%2c+you+have+successfully+verified+your+product%2fs%2e+EV+Dreamz+Private+Limited%2e";  // NOTIFVRF 
            
            $input_data_admin = [
                'phone'=>'8967770323', //$this->admin_phone,
                'msg'=>$admin_msg
            ];
            
            $this->send_msg_dy($input_data_admin);
        }
        
        
    }
    
    // public function send_msg_dy($input_data){
    public function send_msg_dy(){
        
        $input_data['phone'] = '8617028943';
        // $input_data['msg'] = "vendorname"."+has+successfully+registered+on+the+EV+Dreamz+website%2e+EV+Dreamz+Private+Limited%2e";
        // $input_data['msg'] = "Dear+"."vendorname"."%2c+you+have+successfully+registered+on+the+EV+Dreamz+website%2e+EV+Dreamz+Private+Limited%2e";
        $input_data['msg'] = "TESTsddsdsdALOKIS+THERE"."+has+successfully+verified+their+product%2fs%2e+EV+Dreamz+Private+Limited%2e";
        // $input_data['msg'] = "TEST";
        
        // SMS Credentials
        $api_key = "SMVIHqlkBEqEbQbX6NHDDQ";
        $sender_id = "EVDRMZ";
        $channel_id = "Trans";  
        $dcs = 0;
        $flash_msg = 0;
        $route_id = 5;

        // otp message send
        $cSession = curl_init(); 

        //step2
        curl_setopt($cSession,CURLOPT_URL,"http://cloud.smsindiahub.in/api/mt/SendSMS?APIKey=".$api_key."&senderid=".$sender_id."&channel=".$channel_id."&DCS=".$dcs."&flashsms=".$flash_msg."&number=".$input_data['phone']."&text=".$input_data['msg']."&route=".$route_id."##&PEId=##");
        curl_setopt($cSession,CURLOPT_RETURNTRANSFER,true);
        curl_setopt($cSession,CURLOPT_HEADER, false); 
        //step3
        $result=curl_exec($cSession);
        //step4
        curl_close($cSession);
        //step5
        echo $result;
    }
    
    public function not_found(){
        $this->output->set_status_header('404');

        // Make sure you actually have some view file named 404.php
        $this->load->view('includes/header');
        $this->load->view('not_found');
        $this->load->view('includes/footer');
    }


}

