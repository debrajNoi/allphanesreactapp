<?php
class Webservice_common_model extends CI_Model
{    
    function __construct()
    {
        parent::__construct();
    }

	

	public function send_sms($mobile_no='',$message='')
	{
		//SMS API INTEGRATION
		$response=array();
		if(trim($mobile_no) && trim($message))
		{
		
			$response=$this->curl_post_method($endPoint,$params);
		}
		return $response;
	}

	public function curl_post_method($url,$params='')
	{
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,$url);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS,$params);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$server_output = curl_exec ($ch);
		curl_close ($ch);
		return $server_output;
	}

	
	
	function GetCategoryList(){
	$today=date('Y-m-d');
	
	 $query=$this->db->query('SELECT * FROM category_master ORDER BY id DESC');
	  
	   $result= $query->result();
	   return $result;
	}
	
function GetCourseList(){
	$today=date('Y-m-d');
	
	 $query=$this->db->query('SELECT * FROM course ORDER BY id DESC');
	  
	   $result= $query->result();
	   return $result;
	}
	
function GetSubscriptionList(){
   $query=$this->db->query('SELECT * FROM subscription_master  ORDER BY id DESC');
	  
	   $result= $query->result();
	   return $result;
}
	function GetGroupList(){
	
	 $query=$this->db->query('SELECT * FROM groups WHERE remove_status=0 ORDER BY id DESC');
	  
	   $result= $query->result();
	   return $result;
	}
	
	
	function GetInvoiceList(){
	    $query=$this->db->query('SELECT * FROM invoices ORDER BY id DESC');
	  
	   $result= $query->result();
	   return $result;
	}
	function GetItemList(){
		$query=$this->db->query('SELECT * FROM items WHERE added_by="admin" ORDER BY id DESC');
	  
	   $result= $query->result();
	   return $result;
	}

	
	
	
function GetBannerList(){
	 $query=$this->db->query('SELECT * FROM banners ORDER BY id DESC');
	  $result= $query->result();
	   return $result;
	}
	
	function GetUserList(){
	 $query=$this->db->query('SELECT * FROM users WHERE remove_status=0 ORDER BY user_id DESC');
	  $result= $query->result();
	   return $result;
	}

function GalleryList(){
	 $this->db->select("*");
      $this->db->from('gallery');
	  $this->db->order_by('id','DESC');
      $query = $this->db->get();
	  $result=$query->result();
	   return $result;
	}

	
function GetGalleryList($item_id){
	 
	   
	  $this->db->select("*");
      $this->db->from('items_images');
      $this->db->where('item_id',$item_id);
	 
      $query = $this->db->get();
	  $result=$query->result();
	   return $result;
	}
	
	
	function GetVideoList(){
	 
	   
	  $this->db->select("*,videos.id as video_id,videos.status as video_status,videos.description as video_desc,videos.dated as video_date");
      $this->db->from('videos');
      $this->db->join('users', 'users.user_id = videos.user_id');
	  $this->db->where('videos.remove_status',0);
      $query = $this->db->get();
	  $result=$query->result();
	   return $result;
	}

function GetEventList(){
   $this->db->select("*");
      $this->db->from('events');
      $this->db->where('remove_status',0);
      $query = $this->db->get();
	  $result=$query->result();
	   return $result;
}

function GetnotificationList(){
   $this->db->select("*");
      $this->db->from('notification');
      $this->db->where('remove_status',0);
	   $this->db->order_by('dated','DESC');
      $query = $this->db->get();
	  $result=$query->result();
	   return $result;
}
function GetCMSList(){
   $this->db->select("*");
      $this->db->from('cms');
      $query = $this->db->get();
	  $result=$query->result();
	   return $result;
}		

	function insert($table, $data = array()) 
	{
        $this->db->insert($table, $data);
        return $this->db->insert_id();
    }

	function get_where_num($table, $where = '')
	{
        $query = $this->db->get_where($table, $where);
        return $query->num_rows();
    }

	function get_where_row($table, $where = '',$sortby='') 
	{
        $query = $this->db->get_where($table, $where, $sortby);
        return $query->row();
    }

	function get_where($table, $where = '',$sortby='') 
	{
        $query = $this->db->get_where($table, $where,$sortby='');
        return $query->result();
    }

	function get_where_array($table, $where = '') 
	{
        $query = $this->db->get_where($table, $where);
        return $query->result_array();
    }
	
	function update($table, $data = array(), $where = array()) 
	{
        $this->db->where($where);
        $this->db->update($table, $data);
        return $this->db->affected_rows();
    }

	function delete($table, $where = array()) 
	{
        $this->db->delete($table, $where);
        return $this->db->affected_rows();
    }

	function otp()
	{

		$otp=mt_rand(1000, 9999);//rand()

		return $otp;

	}

	function nullToStr($value) 
	{
   		 $value = $value === null ? "" : $value;
		 return  (string)$value;
    }

	public function send_otp_email($email)
	{
		if(trim($email))
		{
			$otp=$this->otp();
			$data=array(
			  "mobile_or_email"	=>$email,
			  "otp"				=>$otp,
			  "date_time"		=>date("Y-m-d H:i:s")
			);

			$this->db->insert("instadoc_otp",$data);		

			/*$to = $email;

			$config = array (
					'mailtype' => 'html',
					'charset'  => 'utf-8',
					'priority' => '1'
				);
			$this->email->initialize($config);
			$this->email->from('info@instacall.com', 'InstaCall');
			$this->email->to($to);
			$this->email->subject('OTP Send From InstaCall');
			$body = "Please use this code ".$otp." to verify your email";
			$this->email->message($body);
			$this->email->send();*/
			
			$token = array(
			   'OTP'=> $otp
			);
			$pattern = '[%s]';
			foreach($token as $key=>$val)
			{
				$varMap[sprintf($pattern,$key)] = $val;
			}
		  
			// email to patient start
			$query=$this->db->query("SELECT * FROM instadoc_email_templates WHERE  email_template_type_id='2'"); 	
			$tempData= $query->row_array();
			$resultArrayCount=$query->num_rows();
			if($resultArrayCount>0)
			{
				$emailContent = strtr($tempData['content'],$varMap);	
				$receiver_email = $email;
				$mail_config = array(
				 'protocol' => 'tls',
				 'smtp_host' => 'v-xplore.com',
				 'smtp_port' => 465,
				 'smtp_user' => 'dipankar@v-xplore.com', // change it to yours
				 'smtp_pass' => 'dipankar@123', // change it to yours
				 'mailtype'  => 'html', 
				 'charset'   => 'utf-8',
				 'wordwrap' => TRUE		
				); 
				$email_body = $emailContent;
				$this->load->library('email',$mail_config);
				$this->email->set_mailtype("html");
				$this->email->from('info@intadoc.com', "InstaDoc");
				$this->email->to($receiver_email);
			   // $this->email->reply_to('koushik@bikrimart.com', "Bikrimart");
				$this->email->subject($tempData['subject']);
				$this->email->message($email_body);			
				$this->email->send();
			}
	
		}
	}
    
 

function GetSheduleList(){
 $query=$this->db->query('SELECT * FROM shedules ORDER BY created DESC');
	  $result= $query->result();
	   return $result;
}
	
	
	
function GetTeamList(){
	
	   $query=$this->db->query('SELECT * FROM team  ORDER BY id DESC');
	
	
	   $result= $query->result();
	   return $result;
	}	
	
	
	
	
	
	
}

