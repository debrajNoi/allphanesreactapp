<?php
class User_Model extends CI_Model
{    
    function __construct()
    {
        parent::__construct();
		
    }

	

function user_signup(){
 $this->load->library('session');

  $first_name=$this->input->post('first_name');
  $last_name=$this->input->post('last_name');
  $email=$this->input->post('email');
  $mobile=$this->input->post('mobile');
  $address=$this->input->post('address');
  $password=$this->input->post('password');
  $cpassword=$this->input->post('cpassword');
  $courses=implode(',',$this->input->post('courses'));
  
 
  $chk=$this->db->query('SELECT * FROM users WHERE email="'.$email.'" OR mobile="'.$mobile.'"');
  if($chk->num_rows()>0){
     $this->session->set_flashdata('error', 'Email or mobile number already taken.');
  
  }else{
  $sess_data = array(
               'course'   		 => $courses,
               'first_name'    => 	$first_name,
               'last_name'     => 	$last_name,
               'email'     	   => 	$email,
               'mobile'        =>	$mobile,
			   'address'        =>	$address,
               'password'	   => 	md5($password)
             );
	$this->session->set_userdata('signup',$sess_data);
      $this->db->insert('users',$sess_data);
	  $this->session->unset_userdata('signup');
	  $this->session->set_flashdata('success', 'Signup succesfully.');
  
  }
}


function login(){
   $email = $this->input->post('email');
	  $password = $this->input->post('password');
	  
	  $chk=$this->db->query('SELECT * FROM users WHERE email="'.$email.'" AND password="'.md5($password).'"');
	  if($chk->num_rows()>0){
	  $user=$chk->row();
	    $userdata = array(
		       'user_id'    => 	$user->user_id,
               'first_name'    => 	$user->first_name,
               'last_name'     => 	$user->last_name,
               'email'     	   => 	$user->email,
               'mobile'        =>	$user->mobile,
			   'address'        =>	$user->address
               );
			    $this->session->set_userdata('userdata',$userdata);
	    		 return 1;
	  }else{
	    		 return 0;
	  }
}	
	
	function UserInfo(){
	
	 $user=$this->session->userdata('userdata');
	 $query=$this->db->query('SELECT * FROM users WHERE user_id="'.$user['user_id'].'"');
	  $result= $query->result();
	   return $result;
	}
	
function GetTimeline(){
 $user=$this->session->userdata('userdata');
  $query=$this->db->query('SELECT * FROM timeline WHERE user_id="'.$user['user_id'].'"');
	  $result= $query->result();
	   return $result;
}
	
	
	
	
	
}

