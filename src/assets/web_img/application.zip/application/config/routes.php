<?php

defined('BASEPATH') OR exit('No direct script access allowed');



/*

| -------------------------------------------------------------------------

| URI ROUTING

| -------------------------------------------------------------------------

| This file lets you re-map URI requests to specific controller functions.

|

| Typically there is a one-to-one relationship between a URL string

| and its corresponding controller class/method. The segments in a

| URL normally follow this pattern:

|

|	example.com/class/method/id/

|

| In some instances, however, you may want to remap this relationship

| so that a different class/function is called than the one

| corresponding to the URL.

|

| Please see the user guide for complete details:

|

|	https://codeigniter.com/user_guide/general/routing.html

|

| -------------------------------------------------------------------------

| RESERVED ROUTES

| -------------------------------------------------------------------------

|

| There are three reserved routes:

|

|	$route['default_controller'] = 'welcome';

|

| This route indicates which controller class should be loaded if the

| URI contains no data. In the above example, the "welcome" class

| would be loaded.

|

|	//$route['404_override'] = 'errors/page_missing';

      $route['error404'] = 'Custom404/index';

|     $route['404']             = "Custom404/index";

| This route will tell the Router which controller/method to use if those

| provided in the URL cannot be matched to a valid route.

|

|	$route['translate_uri_dashes'] = FALSE;

|

| This is not exactly a route, but allows you to automatically route

| controller and method names that contain dashes. '-' isn't a valid

| class or method name character, so it requires translation.

| When you set this option to TRUE, it will replace ALL dashes in the

| controller and method URI segments.

|

| Examples:	my-controller/index	-> my_controller/index

|		my-controller/my-method	-> my_controller/my_method

*/

$route['default_controller'] = 'front/index';
$route['404_override'] = 'front/not_found';
$route['translate_uri_dashes'] = FALSE;
$route['vendor/regisration'] = 'front/vendor_regisration';
$route['verify-email'] = 'front/verify_email';


// $route['vendor'] = 'Vendor/index';
$route['vendor/login'] = 'Vendor/index';





$route['pricing'] = 'front/pricing';
$route['products'] = 'front/products';
// $route['product-details'] = 'front/product_details';
$route['product-details/(:any)'] = 'front/product_details/$1';
$route['contact-us'] = 'front/contact_us';
$route['terms'] = 'front/terms';
$route['privacy'] = 'front/privacy';
$route['cancellation'] = 'front/cancellation';
$route['about-us'] = 'front/about_us';
$route['sell'] = 'front/sell';
$route['partner-with-us'] = 'front/partner_with_us';
$route['coming-soon'] = 'front/coming_soon';




// User Routes
$route['user'] = 'User/index';
$route['users/registration'] = 'front/user_regisration';
$route['user/login'] = 'customer/index';
$route['user/forgot_password'] = 'customer/forgot_password';

$route['sitemap\.xml'] = "Sitemap/index";


/***********************************************vendor website section*************************************************************/

require_once( BASEPATH .'database/DB.php' );
$db =& DB();
$db->select('*');    
$db->from('users');
$db->where('user_role',1);
$query = $db->get();
$result = $query->result();
foreach( $result as $row )
{
	$route[strtolower($row->slug)] = 'front/vendor_website'; 
}



