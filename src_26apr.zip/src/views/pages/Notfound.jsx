import React from 'react'
import IndexNavbar from '../../components/Navbars/IndexNavbar'

function Notfound() {
  return (
    <section id='notfound'>
        {/* <IndexNavbar /> */}
        <div className="d-flex justify-content-center mt-5"><h1>Page Not Found</h1></div>
    </section>
  )
}

export default Notfound