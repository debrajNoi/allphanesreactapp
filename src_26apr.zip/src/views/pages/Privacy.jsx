import React from 'react'
import IndexNavbar from '../../components/Navbars/IndexNavbar'

function Privacy() {
  return (
    <main>
        <div>
            <div className="terms container mt-5">
                <h3>Privacy Policy </h3>
                <p className='mt-3'>
                1. Lorem ipsum, dolor sit amet consectetur adipisicing elit. Sequi aliquam possimus ullam nemo porro dolorem modi ut, enim natus iusto voluptate quae unde odio nihil repellendus dolore quos suscipit labore?

                </p>
                <p>2. Lorem ipsum dolor sit amet consectetur adipisicing elit. Eaque possimus, ipsum nisi eius distinctio praesentium, dolorum voluptatum id dignissimos illum adipisci aspernatur consectetur assumenda suscipit cumque quis minus non error.</p>
                <p>3. Lorem ipsum dolor, sit amet consectetur adipisicing elit. Officiis fuga quasi repellat nam quidem voluptatibus labore, error recusandae consequatur! Doloremque quidem dolorem id inventore enim odit facilis ex architecto iste.</p>
                <p>4. Lorem ipsum dolor, sit amet consectetur adipisicing elit. Officiis fuga quasi repellat nam quidem voluptatibus labore, error recusandae consequatur! Doloremque quidem dolorem id inventore enim odit facilis ex architecto iste.</p>
                <p>5. Lorem ipsum dolor, sit amet consectetur adipisicing elit. Officiis fuga quasi repellat nam quidem voluptatibus labore, error recusandae consequatur! Doloremque quidem dolorem id inventore enim odit facilis ex architecto iste.</p>
                <p>6. Lorem ipsum dolor, sit amet consectetur adipisicing elit. Officiis fuga quasi repellat nam quidem voluptatibus labore, error recusandae consequatur! Doloremque quidem dolorem id inventore enim odit facilis ex architecto iste.</p>
            </div>
        </div>
    </main>
  )
}

export default Privacy